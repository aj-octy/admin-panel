import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import styles from "../../styles.module.css";
import { Form } from "react-bootstrap";
import axios from "axios";
import DatePicker from "react-datepicker";
import AsyncSelect from "react-select/async";
import makeAnimated from "react-select/animated";
import "../../styles.module.css";
import Select from "react-select";
import { library } from "@fortawesome/fontawesome-svg-core";
import { faSave } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useParams, useHistory } from "react-router-dom";
import Crud from '../../common/Calls_methods'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

library.add(faSave);

function AddEditDeals() {
  const { id } = useParams();
  let history = useHistory();

  const [visible, setVisible] = useState(true);
  const [bidderShow, setBidderShow] = useState(true);
  const [dealTypeShow, setDealTypeShow] = useState(true);
  const [endDateShow, setEndDateShow] = useState(true);

  const [startDate, setStartDate] = useState();
  
  const [endDate, setEndDate] = useState("");

  //set default query terms
  const [query, setQuery] = useState([]);
  const [query2, setQuery2] = useState('aa');
  const [queryBidder, setQueryBidder] = useState("");

  //get animated components wrapper
  const animatedComponents = makeAnimated();

  //   if (id != undefined) {
  var [packId, setPackId] = useState("");
  var [defaultData, setdefaultData] = useState([]);
  var [defaultDataForMulti, setdefaultDataForMulti] = useState([]);
  var [defaultBidderData, setdefaultDataBidderData] = useState([]);
  var [data, setData] = useState([]);
  var [updateBidder, setUpdateBidder] = useState("");
  //   }
  var [selectedOption, setSelectedOption] = useState([]);
  var [onlydeal, setonlydeal] = useState(true);

  const initialValue = {
    name: "",
    auction_price_type: "fixed",
    price: 0,
    seat_id: "",
    pack_id: "",
    deal_type: "guaranteed",
    targetimpression: "0",
    start_date: "",
    end_date: "",
    onGoing:0,
    bidders_option:"selected_bidder",
    startHM:"00:00",
    endHM:"00:00"
    
  };
  
  const [deals, setDeals] = useState(initialValue);
  const [deal_bidder, setDeal_bidder] = useState([]);

  const {
    name,
    price,
    auction_price_type,
    seat_id,
    deal_type,
    targetimpression,
    start_date,
    end_date,
    onGoing,
    pack_id,
    startHM,
    endHM
    
  } = deals;
  const { deal_id, bidder_id, margin } = deal_bidder;

  // error form 
  const [validation, setValidation] = useState({
    name: '',
    pack_id:'',
    auction_price_type: "fixed",
    price: '',
    deal_type: "guaranteed",
    targetimpression: '',
    start_date:'',
    end_date: "",
    onGoing:0,
  });
  // error form

  // fetch filteres search results for dropdown for packages
  const loadOptions = () => {
    
    Crud.fetchDatas(`deals/packages-search?${query}`).then(
      (res) =>
        res.json().then(async (data) => {
          let mydata = await data.map((it) => {
            return { label: it.name, value: it.id };
          });
          setData(mydata)
        })
    );
  };

  if (selectedOption) {
    var BiddersIdsInArray = selectedOption.map((item) => item.id);
    var BiddersIds = BiddersIdsInArray.toString();
  }
  useEffect(() => {
    setUpdateBidder(BiddersIds);
  });
  

  const getDealData = () => {
    Crud.details(`deals/${id}`).then((res) => {
      console.info(JSON.parse(res.data[0].definition))
      var data = JSON.parse(res.data[0].definition)
      console.log(data)
      let check = data.bidders.some(it => it.onlydeal == 1)
      console.info(check)
      if(data.auction_price_type == "nonfixed") {
        setVisible(false)
      } 
      if(data.bidders_option == "allBidder") {
        setBidderShow(false)
      }
      
      if(data.deal_type == "nonguaranteed") {
        setDealTypeShow(false)
      }
      
      if(data.onGoing == 1){
        setEndDateShow(false)
      }
 
      if(check == true) setonlydeal(1)
      else setonlydeal(0)
      setDeals({ ...data});
      loadPack(data.pack_id)
      loadBidderData(data.deal_id)
      console.log(data.deal_id)
    });
  };
  let optional = [];
  const loadPack = (packID) => {
    Crud.fetchData(`deals/packId/` + packID).then((res) =>{
      res.json()
      .then((el) => {
        optional.push({ label: el[0].name, value: el[0].id });
        setdefaultData([{ label: el[0].name, value: el[0].id }]);
      }).catch( er =>{
        console.error(er)
      })
    }
     
    )
  };

  
  const loadBidderData = (deal_id) => {
    Crud.fetchData(`deal_bidder/` + deal_id).then((res) =>{
      res.json()
      .then((it) => {
        console.log(it)
        setDeal_bidder(it)
        it.forEach(element => {
          Crud.fetchData(`deal_bidder/bidder_id/` + element.bidder_id).then((res) =>{
            res.json()
            .then((el) => {
              let check = defaultDataForMulti.some(item => item.value == el.BidderId)
              
               if(check == false){
                setdefaultDataForMulti(o=>([...o,{label: el[0].BidderName, value: el[0].BidderId}]));
                setSelectedOption(o=>([...o,{label: el[0].BidderName, value: el[0].BidderId, margin: element.margin}]))
              }
            }
          )})
        });
      }).catch( er =>{
        console.error(er)
      })
    });
    
  };

  useEffect(() => {
    if (data.length <= 0) {
      loadPack(deals.pack_id);
    }
  });
  useEffect(async () => {
    loadOptions();
      await loadBidders();
  }, [queryBidder]);

  // fetch filteres search results for Bidder
  const loadBidders = () => {
    Crud.fetchData(`deals/bidders-search?${queryBidder}`
    ).then((res) => res.json()
    .then(data => {
      let newData = data.map( ol => {
        return {label: ol.BidderName , value: ol.BidderId}
      })
      setQuery(newData)
    }));
  };

  //   ----------------------------------------------------------------------------------------------------------


  useEffect(() => {
    if (id != undefined) {
      getDealData();
    } else if (id == "") {
    }
  }, []);


  // dateFormat

  Number.prototype.padLeft = function(base,chr){
    var  len = (String(base || 10).length - String(this).length)+1;
    return len > 0? new Array(len).join(chr || '0')+this : this;
}

const formatDateTime = val => {
	let d = new Date(val);
	let dformat =
		[d.getFullYear(), (d.getMonth() + 1).padLeft(), d.getDate().padLeft()].join('-') 
		// [d.getHours().padLeft(), d.getMinutes().padLeft(), d.getSeconds().padLeft()].join(':');
	return dformat;
};

  
const onInputChangeStartDate = (e) => {
  
  setDeals((item) => ({...item,start_date: formatDateTime(e)}));
}

  const onInputChangePack = (e) => {
    setDeals((item) => ({
      ...item,
      pack_id: e?.value,
    }));
    setdefaultData([{ label: e.label, value: e.value }]);
  }

  const onInputChangeEndDateFormat =(e,t) =>{
    if(t){console.log(t)}
    setDeals((item) => ({...item,end_date: formatDateTime(e)}));
  }


  const onInputChangeEndDate = (e) => {
    let t="test"
      let ongoingName = e.target.name
      let ongoingValue = e.target.value
      if(ongoingName == "onGoing" && ongoingValue == 1){
        // onInputChangeEndDateFormat(t)
        setDeals((item) => ({...item,[e.target.name]: e.target.value })); 
        setDeals((item) => ({...item,endHM:"00:00" }));
        setDeals((item) => ({...item,end_date:"0000-00-00" }));
      }else{
        setDeals((item) => ({
          ...item,[e.target.name]: e.target.value,
        }));
      }
    }

  const onInputChangeDealType = e => {
    if(e.target.name == 'targetimpression'){
      let errors = [] 
      if(e.target.value < 0){
        errors.targetimpression = "cpm must be poitive";
      }
      setValidation(errors);
    }

    if(e.target.value == "nonguaranteed"){
      setDeals((item) => ({
        ...item, deal_type: e.target.value,targetimpression:"0"
      }));
    }else{
      setDeals((item) => ({
        ...item, [e.target.name]: e.target.value,
      }));
    }
}

const onInputChangeAuctionType =(e)=>{
  if(e.target.value == "nonfixed") {
    setDeals((item) => ({
      ...item, auction_price_type: e.target.value,price:0
    }));
  }else{
    setDeals((item) => ({
      ...item, [e.target.name]: e.target.value,
    }));
  } 
}




  const onInputChange = (e) => {

    if(e.target.name == 'price'){
      let errors = [] 
      if(e.target.value < 0){
        errors.price = "Only Positive Numbers Allowed";
      }
      setValidation(errors);
    }

    if (e.target.value == "allBidder"){
      setDeal_bidder([]);
    }else {console.log("deal_bidder selected")}
    setDeals((item) => ({
      ...item,
      deal_id:Math.floor(100000 + Math.random() * 900000),
      [e.target.name]: e.target.value,
    }));
   
  };

  const onSubmit = async (e) => {

    console.log(deals)
    e.preventDefault();

    console.log(validation)


    let errors = [] 

    if (deals.name.trim()=='') {
      errors.name = "Please provide deals name";
      toast.error("Please provide deals name",{
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        })
    }
    
    if (deals.pack_id=='') {
      errors.pack_id = "Please provide pack_id name";
      toast.error("Please provide pack_id name",{
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        })
    }
    if(deals.auction_price_type == 'fixed'){
    if (deals.price=='') {
      errors.price = "Please provide price";
      toast.error("Please provide price",{
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        })
    }
  }
  if(deals.deal_type == 'guaranteed'){
    if (deals.targetimpression=='') {
      errors.targetimpression = "Please Enter CPM";
      toast.error("Please provide CPM",{
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        })
    }
  }
  if (deals.start_date=='') {
    errors.start_date = "Please Select Start Date";
    toast.error("Please Select Start Date",{
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: false,
      draggable: true,
      progress: undefined,
      })
  }
  if(deals.onGoing == 0){
    if (deals.end_date=='') {
      errors.end_date = "Please End Date";
      toast.error("Please End Date",{
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        })
    }
  }

// get start date & end diff
let getStartDate = deals.start_date
let getEndDate = deals.end_date
  const _MS_PER_DAY = 1000 * 60 * 60 * 24;

// getstartdate and getenddate are javascript Date objects
function dateDiffInDays(getstartdate, getenddate) {
  // Discard the time and time-zone information.
  const utc1 = Date.UTC(getstartdate.getFullYear(), getstartdate.getMonth(), getstartdate.getDate());
  const utc2 = Date.UTC(getenddate.getFullYear(), getenddate.getMonth(), getenddate.getDate());

  return Math.floor((utc2 - utc1) / _MS_PER_DAY);
}

// test it
const getstartdate = new Date(getStartDate),
      getenddate = new Date(getEndDate),
    difference = dateDiffInDays(getstartdate, getenddate);
// get start date & end diff 
console.log(difference)
if (difference <= 0) {
  errors.end_date = "End Date must be Greater than Start Date";
  toast.error("End Date must be Greater than Start Date",{
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: false,
    draggable: true,
    progress: undefined,
    })
}


    setValidation(errors);

    console.log(Object.values(errors))
    console.log(Object.values(errors).length)

    if(Object.values(errors).length == ''){
      console.log("no error found")
    

    if(id && id >0 ){
      deals.bidders = deal_bidder
      console.log(deal_bidder)
      console.log(deals)
    return Crud.update(`deals`,id, deals).then(res => {
      console.log("Edit")
      console.log(deals)
      if(res.status == 200){
        let finaldata = []
        if(deal_bidder.length > 0) {
           finaldata = deal_bidder.map( ol => {
            return {...ol,deal_id :deals.deal_id};
          })
        } else {
          finaldata.push({deal_id: deals.deal_id, delete: 'all'})
        }
        console.log(finaldata)
        Crud.create(`deal_bidder`, finaldata)
        .then(data => console.log(data))
      }
    })
    .then(()=>{console.log(deals) 
      toast.success("Deals Updated !",{
         position: "top-right",
         autoClose: 5000,
         hideProgressBar: false,
         closeOnClick: true,
         pauseOnHover: false,
         draggable: true,
         progress: undefined,
         })
         history.push("/tools/ManagePackagesAndDeals");
        }) 
      }else{ 
    deals.bidders = deal_bidder
      return  Crud.create(`deals`, deals).then(res => {
          console.log("add")
          if(res.status == 200){
            console.log(res)
            let beaderData = deal_bidder.map( ol => {
              ol.deal_id = res.data.deal_id
              return ol
            })
            Crud.create(`deal_bidder`, beaderData)
            .then(console.log(beaderData))
          }
        })
        .then(()=>{console.log(deals) 
          toast.success("Deals Added !",{
             position: "top-right",
             autoClose: 5000,
             hideProgressBar: false,
             closeOnClick: true,
             pauseOnHover: false,
             draggable: true,
             progress: undefined,
             })
             history.push("/tools/ManagePackagesAndDeals");
            })
          }
        }
  };

  const mymultiselect =(e) => {
    if(e && e.length>0){
      let obj2 = {
        bidder_id: e[e.length-1].value,
        onlydeal:0
      }
      let newData = e.map( ol => {
        return ol
      })
    setdefaultDataForMulti(newData);
    setSelectedOption(e)
    let check = deal_bidder.some( ol => ol.bidder_id == e[e.length-1].value)
    if(check == false) setDeal_bidder(p=>([...p,obj2]))
    else {
      const results = defaultDataForMulti.filter(({ value: id1 }) => !e.some(({ value: id2 }) => id2 === id1)).map(ol=> {return {bidder_id: ol.value}});
      const index = deal_bidder.findIndex(ol => ol.bidder_id == results[0].bidder_id)
      if(index !== -1) {
        deal_bidder.splice(index, 1)
        setDeal_bidder(deal_bidder)
      }
    }
  } else {
    setdefaultDataForMulti([]);
    setDeal_bidder([])
    setSelectedOption([])
  }
}
let [state, setState] = useState(false)
  const marginInput =(e) => {
    e.preventDefault()
    if(state ==false) setState(true)
    else setState(false)
    deal_bidder[e.target.name].margin = Number(e.target.value)
    setDeal_bidder(deal_bidder)
    selectedOption[e.target.name].margin = Number(e.target.value)
    setSelectedOption(selectedOption)
  }
  
  const onInputChangeRadio =(e) => {
    deal_bidder[e.target.name].onlydeal = e.target.value == false? 0: 1
    if(onlydeal == false)setonlydeal(true)
    else setonlydeal(false)
    setDeal_bidder(deal_bidder)
    selectedOption[e.target.name].onlydeal = e.target.value == false? 0: 1
    
    setSelectedOption(selectedOption)
  }
  
  return (
    <>

      <div align="left" className={styles.container}><h4>{id ? <>Update Deal</> : <> Create New Deal</>}</h4></div>

      <div className="container-fluid">
        <div className="row">
          <div className="col-md-12">
            <Form onSubmit={(e) => onSubmit(e)}>
              <div>
                <fieldset>
                  <legend>Deal Setting</legend>
                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right">Deal Name</label>
                    <div className="col-sm-4">
                      <Form.Control
                        className="form-control customInput"
                        type="text"
                        name="name"
                        value={deals.name || ""}
                        onChange={(e) => onInputChange(e)}
                      />
                      <p className='formErrors'>{validation.name}</p> 
                    </div>
                  </Form.Group>

                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right">Package</label>
                    <div className="col-sm-8">
                      <Select
                        className="basic-single"
                        classNamePrefix="select"
                        isLoading={false}
                        value={defaultData[0]}
                        isClearable={false} 
                        isSearchable={true}
                        name="pack_id"
                        onChange={(e) => onInputChangePack(e)}
                        isRtl={false}
                        options={data}
                      />
                      <p className='formErrors'>{validation.pack_id}</p> 
                    </div>
                  </Form.Group>

                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right mt-2">
                      Auction Type
                    </label>

                    <div className="col text-left">
                      <div className="form-check">
                        <label className="form-check-label">
                          <input
                            type="radio"
                            className="form-check-input"
                            name="auction_price_type"
                            onChange={(e) => onInputChangeAuctionType(e)}
                            onClick={() => setVisible(false)}
                            value="nonfixed"
                            checked={deals.auction_price_type == "nonfixed"}
                          />
                          Non-Fixed Price
                          <i className="input-helper"></i>
                        </label>
                      </div>
                      
                      <div className="form-check ml-3">
                        <div className="row">
                          <div className="col-sm-2">
                              <label className="form-check-label ml-3">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="auction_price_type"
                                onChange={(e) => onInputChangeAuctionType(e)}
                                onClick={() => setVisible(true)}
                                value="fixed"
                                checked={deals.auction_price_type == "fixed"}
                              />
                              Fixed Price
                              <i className="input-helper"></i>
                            </label>
                          </div>

                          <div className="col-sm-3">
                            {visible && (
                            <Form.Group>
                                <div className="input-group">
                                  <Form.Control
                                    type="number"
                                    min="0"
                                    className="form-control customInput"
                                    placeholder="0.00"
                                    name="price"
                                    value={price || ""}
                                    onChange={(e) => onInputChange(e)} />
                                  <div className="input-group-prepend">
                                    <span
                                      style={{
                                        borderRadius: "0px 5px 5px 0px",
                                      }}
                                      className="input-group-text"
                                    >
                                      $
                                    </span>
                                  </div>
                                  
                                </div>
                                <p className='formErrors'>{validation.price}</p>
                          </Form.Group>
                          )}
                          </div>

                        </div>
                        

                          
                      </div>
                      
                    </div>
                  </Form.Group>

                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right mt-2">
                      Bidders
                    </label>

                    <div className="col text-left">
                      <div className="form-check">
                        <label className="form-check-label">
                          <input
                            type="radio"
                            className="form-check-input"
                            name="bidders_option"
                            value="allBidder"
                            onClick={() => setBidderShow(false)}
                            onChange={(e) => onInputChange(e)}
                            checked={deals.bidders_option == "allBidder"}
                          />
                          Available to all bidders
                          <i className="input-helper"></i>
                        </label>
                      </div>

                      <div className="form-check">
                        <label className="form-check-label">
                          <input
                            type="radio"
                            className="form-check-input"
                            name="bidders_option"
                            value="selected_bidder"
                            onClick={() => setBidderShow(true)}
                            onChange={(e) => onInputChange(e)}
                            checked={deals.bidders_option == "selected_bidder"}
                            // defaultChecked
                          />
                          Available to selected bidders
                          <i className="input-helper"></i>
                        </label>
                      </div>
                      {bidderShow && (
                        <Form.Group className="row">
                          {/* <label className="col-sm-2 col-form-label"> </label> */}
                          <div
                            className="col-sm-10"
                            style={{ marginLeft: "0px" }}
                          >
                             <Select
                              isMulti
                              options={query}
                              className="basic-multi-select"
                              classNamePrefix="select"
                              onChange={(e) => mymultiselect(e)}
                              isLoading={false}
                              value={defaultDataForMulti}
                              isClearable={false} 
                              isSearchable={true}
                              isRtl={false}
                            />

                          </div>

                          {/* create new div on select  */}
                          <div>
                            {selectedOption == null ? (
                              ""
                            ) : (
                              <div>
                                {selectedOption.map((item,i) => (
                                  <div>
                                    <div
                                      className="row mt-4"
                                      style={{ marginLeft: "0px" }}
                                    >
                                      <div className="col-sm-9">
                                        {item.label}
                                      </div>
                                      <div className="col-sm-3 text-right">
                                        {/* <Form.Control
                                          className="form-control customInput"
                                          type="text"
                                          name={i}
                                          value={item?.margin}
                                          onChange={(e) => marginInput(e)}
                                        /> */}

                                        <Form.Group>
                                            <div className="input-group">
                                              <Form.Control
                                                type="number"
                                                min="0"
                                                className="form-control customInput"
                                                placeholder="0.00"
                                                name={i}
                                                value={item?.margin}
                                                onChange={(e) => marginInput(e)} />
                                              <div className="input-group-prepend">
                                                <span
                                                  style={{
                                                    borderRadius: "0px 5px 5px 0px",
                                                  }}
                                                  className="input-group-text"
                                                >
                                                  $
                                                </span>
                                              </div>
                                            </div>
                                      </Form.Group>


                                      </div>
                                      {item.value == "96155bbc-4d01-404a-b8a3-d17ec9403e81" ? (
                                        <div className="col text-left">
                                          <div className="form-check">
                                            <label className="form-check-label">
                                              <input
                                                type="radio"
                                                className="form-check-input"
                                                name={i}
                                                onChange={e => onInputChangeRadio(e)}
                                                value={0}
                                                checked={ onlydeal == 0 ? true: false  }
                                                // value="true"
                                              />
                                              Send only Deal ID based auctions
                                              <i className="input-helper"></i>
                                            </label>
                                          </div>

                                          <div className="form-check">
                                            <label className="form-check-label">
                                              <input
                                                type="radio"
                                                className="form-check-input"
                                                name={i}
                                                onChange={e => onInputChangeRadio(e)}
                                                value={1}
                                                checked={ onlydeal == 1 ? true: false}
                                              />
                                              Send both Deal ID based auctions
                                              and open auctions
                                              <i className="input-helper"></i>
                                            </label>
                                          </div>
                                        </div>
                                      ) : (
                                        ""
                                      )}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                          {/* create new div on select  */}
                        </Form.Group>
                      )}
                    </div>
                  </Form.Group>

                  <Form.Group className="row mb-3">
                    <label className="col-sm-2 col-form-label text-right">
                      Seat ID
                    </label>
                    <div className="col-sm-6">
                      <Form.Control
                        className="form-control customTextarea"
                        type="text"
                        as="textarea"
                        name="seat_id"
                        value={seat_id || ""}
                        onChange={(e) => onInputChange(e)}
                        rows="4"
                        placeholder="Seat ID is optional. Use it when the bidder is running an auction with many bidders on their end. One value per line."
                        row={3}
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right mt-2">
                      Deal Type
                    </label>

                    <div className="col text-left">
                      <div className="form-check">
                        <div className="row" >
                          <div className="col-sm-3 ml-3" style={{flex:"0 0 19%"}}>
                            <label className="form-check-label ml-3">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="deal_type"
                                onClick={() => setDealTypeShow(true)}
                                onChange={(e) => onInputChangeDealType(e)}
                                checked={deals.deal_type == "guaranteed"}
                                value="guaranteed"
                              />
                              Advertiser Guaranteed
                              <i className="input-helper"></i>
                            </label>
                        </div>
                        <div className="col-sm-7">
                          {dealTypeShow && (


                            <Form.Group>
                          
                            <div className="row" style={{  marginTop:"-7px" }}>
                                <div className="col-md-3 text-right mt-1">
                                  <p>Price (in CPM):</p>
                                </div>
                                <div className="col-md-4">
                                  <Form.Group>
                                    <div className="input-group">
                                      <Form.Control
                                        type="number"
                                        min="0"
                                        className="form-control customInput"
                                        placeholder="0.00"
                                        name="targetimpression"
                                        value={targetimpression || ""}
                                        onChange={e => onInputChangeDealType(e)} />
                                      <div className="input-group-prepend">
                                        <span
                                          style={{
                                            borderRadius: "0px 5px 5px 0px",
                                          }}
                                          className="input-group-text"
                                        >
                                          $
                                        </span>
                                      </div>
                                    </div>
                                    <p className='formErrors' style={{marginBottom:"-13px"}}>{validation.targetimpression}</p>
                                  </Form.Group>
                                  
                                </div>
                              </div>


                          </Form.Group>
                          )}
                          </div>
                        </div>
                      </div>

                      <div className="form-check">
                        <label className="form-check-label">
                          <input
                            type="radio"
                            className="form-check-input"
                            onClick={() => setDealTypeShow(false)}
                            name="deal_type"
                            onChange={(e) => onInputChangeDealType(e)}
                            checked={deals.deal_type == "nonguaranteed"}
                            value="nonguaranteed"
                          />
                          Non-Guaranteed
                          <i className="input-helper"></i>
                        </label>
                      </div>
                    </div>
                  </Form.Group>

                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right">Start Date</label>
                    <div className="col-sm-2">
                      <DatePicker
                        // required
                        selected={startDate}
                        value={start_date || ""}
                        dateFormat="yyyy-MM-dd"
                        onChange={e => onInputChangeStartDate(e)}
                        className="form-control customInput"
                      />
                      <p className='formErrors'>{validation.start_date}</p> 
                    </div>
                    <div className="col-sm-2">
                      <select className="form-control customDropDown" name="startHM" onChange={e => onInputChange(e)} style={{width:"80px"}}>
                            <option selected={deals.startHM == "00:00"} value="00:00">00:00</option>
                            <option selected={deals.startHM == "00:30"} value="00:30">00:30</option>
                            <option selected={deals.startHM == "01:00"} value="01:00">01:00</option>
                            <option selected={deals.startHM == "01:30"} value="01:30">01:30</option>
                            <option selected={deals.startHM == "02:00"} value="02:00">02:00</option>
                            <option selected={deals.startHM == "02:30"} value="02:30">02:30</option>
                            <option selected={deals.startHM == "03:00"} value="03:00">03:00</option>
                            <option selected={deals.startHM == "03:30"} value="03:30">03:30</option>
                            <option selected={deals.startHM == "04:00"} value="04:00">04:00</option>
                            <option selected={deals.startHM == "04:30"} value="04:30">04:30</option>
                            <option selected={deals.startHM == "05:00"} value="05:00">05:00</option>
                            <option selected={deals.startHM == "05:30"} value="05:30">05:30</option>
                            <option selected={deals.startHM == "06:00"} value="06:00">06:00</option>
                            <option selected={deals.startHM == "06:30"} value="06:30">06:30</option>
                            <option selected={deals.startHM == "07:00"} value="07:00">07:00</option>
                            <option selected={deals.startHM == "07:30"} value="07:30">07:30</option>
                            <option selected={deals.startHM == "08:00"} value="08:00">08:00</option>
                            <option selected={deals.startHM == "08:30"} value="08:30">08:30</option>
                            <option selected={deals.startHM == "09:00"} value="09:00">09:00</option>
                            <option selected={deals.startHM == "09:30"} value="09:30">09:30</option>
                            <option selected={deals.startHM == "10:00"} value="10:00">10:00</option>
                            <option selected={deals.startHM == "10:30"} value="10:30">10:30</option>
                            <option selected={deals.startHM == "11:00"} value="11:00">11:00</option>
                            <option selected={deals.startHM == "11:30"} value="11:30">11:30</option>
                            <option selected={deals.startHM == "12:00"} value="12:00">12:00</option>
                            <option selected={deals.startHM == "12:30"} value="12:30">12:30</option>
                            <option selected={deals.startHM == "13:00"} value="13:00">13:00</option>
                            <option selected={deals.startHM == "13:30"} value="13:30">13:30</option>
                            <option selected={deals.startHM == "14:00"} value="14:00">14:00</option>
                            <option selected={deals.startHM == "14:30"} value="14:30">14:30</option>
                            <option selected={deals.startHM == "15:00"} value="15:00">15:00</option>
                            <option selected={deals.startHM == "15:30"} value="15:30">15:30</option>
                            <option selected={deals.startHM == "16:00"} value="16:00">16:00</option>
                            <option selected={deals.startHM == "16:30"} value="16:30">16:30</option>
                            <option selected={deals.startHM == "17:00"} value="17:00">17:00</option>
                            <option selected={deals.startHM == "17:30"} value="17:30">17:30</option>
                            <option selected={deals.startHM == "18:00"} value="18:00">18:00</option>
                            <option selected={deals.startHM == "18:30"} value="18:30">18:30</option>
                            <option selected={deals.startHM == "19:00"} value="19:00">19:00</option>
                            <option selected={deals.startHM == "19:30"} value="19:30">19:30</option>
                            <option selected={deals.startHM == "20:00"} value="20:00">20:00</option>
                            <option selected={deals.startHM == "20:30"} value="20:30">20:30</option>
                            <option selected={deals.startHM == "21:00"} value="21:00">21:00</option>
                            <option selected={deals.startHM == "21:30"} value="21:30">21:30</option>
                            <option selected={deals.startHM == "22:00"} value="22:00">22:00</option>
                            <option selected={deals.startHM == "22:30"} value="22:30">22:30</option>
                            <option selected={deals.startHM == "23:00"} value="23:00">23:00</option>
                            <option selected={deals.startHM == "23:30"} value="23:30">23:30</option>
                            <option selected={deals.startHM == "24:00"} value="24:00">24:00</option>
                      </select>
                    </div>
                  </Form.Group>

                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right mt-2">End Date</label>

                    <div className="col text-left">
                      <div className="form-check">
                        <label className="form-check-label">
                          <input
                            type="radio"
                            className="form-check-input"
                            name="onGoing"
                            onClick={() => setEndDateShow(false)}
                            onChange={(e) => onInputChangeEndDate(e)}
                            checked={deals.onGoing == 1}
                            value={1}
                          />
                          On-going
                          <i className="input-helper"></i>
                        </label>
                      </div>

                      <div className="form-check ml-3">
                        <div className="row">
                          <div className="col-sm-3" style={{flex:"0 0 19%"}}>
                            <label className="form-check-label ml-3">
                            <input
                              type="radio"
                              className="form-check-input"
                              name="onGoing"
                              onClick={() => setEndDateShow(true)}
                              onChange={(e) => onInputChangeEndDate(e)}
                              checked={deals.onGoing == 0}
                              value={0}
                            />
                            End on this date
                            <i className="input-helper"></i>
                          </label>
                          </div>
                        
                        <div className="col-sm-6">

                              {endDateShow && (
                              <Form.Group className="row">
                                {/* <label className="col-sm-2 col-form-label"> </label> */}
                                <div
                                  className="col-sm-5"
                                  style={{ marginLeft: "0px", marginTop:"-8px" }}
                                >
                                  <DatePicker
                                  key="example9"
                                    name="end_date"
                                    selected={endDate}
                                    value={end_date || ""}
                                    dateFormat="yyyy-MM-dd"
                                    onChange={e => onInputChangeEndDateFormat(e)}
                                    className="form-control customInput"
                                  />
                                  <p className='formErrors'>{validation.end_date}</p> 
                                </div>
                                <div className="col-sm-2">
                      <select className="form-control customDropDown" name="endHM" onChange={e => onInputChange(e)} style={{width:"80px", marginTop:"-8px"}}>
                            <option selected={deals.endHM == "00:00"} value="00:00">00:00</option>
                            <option selected={deals.endHM == "00:30"} value="00:30">00:30</option>
                            <option selected={deals.endHM == "01:00"} value="01:00">01:00</option>
                            <option selected={deals.endHM == "01:30"} value="01:30">01:30</option>
                            <option selected={deals.endHM == "02:00"} value="02:00">02:00</option>
                            <option selected={deals.endHM == "02:30"} value="02:30">02:30</option>
                            <option selected={deals.endHM == "03:00"} value="03:00">03:00</option>
                            <option selected={deals.endHM == "03:30"} value="03:30">03:30</option>
                            <option selected={deals.endHM == "04:00"} value="04:00">04:00</option>
                            <option selected={deals.endHM == "04:30"} value="04:30">04:30</option>
                            <option selected={deals.endHM == "05:00"} value="05:00">05:00</option>
                            <option selected={deals.endHM == "05:30"} value="05:30">05:30</option>
                            <option selected={deals.endHM == "06:00"} value="06:00">06:00</option>
                            <option selected={deals.endHM == "06:30"} value="06:30">06:30</option>
                            <option selected={deals.endHM == "07:00"} value="07:00">07:00</option>
                            <option selected={deals.endHM == "07:30"} value="07:30">07:30</option>
                            <option selected={deals.endHM == "08:00"} value="08:00">08:00</option>
                            <option selected={deals.endHM == "08:30"} value="08:30">08:30</option>
                            <option selected={deals.endHM == "09:00"} value="09:00">09:00</option>
                            <option selected={deals.endHM == "09:30"} value="09:30">09:30</option>
                            <option selected={deals.endHM == "10:00"} value="10:00">10:00</option>
                            <option selected={deals.endHM == "10:30"} value="10:30">10:30</option>
                            <option selected={deals.endHM == "11:00"} value="11:00">11:00</option>
                            <option selected={deals.endHM == "11:30"} value="11:30">11:30</option>
                            <option selected={deals.endHM == "12:00"} value="12:00">12:00</option>
                            <option selected={deals.endHM == "12:30"} value="12:30">12:30</option>
                            <option selected={deals.endHM == "13:00"} value="13:00">13:00</option>
                            <option selected={deals.endHM == "13:30"} value="13:30">13:30</option>
                            <option selected={deals.endHM == "14:00"} value="14:00">14:00</option>
                            <option selected={deals.endHM == "14:30"} value="14:30">14:30</option>
                            <option selected={deals.endHM == "15:00"} value="15:00">15:00</option>
                            <option selected={deals.endHM == "15:30"} value="15:30">15:30</option>
                            <option selected={deals.endHM == "16:00"} value="16:00">16:00</option>
                            <option selected={deals.endHM == "16:30"} value="16:30">16:30</option>
                            <option selected={deals.endHM == "17:00"} value="17:00">17:00</option>
                            <option selected={deals.endHM == "17:30"} value="17:30">17:30</option>
                            <option selected={deals.endHM == "18:00"} value="18:00">18:00</option>
                            <option selected={deals.endHM == "18:30"} value="18:30">18:30</option>
                            <option selected={deals.endHM == "19:00"} value="19:00">19:00</option>
                            <option selected={deals.endHM == "19:30"} value="19:30">19:30</option>
                            <option selected={deals.endHM == "20:00"} value="20:00">20:00</option>
                            <option selected={deals.endHM == "20:30"} value="20:30">20:30</option>
                            <option selected={deals.endHM == "21:00"} value="21:00">21:00</option>
                            <option selected={deals.endHM == "21:30"} value="21:30">21:30</option>
                            <option selected={deals.endHM == "22:00"} value="22:00">22:00</option>
                            <option selected={deals.endHM == "22:30"} value="22:30">22:30</option>
                            <option selected={deals.endHM == "23:00"} value="23:00">23:00</option>
                            <option selected={deals.endHM == "23:30"} value="23:30">23:30</option>
                            <option selected={deals.endHM == "24:00"} value="24:00">24:00</option>
                      </select>
                    </div>
                              </Form.Group>
                              
                            )}
                          </div>
                        </div>
                      </div>
                      
                    </div>
                  </Form.Group>
                </fieldset>
              </div>
              <Form.Group className="row mt-4">
                <label className="col-sm-2 col-form-label text-right"></label>
                <div className="col-sm-9 ml-2">
                  <button
                    type="submit"
                    className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                  >
                    {id ? <>Update</> : <> Save</>}
                    <FontAwesomeIcon icon="save" />
                  </button>
                </div>
              </Form.Group>
            </Form>
          </div>
        </div>
      </div>
    </>
  );

  function newFunction(getValue) {
    console.log(getValue);
  }
}

export default AddEditDeals;
