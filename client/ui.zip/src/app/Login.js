import React, { useState, useContext } from 'react';
import { Form,Row, Col , Button} from 'react-bootstrap';
import axios from 'axios';
// import {AuthContext} from "../helpers/AuthContext"
import {AuthContext} from "../helpers/AuthContext"
import { useHistory } from 'react-router-dom';
import logo from '../assets/images/admin-logo-login.png'
//import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Login() {

  let history = useHistory();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const {setAuthState} = useContext(AuthContext)

  const login = () => {
    const data = { username: username, password: password };
    axios.post("http://localhost:5000/auth/login", data).then((response) => {
      console.log("response.data : " +  response.data)
      console.log("response.data.username : " +  response.data.username)
      
      if (response.data.error){
        alert(response.data.error);

      }else{
        localStorage.setItem("accessToken", response.data.token)
          setAuthState({
            username: response.data.username,
            id: response.data.id,
            status: true,
          });
          history.push("/advertiser/advertisers");
      }
    })
    
  };



    return (
      <div>
        <div className="d-flex align-items-center auth px-0" style={{marginLeft: "-260px"}}>
          <div className="row w-100 mx-0">
            <div className="mx-auto">
            <div className="brand-logo">
                  <img src={logo} alt="logo" />
                </div>
              <div className="auth-form-light text-left py-5 px-4 px-sm-5">
                
                <h4 className="text-center login-text">Welcome Admin</h4>
                
                <Form className="pt-3">
                  
                  <div className="mt-3 text-center">
                  <Form>

                    <Form.Group as={Row} className="mb-3">
                      
                      <Form.Label column sm="2">
                        Email
                      </Form.Label>
                      
                      <Col sm="10">
                        <Form.Control type='text' 
                           onChange={(event) => {
                            setUsername(event.target.value);
                          }}
                        />
                      </Col>

                    </Form.Group>

                    <Form.Group as={Row} className="mb-3">

                      <Form.Label column sm="2">
                        Password
                      </Form.Label>
                      
                      <Col sm="10">
                        <Form.Control type="password"
                          onChange={(event) => {
                            setPassword(event.target.value);
                          }}
                        />
                      </Col>

                    </Form.Group>

                    <Button variant="primary" onClick={login} className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg">
                      Sign In
                    </Button>

                  </Form>
                  </div>
                 
                </Form>
              </div>
            </div>
          </div>
        </div>  
      </div>
    )
  }
// }

export default Login
