export const API_URL = "http://localhost:5000";
export const ADVERTISER_DASHBOARD = "http://localhost:3001";