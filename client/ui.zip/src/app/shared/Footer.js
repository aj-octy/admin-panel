import React, { Component } from 'react';

class Footer extends Component {
  getYear() {
    return new Date().getFullYear();
}
  render () {
    return (
      <footer className="footer">
        <div className="d-sm-flex justify-content-center ">
          <span className="text-muted text-center ">
             <p style={{color:"#6c6b6b"}}>Copyright © {this.getYear()} Vdopia. All Rights Reserved. | <a href='#'>Home</a></p> </span>
             {/* <span><p href="https://chocolateplatform.com/" target="_blank" rel="noopener noreferrer">Copyright © {this.getYear()} Vdopia. All Rights Reserved. | Home</p></span> */}
        </div>
      </footer> 
    );
  }
}

export default Footer;