import React, { Component } from "react";
import { Link, withRouter } from "react-router-dom";
import { Collapse } from "react-bootstrap";
// import { Trans } from "react-i18next";

class Sidebar extends Component {
  state = {};

  toggleMenuState(menuState) {
    if (this.state[menuState]) {
      this.setState({ [menuState]: false });
    } else if (Object.keys(this.state).length === 0) {
      this.setState({ [menuState]: true });
    } else {
      Object.keys(this.state).forEach((i) => {
        this.setState({ [i]: false });
      });
      this.setState({ [menuState]: true });
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.location !== prevProps.location) {
      this.onRouteChanged();
    }
  }

  onRouteChanged() {
    document.querySelector("#sidebar").classList.remove("active");
    Object.keys(this.state).forEach((i) => {
      this.setState({ [i]: false });
    });

    const dropdownPaths = [
      
      { path: "/advertiser", state: "advertisersMenuOpen" },

      { path: "/publisher", state: "publishersMenuOpen" },

      { path: "/user-pages", state: "userPagesMenuOpen" },

      { path: "/tools", state: "toolsPagesMenuOpen" },

      
    ];

    dropdownPaths.forEach((obj) => {
      if (this.isPathActive(obj.path)) {
        this.setState({ [obj.state]: true });
      }
    });
  }

  render() {
    return (
      <nav className="sidebar sidebar-offcanvas" id="sidebar">
        <ul className="nav">

          
          {/* Advertisers */}
          <li className={this.isPathActive("/advertiser") ? "nav-item active" : "nav-item"} >
            <div className={ this.state.advertisersMenuOpen ? "nav-link menu-expanded" : "nav-link" } onClick={() => this.toggleMenuState("advertisersMenuOpen")} data-toggle="collapse" > 
            <span className="menu-title"> Advertiser </span> <i className="menu-arrow"></i>
            <i className="mdi mdi-account-multiple menu-icon"></i></div>
            <Collapse in={this.state.advertisersMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={ this.isPathActive("/advertiser/advertisers") ? "nav-link active" : "nav-link" } to="/advertiser/advertisers" > Advertiser  </Link> </li>             
              </ul>
            </Collapse>
          </li>
          

          
          <li className={ this.isPathActive("/publisher") ? "nav-item active" : "nav-item"  } >
            <div className={ this.state.publishersMenuOpen ? "nav-link menu-expanded" : "nav-link" } onClick={() => this.toggleMenuState("publishersMenuOpen")}  data-toggle="collapse">
              <span className="menu-title">publisher</span><i className="menu-arrow"></i>
              <i className="mdi mdi-laptop-windows menu-icon"></i> </div>
            <Collapse in={this.state.publishersMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"><Link className={ this.isPathActive("/publisher/publishers") ? "nav-link active" : "nav-link" } to="/publisher/publishers" > Publishers  </Link> </li>
                
              </ul>
            </Collapse>
          </li>


          <li className={ this.isPathActive("/tools") ? "nav-item active" : "nav-item" } >
            <div  className={ this.state.toolsPagesMenuOpen ? "nav-link menu-expanded" : "nav-link" } onClick={() => this.toggleMenuState("toolsPagesMenuOpen")} data-toggle="collapse" >
              <span className="menu-title">Tools</span><i className="menu-arrow"></i> <i className="mdi mdi-wrench menu-icon"></i>
                
            </div>
            
            <Collapse in={this.state.toolsPagesMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={ this.isPathActive('/tools/ManagePackagesAndDeals') || this.isPathActive("/tools/AddEditDeals") || this.isPathActive("/tools/AddEditPackages") ? 'nav-link active' : 'nav-link' } to="/tools/ManagePackagesAndDeals">Packages & Deals </Link></li>
              </ul>
            </Collapse>
          </li>
          

          

          {/* <li className={ this.isPathActive("/login") ? "nav-item active" : "nav-item" } >
            <div className={ this.state.userPagesMenuOpen ? "nav-link menu-expanded" : "nav-link" } onClick={() => this.toggleMenuState("userPagesMenuOpen")} data-toggle="collapse" >
              <span className="menu-title"> User Pages </span> <i className="menu-arrow"></i> <i className="mdi mdi-lock menu-icon"></i> </div>
            <Collapse in={this.state.userPagesMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={ this.isPathActive("/login") ? "nav-link active" : "nav-link" }  to="/login"> Login </Link> </li>
                <li className="nav-item"> <Link className={ this.isPathActive("/registration") ? "nav-link active" : "nav-link" } to="/registration" > Registration </Link> </li>
              </ul>
            </Collapse>
          </li> */}

          
        </ul>
      </nav>
    );
  }

  isPathActive(path) {
    return this.props.location.pathname.startsWith(path);
  }

  componentDidMount() {
    this.onRouteChanged();
    // add class 'hover-open' to sidebar navitem while hover in sidebar-icon-only menu
    const body = document.querySelector("body");
    document.querySelectorAll(".sidebar .nav-item").forEach((el) => {
      el.addEventListener("mouseover", function () {
        if (body.classList.contains("sidebar-icon-only")) {
          el.classList.add("hover-open");
        }
      });
      el.addEventListener("mouseout", function () {
        if (body.classList.contains("sidebar-icon-only")) {
          el.classList.remove("hover-open");
        }
      });
    });
  }
}

export default withRouter(Sidebar);
