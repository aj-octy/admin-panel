// import Header from  './Header'
import React,{useState,useEffect} from 'react'
import { withRouter } from 'react-router-dom'
import {Col,Row,Container, Button} from 'react-bootstrap'

// import DynamicIFilterConfigurationSettings from '../tools/DynamicIFilterConfigurationSettings'

function Editifilter(){

const [id , setId] = useState();
const [name, setName] = useState("");
const [email,setEmail] = useState("");
const [body,setBody] = useState("");
const [postId,setpostId] = useState("");

const changeHandleEmail = e => {
    setEmail(e.target.value)
}

const changeHandleName = e => {
    setName(e.target.value)
}

const changeHandleBody = e => {
    setBody(e.target.value)
}

const changeHandlepostId = e => {
    setpostId(e.target.value)
}








useEffect(() => {
  setId ( localStorage.getItem("id"))
  setName ( localStorage.getItem("name"))
  setEmail ( localStorage.getItem("email"))
  setBody ( localStorage.getItem("body"))
  setpostId ( localStorage.getItem("postId"))
  

},[])

// changeHandler((e) => {
//     setState({[e.target.name]: e.target.value});
// })


console.log("id:+++++++++++++++"+id);
console.log("name:+++++++++++++++"+name);
console.log("body:+++++++++++++++"+body);
// console.log("name:+++++++++++++++"+name);



    
    return(
        <>
        <div>
            <h3>Edit Existing IFilter</h3>
            <br />
            <fieldset>
                <legend>Deal Settings</legend>
            </fieldset>
        </div><br /><br /><Container>
                <Row xs="auto">
                    <Col>


                        <label class="control-label">

                            <label>Enter your Email
                                <i class="text-error">*</i>
                            </label>
                        </label>

                    </Col>
                    <Col>
                        <input
                            //   onChange={(e)=>handle(e)} id="name" value={data.name} 
                            style={{ width: "400px" }} className="form-control"  type="text" placeholder="Enter Email..." value={email} onChange={changeHandleEmail} />
                    </Col>


                </Row>
            </Container><br /><Container>
                <Row xs="auto">
                    <Col>
                        <label class="control-label">
                            <label>Enter  Product ID
                                <i class="text-error">*</i>
                            </label>
                        </label>
                    </Col>
                    <Col>
                        <input
                            // onChange={(e)=>handle(e)} id="email" value={data.email} 
                            style={{ width: "400px" }} className="form-control" type="text" value={postId} onChange={changeHandlepostId}     placeholder="Enter Product ID..." aria-label="Search" />
                    </Col>
                </Row>
            </Container><br /><Container>
                <Row xs="auto">
                    <Col>
                        <label class="control-label">
                            <label>Enter  Name
                                <i class="text-error">*</i>
                            </label>
                        </label>
                    </Col>

                    <Col>
                        <input
                            // onChange={(e)=>handle(e)} id="email" value={data.email} 
                            style={{ width: "400px" }} className="form-control" type="text" value={name} placeholder="Enter Name..."  onChange={changeHandleName} aria-label="Search" />

                    </Col>
                </Row>
            </Container><br /><Container>
                <Row xs="auto">
                    <Col>
                        <label class="control-label">
                            <label>Enter  body
                                <i class="text-error">*</i>
                            </label>
                        </label>
                    </Col>

                    <Col>
                        <input
                            // onChange={(e)=>handle(e)} id="email" value={data.email} 
                            style={{ width: "400px" }} className="form-control" type="text" value={body} placeholder="Enter body..." onChange={changeHandleBody} aria-label="Search" />

                    </Col>
                </Row>
            </Container><br /><Button
                type='submit'
                // onClick={()=>this.postData()} 
                style={{ marginLeft: "930px" }} variant="primary" size='sm'
            >
                {/* <i className="mdi mdi-plus menu-icon"></i> */}
                Save

            </Button>{' '} 
            </>
        
       
       
    )
}

export default withRouter(Editifilter)