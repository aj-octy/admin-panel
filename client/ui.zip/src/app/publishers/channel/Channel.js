import React, { useState } from "react";
import { useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import styles from "../../styles.module.css";
import { library } from "@fortawesome/fontawesome-svg-core";
import { faSearch, faPlus } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link } from "react-router-dom";

library.add(faSearch, faPlus);

function Channels() {
  const [data, setData] = useState([]);

  const [name, setName] = useState([]);

  // const [action,setaction]

  useEffect(() => {
    getData();
  }, []);


  const getData = () => {
    axios("http://localhost:5000/channels").then((res) => {
      //console.log(res.data);
      //setData(res.data);
      setData(res.data);
    });
  };


  const handleDelete = (rowId, name) => {
    console.log(rowId, name);
    //1 YourCellName
  };
  const handleEdit = (rowId, name) => {
    console.log(rowId, name);
    //1 YourCellName
  };
  // {

  

  return (
    <>
      <div align="left" className={styles.container}>
        <h4>Connection</h4>
        <div className="row mb-4">
          <div className="col-sm-8">
            <form className="form-inline">
              <input
                className="form-control form-control-md mr-4"
                type="text"
                placeholder="Search Advertisers..."
                aria-label="Search"
                onChange={(e) => {
                  setName(e.target.value);
                }}
              />
              <i class="fa-solid fa-cutlery"></i>
              <button
                type="button"
                className="btn btn-gradient-info btn-rounded btn-icon-text"
              >
                Search
                <FontAwesomeIcon icon="search" />
              </button>
            </form>
          </div>
          <div className="col-sm-4 text-right">
            <Link to={"/supply/AddNewChannel"}>
              <button
                type="button"
                className="btn btn-gradient-info btn-rounded btn-icon-text"
              >
                Create
                <FontAwesomeIcon icon="plus" />
              </button>
            </Link>
          </div>
        </div>
      </div>

    </>
  );
}

export default Channels;
