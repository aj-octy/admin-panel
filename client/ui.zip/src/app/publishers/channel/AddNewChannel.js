import React, { useState } from 'react'
import styles from "../../styles.module.css";
import { Form, Row, Col, Container } from "react-bootstrap";
import {Button} from 'react-bootstrap';
import { library } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSave } from "@fortawesome/free-solid-svg-icons";

library.add(faSave);


function AddNewChannel() {

    const[visible,setVisible]=useState(false);

    const[inputFields, setInputField]=useState([
        {firstname : '',lastname : ''},
    ]);

    const handleAddFields=event=>{
        event.preventDefault()
        setInputField([...inputFields,{firstname : '',lastname : ''}])
    }

    const handleRemoveFields=(index)=>{
        // event.preventDefault()
        const values=[...inputFields];
        values.splice(index,1);
        setInputField(values);
    }

    return (
      <div>
          <div align="left" className={styles.container}>
                <h3>Add Channel</h3>
          </div>
          <div className='container-fluid'>
              <div className='row'>
                    <div className='col-md-12'>
                        <Form>
                            <div>
                                <fieldset>
                                    <legend>
                                        Channel Details
                                        <i class="text-error">*</i>
                                    </legend>
                                    
                                    <Form.Group className="row">
                                        
                                    <label className="col-sm-3 col-form-label text-right">
                                     Channel Name
                                     <i class="text-error">*</i>
                                    </label>
                                    
                                    <div className="col-sm-4">
                                    <Form.Control
                                    className="form-control customInput"
                                    type="text"
                                    />
                                    </div>
                                    </Form.Group>
                            
                                    <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                     Marketing Name
                                     <i class="text-error">*</i>
                                    </label>
                                    <div className="col-sm-4">
                                    <Form.Control
                                    className="form-control customInput"
                                    type="text"
                                    />
                                    <Form.Text id="passwordHelpBlock" muted>
                            (Name that will show up to the Buyer.Ex:- App123)
                        </Form.Text>
                                    </div>
                                    </Form.Group>
                                    <br/>
                                    <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    Is Desktop
                                    </label>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType"
                                            id="membershipRadios1"
                                            defaultChecked
                                            onClick={()=>setVisible(true)}
                                        />{" "}
                                        Yes
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-4">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType"
                                            id="membershipRadios2"
                                            onClick={()=>setVisible(false)}
                                        />{" "}
                                        No
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    Channel Type
                                    <i class="text-error">*</i>
                                    </label>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType1"
                                            id="membershipRadios3"
                                            defaultChecked
                                        />{" "}
                                        Site
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    { visible &&
                                    <div className="col-md-4">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType1"
                                            id="membershipRadios4"
                                        />{" "}
                                        App
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>
                                    }
                                </Form.Group>
                                    { visible &&
                                    <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                     Site Domain
                                     <i class="text-error">*</i>
                                    </label>
                                    
                                    <div className="col-sm-4">
                                    <Form.Control
                                    className="form-control customInput"
                                    type="text"
                                    />
                                    <Form.Text id="passwordHelpBlock" muted>
                                    (required for Site)<br/>
                                    (should follow the format â€œabc.comâ€)
                                    </Form.Text>
                                    </div>
                                    
                                    </Form.Group>
                                    }
                                    <br/>
                                    <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                     App Bundle ID
                                     <i class="text-error">*</i>
                                    </label>
                                    
                                    <div className="col-sm-4">
                                    <Form.Control
                                    className="form-control customInput"
                                    type="text"
                                    />
                                    <Form.Text id="passwordHelpBlock" muted>
                                    (required for App)<br/>
                                    (For Android: provide the package name : e.g. com.foo.mygame.)<br/>
                                    (For iOS: provide the bundle ID e.g. 373416293)     
                                    </Form.Text>
                                    </div>
                                    </Form.Group>
                                    <br/>
                                    <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    App Store URL/Site Page URL 
                                     <i class="text-error">*</i>
                                    </label>
                                    
                                    <div className="col-sm-4">
                                    <Form.Control
                                    className="form-control customInput"
                                    type="text"
                                    />
                                    <Form.Text id="passwordHelpBlock" muted>
                                    (Sites: Provide the URL of the page where the impression will be shown)<br/>
                                    (Apps: Provide the App Store URL)     
                                    </Form.Text>
                                    </div>
                                    </Form.Group>
                                    <br/>
                                    <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    Skippable
                                    </label>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType2"
                                            id="membershipRadios1"
                                            defaultChecked
                                        />{" "}
                                        Yes
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-4">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType2"
                                            id="membershipRadios2"
                                        />{" "}
                                        No
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    Sound
                                    </label>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType3"
                                            id="membershipRadios1"
                                            defaultChecked
                                        />{" "}
                                        On
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-4">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType3"
                                            id="membershipRadios2"
                                        />{" "}
                                        Off
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    Auto-Play
                                    </label>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType4"
                                            id="membershipRadios1"
                                            defaultChecked
                                        />{" "}
                                        Yes
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-4">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType4"
                                            id="membershipRadios2"
                                        />{" "}
                                        No
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    Incentivized 
                                    </label>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType5"
                                            id="membershipRadios1"
                                            defaultChecked
                                        />{" "}
                                        Yes
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-4">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType5"
                                            id="membershipRadios2"
                                        />{" "}
                                        No
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    In-Stream
                                    </label>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType6"
                                            id="membershipRadios1"
                                            defaultChecked
                                        />{" "}
                                        Yes
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-4">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType6"
                                            id="membershipRadios2"
                                        />{" "}
                                        No
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    Clickable
                                    </label>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType7"
                                            id="membershipRadios1"
                                            defaultChecked
                                        />{" "}
                                        Yes
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-4">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType7"
                                            id="membershipRadios2"
                                        />{" "}
                                        No
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    Integration Type
                                    </label>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType8"
                                            id="membershipRadios1"
                                            defaultChecked
                                        />{" "}
                                        Chocolate SSP
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType8"
                                            id="membershipRadios2"
                                        />{" "}
                                        Vdopia Direct
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType8"
                                            id="membershipRadios2"
                                        />{" "}
                                            Mediation Direct
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType8"
                                            id="membershipRadios2"
                                        />{" "}
                                        Indirect
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    Technical Integration Type
                                    </label>

                                    <div className="col-md-3">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType9"
                                            id="membershipRadios1"
                                            defaultChecked
                                        />{" "}
                                        Client To Server(C2S)
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-4">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType9"
                                            id="membershipRadios2"
                                        />{" "}
                                        Server To Server(S2S)
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right">
                                    Video Ad Size
                                    </label>

                                    <div className="col-md-2">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType10"
                                            id="membershipRadios1"
                                            defaultChecked
                                        />{" "}
                                        320*480
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>

                                    <div className="col-md-4">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            name="ionType10"
                                            id="membershipRadios2"
                                        />{" "}
                                        300*250
                                        <i className="input-helper"></i>
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className='row'>
                                <label className="col-sm-3 col-form-label text-right">
                                Supported Creative
                                </label>
                                <div className="col">
                                <div className="form-check">
                                    <label className="form-check-label">
                                    <input type="checkbox" className="form-check-input" />
                                    <i className="input-helper"></i>
                                    VPAID 2.0
                                    </label>
                                </div>
                                </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right"></label>
                                    <div className="col">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input type="checkbox" className="form-check-input" />
                                        <i className="input-helper"></i>
                                        MRAID-1
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-3 col-form-label text-right"></label>
                                    <div className="col">
                                    <div className="form-check">
                                        <label className="form-check-label">
                                        <input type="checkbox" className="form-check-input" />
                                        <i className="input-helper"></i>
                                        MRAID-2
                                        </label>
                                    </div>
                                    </div>
                                </Form.Group>
                                
                                <Form.Group className='row'>
                                <label className="col-sm-3 col-form-label text-right">
                                Coppa
                                </label>
                                <div className="col">
                                <div className="form-check">
                                    <label className="form-check-label">
                                    <input type="checkbox" className="form-check-input" />
                                    <i className="input-helper"></i>
                                    This app or site is directed to children under 13 as defined<br/> by the Children's Online Privacy Protection Act.
                                    </label>
                                </div>
                                </div>
                                </Form.Group>
                                </fieldset>
                                <br/>
                                <fieldset>
                                    <legend>
                                        Floor Price Configuration
                                        <i class="text-error">*</i>
                                    </legend>
                                    <Form.Group>
                                    <Container>
                                            <Row>
                                                <Col align="left">
                                                    <h5>Country</h5>
                                                </Col>
                                                <Col>
                                                    <h5>Ad Type</h5>
                                                </Col>
                                                <Col>
                                                    <h5>Bundle/Domain...</h5>
                                                </Col>
                                                <Col align='center'>
                                                    <h5>Floor Price Type</h5>
                                                </Col>
                                                <Col>
                                                    <h5>Floor Price(in $CPM)</h5>
                                                </Col>
                                                <Col xs="auto"></Col>
                                            </Row>
                                            <br/>
                                            <Row>
                                            <Col xs='2'>
                                                {/* <div className="col-sm-10"> */}
                                                <div>
                                                <Form.Group controlId="formBasicSelect">
                                                    <Form.Control as="select" >
                                                        <option value='US'>US</option>
                                                        <option >India</option>
                                                        <option >Uruguay</option>
                                                        <option >Afghanisthan</option>
                                                        <option >New Zealand</option>
                                                    </Form.Control>
                                                </Form.Group>
                                                </div>
                                                {/* </div> */}
                                                </Col>
                                                <Col xs='2'>
                                                {/* <div className="col-sm-5"> */}
                                                <Form.Group controlId="formBasicSelect1">
                                                    <Form.Control as="select" >
                                                        <option >Video</option>
                                                        <option >Banner</option>
                                                    </Form.Control>
                                                </Form.Group>
                                                {/* </div> */}
                                                </Col>
                                                
                                                <Col xs='3'>
                                                <textarea
                                                    className="form-control customTextarea"
                                                    id="exampleTextarea1"
                                                    rows="3"
                                                ></textarea>
                                                </Col>
                                                <Col xs='2' align='center'>
                                                    Hard Floor <br/><br/><br/>Soft Floor
                                                </Col>
                                                <Col xs='3' align='center'>
                                                {/* <div className="col-md-4"> */}
                                                <Form.Group>
                                                    <div className="input-group">
                                                    <Form.Control
                                                        type="text"
                                                        className="form-control customInput"
                                                        placeholder="e.g.5.0"
                                                    />
                                                    <div className="input-group-prepend">
                                                        <span
                                                        style={{
                                                            borderRadius: "0px 5px 5px 0px",
                                                        }}
                                                        className="input-group-text"
                                                        >
                                                        $
                                                        </span>
                                                    </div>
                                                    </div>
                                                </Form.Group>
                                                <p/>
                                                <Form.Group>
                                                    <div className="input-group">
                                                    <Form.Control
                                                        type="text"
                                                        className="form-control customInput"
                                                        placeholder="e.g.5.0"
                                                    />
                                                    <div className="input-group-prepend">
                                                        <span
                                                        style={{
                                                            borderRadius: "0px 5px 5px 0px",
                                                        }}
                                                        className="input-group-text"
                                                        >
                                                        $
                                                        </span>
                                                    </div>
                                                    </div>
                                                </Form.Group>
                                                {/* </div> */}
                                                </Col>
                                                {/* <Col xs="auto">
                                                </Col> */}
                                            </Row>
                                            <br/>
                                            <Row>
                                            <Col>
                                            <button
                                            type="button"
                                            className="btn btn-gradient-info btn-rounded btn-icon-text"
                                            >Add Row</button>
                                            </Col>
                                            <Col align='right'>
                                            <button
                                            type="button"
                                            className="btn btn-gradient-info btn-rounded btn-icon-text"
                                            >Delete</button>
                                            </Col>
                                            </Row>
                                            <br/>
                                            <Row>
                                                
                                            </Row>
                                    </Container>
                                    </Form.Group>
                                    
                                            
                                </fieldset>
                                <br/>
                                <fieldset>
                                    <legend>Publisher Margin</legend>
                                    <Form.Group>
                                    <Container>
                                            <Row>
                                                <Col xs='7' align="left">
                                                    <h5>Country</h5>
                                                </Col>
                                                
                                                <Col xs='3' align='center'>
                                                    <h5>Margin 0-99 (In %)</h5>
                                                </Col>
                                                
                                                
                                            </Row>
                                            <br/>
                                            <Row>
                                            <Col xs='2'>
                                                
                                                <Form.Group controlId="formBasicSelect">
                                                    <Form.Control as="select" >
                                                        <option value='US'>US</option>
                                                        <option >India</option>
                                                        <option >Uruguay</option>
                                                        <option >Afghanisthan</option>
                                                        <option >New Zealand</option>
                                                    </Form.Control>
                                                </Form.Group>
                                                
                                                </Col>
                                                <Col xs='5' align='center'>
                                                    Publisher Margin
                                                </Col>
                                                
                                                <Col xs='3' align='left'>
                                                <Form.Group>
                                                    <div className="input-group">
                                                    <Form.Control
                                                        type="text"
                                                        className="form-control customInput"
                                                        placeholder="e.g.5.0"
                                                    />
                                                    <div className="input-group-prepend">
                                                        <span
                                                        style={{
                                                            borderRadius: "0px 5px 5px 0px",
                                                        }}
                                                        className="input-group-text"
                                                        >
                                                        $
                                                        </span>
                                                    </div>
                                                    </div>
                                                </Form.Group>
                                                </Col>
                                                <Col xs='2' align='center'>
                                                <button
                                                type="button"
                                                className="btn btn-gradient-info btn-rounded btn-icon-text"
                                                >Add Row
                                                <FontAwesomeIcon icon="fa-save"/>
                                                </button>
                                                </Col>
                                                    
                                                    
                                                {/* <Col xs="auto">
                                                </Col> */}
                                            </Row>
                                            </Container>
                                            </Form.Group>
                                    </fieldset>
                                    <br/>
                                    <fieldset>
                                        <legend>Categories</legend>
                                        <Container>
                                        <Row>
                                            <Col xs='1'/>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Arts & Entertainment
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Automotive
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Business
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Careers
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            
                                        </Row>
                                        <Row>
                                            <Col xs='1'/>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Education
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Family & Parenting
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Food & Drink
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Health & Fitness
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            
                                        </Row>
                                        <Row>
                                            <Col xs='1'/>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Hobbies & Interests
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Home & Garden
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Illegal Content
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Law, Gov't & Politics
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            
                                        </Row>
                                        <Row>
                                            <Col xs='1'/>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                News
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Non-Standard Content
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Personal Finance
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Pets
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            
                                        </Row>
                                        <Row>
                                            <Col xs='1'/>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Real Estate
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Religion & Spirituality
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Science
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Shopping
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            
                                        </Row>
                                        <Row>
                                            <Col xs='1'/>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Society
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Sports
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Style & Fashion
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Technology & Computing
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            
                                        </Row>
                                        <Row>
                                            <Col xs='1'/>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Travel
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col>
                                            <Form.Group className="row">
                                            <div className="col">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" />
                                                <i className="input-helper"></i>
                                                Uncategorised
                                                </label>
                                            </div>
                                            </div>
                                            </Form.Group>
                                            </Col>
                                            <Col/>
                                           <Col/>
                                            
                                        </Row>
                                        
                                    </Container>
                                    </fieldset>
                                    <br/>
                                    <fieldset>
                                        <legend>Approve List</legend>
                                        <Container>
                                            <Row>
                                                <Col align='left'>
                                                <button
                                                type="button"
                                                className="btn btn-gradient-info btn-rounded btn-icon-text"
                                                >Add Sites Or Apps
                                                <FontAwesomeIcon icon="fa-save"/>
                                                </button>
                                                </Col>
                                                
                                            </Row>
                                            <br/>
                                            <Row>
                                                <Col>
                                                    <div class='box'>
                                                        <Col xs='1'>
                                                        <br/>Sites(Domain):
                                                        </Col>
                                                        </div>
                                                </Col>
                                            </Row>
                                        </Container>
                                    </fieldset>
                                    <br/>
                                    <fieldset>
                                        <legend>Block List</legend>
                                        <Container>
                                            <Row>
                                                <Col align='left'>
                                                <button
                                                type="button"
                                                className="btn btn-gradient-info btn-rounded btn-icon-text"
                                                >Add Sites Or Apps
                                                <FontAwesomeIcon icon="fa-save"/>
                                                </button>
                                                </Col>
                                                
                                            </Row>
                                            <br/>
                                            <Row>
                                                <Col>
                                                    <div class='box'>
                                                        <Col xs='1'>
                                                        <br/>Sites(Domain):
                                                        </Col>
                                                        </div>
                                                </Col>
                                            </Row>
                                        </Container>
                                    </fieldset>
                                    <br/>
                                    <fieldset>
                                        <legend>Channel MarketPlace Setting
                                        <i class="text-error">*</i>
                                        </legend>
                                        <Container>
                                            <Row>
                                                <Col xs='2'/>
                                                <Col xs='3'>
                                                    <p/>Bidders Enabled On Channel
                                                </Col>
                                                <Col xs='3' align='left'>
                                                <Form.Group controlId="formBasicSelect">
                                                            <Form.Control as="select" >
                                                                <option value='US'>All Bidder-Vdopia Optional</option>
                                                                <option >Vdopia Bidders Only</option>
                                                                <option >All Bidders-Vdopia Mandatory</option>
                                                                <option >Test Bidders Only</option>
                                                                <option >Not On Marketplace</option>
                                                            </Form.Control>
                                                </Form.Group>
                                                </Col>
                                        </Row>
                                        </Container>
                                    </fieldset>
                                    <br/>
                                    <fieldset>
                                        <legend>Ad Format</legend>
                                        <br/>
                                        <Container>
                                            <Row>
                                                <Col xs='auto'/>
                                                <Col>
                                                    <h5>View Product Gallery to see how each ad format looks like.</h5>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col xs='auto'/>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    Pre App Video
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    In App Video
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    Pre App Interstitial
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    In App Interstitial
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col xs='auto'/>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    Banner
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    Preroll
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    Leader VDO
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    Mini VDO
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col xs='auto'/>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    Html Banner
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    JS Banner
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    HTML Interstitial
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                                <Col>
                                                <Form.Group className="row">
                                                <div className="col">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input type="checkbox" className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                    In-View
                                                    </label>
                                                </div>
                                                </div>
                                                </Form.Group>
                                                </Col>
                                            </Row>
                                        </Container>
                                    </fieldset>
                                    <br/>
                                    <fieldset>
                                    <legend>iFilter Setting</legend>
                                    
                                { 
                                        
                                    inputFields.map((inputField,index)=>(   
                                    <Form.Group>
                                    <Container>
                                            <Row>
                                                <Col xs='7' align="left" key={index}>
                                                    <h5>Country</h5>
                                                </Col>
                                                
                                                <Col xs='3' align='center' key={index}>
                                                    <h5>Ifilter</h5>
                                                </Col>
                                                
                                                
                                            </Row>
                                            <br/>
                                            <Row>
                                            <Col xs='2' key={index}>
                                                
                                                <Form.Group controlId="formBasicSelect">
                                                    <Form.Control as="select" >
                                                        <option value='US'>US</option>
                                                        <option >India</option>
                                                        <option >Uruguay</option>
                                                        <option >Afghanisthan</option>
                                                        <option >New Zealand</option>
                                                    </Form.Control>
                                                </Form.Group>
                                                
                                                </Col>
                                                <Col xs='5' align='center'>
                                                    iFilter
                                                </Col>
                                                
                                                <Col xs='3' align='left'>
                                                <Form.Group controlId="formBasicSelect">
                                                    <Form.Control as="select" >
                                                        <option value='US'>US</option>
                                                        <option >Automatic(iFilter)</option>
                                                        <option >Low(10%)</option>
                                                        <option >Blocked(QPS=0)</option>
                                                        <option >High(100%)</option>
                                                    </Form.Control>
                                                </Form.Group>
                                                </Col>
                                                <Col xs='2' align='center'>
                                                <button
                                                type="button"
                                                className="btn btn-gradient-info btn-rounded btn-icon-text"
                                                onClick={handleAddFields}
                                                >Add(+)
                                                <FontAwesomeIcon icon="fa-save"/>
                                                </button>
                                                <br/>
                                                <br/>
                                                <button
                                                type="button"
                                                className="btn btn-gradient-info btn-rounded btn-icon-text"
                                                onClick={()=>handleRemoveFields(index)}
                                                >Remove(-)
                                                <FontAwesomeIcon icon="fa-save"/>
                                                </button>
                                                </Col>
                                                    
                                                    
                                                {/* <Col xs="auto">
                                                </Col> */}
                                            </Row>
                                            </Container>
                                            </Form.Group>
                                            ))
                                }
                                    </fieldset>
                                    <br/>
                                    <fieldset>
                                        <legend>Advanced Settings</legend>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                        Top Bar Height (min 20, max 40):
                                        </label>
                                        
                                        <div className="col-sm-4">
                                        <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        />
                                        </div>
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                        In-View Non-Stop:
                                        </label>

                                        <div className="col-md-2">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios1"
                                                defaultChecked
                                            />{" "}
                                            True
                                            <i className="input-helper"></i>
                                            </label>
                                        </div>
                                        </div>

                                        <div className="col-md-4">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios2"
                                            />{" "}
                                            False
                                            <i className="input-helper"></i>
                                            </label>
                                            
                                        </div>
                                        
                                        </div>
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                        Booking Channel
                                        </label>

                                        <div className="col-md-2">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios1"
                                                defaultChecked
                                            />{" "}
                                            Yes
                                            <i className="input-helper"></i>
                                            </label>
                                        </div>
                                        </div>

                                        <div className="col-md-4">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios2"
                                            />{" "}
                                            No
                                            <i className="input-helper"></i>
                                            </label>
                                            
                                        </div>
                                        
                                        </div>
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                        RON Setting:
                                        </label>

                                        <div className="col-md-2">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios1"
                                                defaultChecked
                                            />{" "}
                                            True
                                            <i className="input-helper"></i>
                                            </label>
                                        </div>
                                        </div>

                                        <div className="col-md-4">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios2"
                                            />{" "}
                                            False
                                            <i className="input-helper"></i>
                                            </label>
                                            
                                        </div>
                                        
                                        </div>
                                        </Form.Group>
                                        <Form.Group className='row'>
                                        <label className="col-sm-3 col-form-label text-right"/>
                                        <div className="col">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input type="checkbox" className="form-check-input" />
                                            <i className="input-helper"></i>
                                            Check On Target:
                                            </label>
                                        </div>
                                        </div>
                                        </Form.Group>
                                        <Form.Group className='row'>
                                        <label className="col-sm-3 col-form-label text-right"/>
                                        <div className="col">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input type="checkbox" className="form-check-input" />
                                            <i className="input-helper"></i>
                                            Webview:
                                            </label>
                                        </div>
                                        </div>
                                        </Form.Group>
                                        <br/>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                        Keyword Targeting:
                                        </label>

                                        <div className="col-md-2">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios1"
                                                defaultChecked
                                            />{" "}
                                            True
                                            <i className="input-helper"></i>
                                            </label>
                                        </div>
                                        </div>

                                        <div className="col-md-4">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios2"
                                            />{" "}
                                            False
                                            <i className="input-helper"></i>
                                            </label>
                                            
                                        </div>
                                        
                                        </div>
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                        Auto Refresh:
                                        </label>
                                        
                                        <div className="col-sm-4">
                                        <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        />
                                        </div>
                                        <label className="col-sm-3 col-form-label text-left">
                                        sec
                                        </label>
                                        
                                        {/* <Form.Text id="passwordHelpBlock" muted>
                                        (Sites: Provide the URL of the page where the impression will be shown)<br/>
                                        (Apps: Provide the App Store URL)     
                                        </Form.Text> */}
                                        
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                        Banner Left Behind:
                                        </label>

                                        <div className="col-md-2">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios1"
                                                defaultChecked
                                            />{" "}
                                            Yes
                                            <i className="input-helper"></i>
                                            </label>
                                        </div>
                                        </div>

                                        <div className="col-md-4">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios2"
                                            />{" "}
                                            No
                                            <i className="input-helper"></i>
                                            </label>
                                            
                                        </div>
                                        
                                        </div>
                                        </Form.Group>
                                        
                                        <Form.Group className='row'>
                                        <label className="col-sm-3 col-form-label text-right"/>
                                        <div className="col">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input type="checkbox" className="form-check-input" />
                                            <i className="input-helper"></i>
                                            Enable Single Tracker
                                            </label>
                                        </div>
                                        </div>
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                        Fill-Rate
                                        </label>
                                        
                                        <div className="col-sm-4">
                                        <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        />
                                        </div>
                                        <label className="col-sm-3 col-form-label text-left">
                                        sec
                                        </label>
                                        
                                        {/* <Form.Text id="passwordHelpBlock" muted>
                                        (Sites: Provide the URL of the page where the impression will be shown)<br/>
                                        (Apps: Provide the App Store URL)     
                                        </Form.Text> */}
                                        
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                        View-Cap Frequency(in min)
                                        </label>
                                        
                                        <div className="col-sm-4">
                                        <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        />
                                        </div>
                                        <label className="col-sm-3 col-form-label text-left">
                                        sec
                                        </label>
                                        
                                        {/* <Form.Text id="passwordHelpBlock" muted>
                                        (Sites: Provide the URL of the page where the impression will be shown)<br/>
                                        (Apps: Provide the App Store URL)     
                                        </Form.Text> */}
                                        
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                        Floor price for VDOFLO campaigns
                                        </label>
                                        
                                        <div className="col-sm-4">
                                        <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        />
                                        </div>
                                        <label className="col-sm-3 col-form-label text-left">
                                        sec
                                        </label>
                                        
                                        {/* <Form.Text id="passwordHelpBlock" muted>
                                        (Sites: Provide the URL of the page where the impression will be shown)<br/>
                                        (Apps: Provide the App Store URL)     
                                        </Form.Text> */}
                                        
                                        </Form.Group>
                                        <Form.Group className='row'>
                                        <label className="col-sm-3 col-form-label text-right"/>
                                        <div className="col">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input type="checkbox" className="form-check-input" />
                                            <i className="input-helper"></i>
                                            Server-Side Impression Counting
                                            </label>
                                        </div>
                                        </div>
                                        </Form.Group>
                                        <Form.Group className='row'>
                                        <label className="col-sm-3 col-form-label text-right"/>
                                        <div className="col">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input type="checkbox" className="form-check-input" />
                                            <i className="input-helper"></i>
                                            Do Not track on comscore
                                            </label>
                                        </div>
                                        </div>
                                        </Form.Group>
                                        <br/>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                            Close Timeout
                                        </label>
                                        
                                        <div className="col-sm-4">
                                        <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        />
                                        </div>
                                        <label className="col-sm-3 col-form-label text-left">
                                        sec
                                        </label>
                                        
                                        {/* <Form.Text id="passwordHelpBlock" muted>
                                        (Sites: Provide the URL of the page where the impression will be shown)<br/>
                                        (Apps: Provide the App Store URL)     
                                        </Form.Text> */}
                                        
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                            Show Close After
                                        </label>
                                        
                                        <div className="col-sm-4">
                                        <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        />
                                        </div>
                                        <label className="col-sm-3 col-form-label text-left">
                                        sec
                                        </label>
                                        
                                        {/* <Form.Text id="passwordHelpBlock" muted>
                                        (Sites: Provide the URL of the page where the impression will be shown)<br/>
                                        (Apps: Provide the App Store URL)     
                                        </Form.Text> */}
                                        
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                        Video Quality
                                        </label>

                                        <div className="col-md-2">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios1"
                                                defaultChecked
                                            />{" "}
                                            Normal
                                            <i className="input-helper"></i>
                                            </label>
                                        </div>
                                        </div>

                                        <div className="col-md-4">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input
                                                type="radio"
                                                className="form-check-input"
                                                name="ionType"
                                                id="membershipRadios2"
                                            />{" "}
                                            High
                                            <i className="input-helper"></i>
                                            </label>
                                            
                                        </div>
                                        
                                        </div>
                                        </Form.Group>
                                        <Form.Group className='row'>
                                        <label className="col-sm-3 col-form-label text-right"/>
                                        <div className="col">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input type="checkbox" className="form-check-input" />
                                            <i className="input-helper"></i>
                                            Ads By Text
                                            </label>
                                        </div>
                                        </div>
                                        </Form.Group>
                                        <br/>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                            Text Foreground Color
                                        </label>
                                        
                                        <div className="col-sm-2">
                                        <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        />
                                        </div>
                                        
                                        
                                        {/* <Form.Text id="passwordHelpBlock" muted>
                                        (Sites: Provide the URL of the page where the impression will be shown)<br/>
                                        (Apps: Provide the App Store URL)     
                                        </Form.Text> */}
                                        
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                            Text Background Color
                                        </label>
                                        
                                        <div className="col-sm-2">
                                        <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        />
                                        </div>
                                        
                                        
                                        {/* <Form.Text id="passwordHelpBlock" muted>
                                        (Sites: Provide the URL of the page where the impression will be shown)<br/>
                                        (Apps: Provide the App Store URL)     
                                        </Form.Text> */}
                                        
                                        </Form.Group>
                                        <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right">
                                            Mobile Web Preroll Passback Tag
                                        </label>
                                        
                                        <div className="col-sm-4">
                                        <textarea
                                                    className="form-control customTextarea"
                                                    id="exampleTextarea1"
                                                    rows="8"
                                                ></textarea>
                                        </div>
                                        
                                        
                                        {/* <Form.Text id="passwordHelpBlock" muted>
                                        (Sites: Provide the URL of the page where the impression will be shown)<br/>
                                        (Apps: Provide the App Store URL)     
                                        </Form.Text> */}
                                        
                                        </Form.Group>
                                        <br/>
                                    </fieldset>
                                    <br/>
                                    
                                    <fieldset>
                                        <legend>Channel Demo Parameters</legend>
                                        <Container>
                                            <Row>
                                            <div class='box1'>
                                                        {/* <Col align='center'> */}
                                                        <h6 align='center'>Set probabilty for each property.Max value=1</h6>
                                                        {/* </Col> */}
                                                        </div>
                                            </Row>
                                            <br/>
                                            <br/>
                                            <Row>
                                                <Col align='center'>
                                                        <h5>Entertainment</h5>
                                                </Col>
                                                <Col xs='auto'></Col>
                                                <Col align='center'>
                                                    <h5>Ethnicity</h5>
                                                </Col>

                                            </Row>
                                            <br/>
                                            <Row>
                                                <Col>
                                                <label>
                                                Movie Purchase Intenders
                                                {/* <i class="text-error">*</i> */}
                                                </label>
                                                </Col>
                                                <Col>
                                                <div>
                                                <Form.Control
                                                className="form-control customInput"
                                                type="text"
                                                />
                                                </div>
                                                </Col>
                                                <Col xs='1'></Col>
                                                <Col>
                                                <label>
                                                Hispanic
                                                {/* <i class="text-error">*</i> */}
                                                </label>
                                                </Col>
                                                <Col>
                                                <div>
                                                <Form.Control
                                                className="form-control customInput"
                                                type="text"
                                                />
                                                </div>
                                                </Col>
                                            </Row>
                                            <br/>
                                            <Row>
                                                <Col>
                                                <label>
                                                Super MPI
                                                {/* <i class="text-error">*</i> */}
                                                </label>
                                                </Col>
                                                <Col>
                                                <div>
                                                <Form.Control
                                                className="form-control customInput"
                                                type="text"
                                                />
                                                </div>
                                                </Col>
                                                <Col xs='1'></Col>
                                                <Col>
                                                <label>
                                                White
                                                {/* <i class="text-error">*</i> */}
                                                </label>
                                                </Col>
                                                <Col>
                                                <div>
                                                <Form.Control
                                                className="form-control customInput"
                                                type="text"
                                                />
                                                </div>
                                                </Col>
                                            </Row>
                                            <br/>
                                            <Row>
                                                <Col>
                                                <label>
                                                Entertainment Enthusiasts
                                                {/* <i class="text-error">*</i> */}
                                                </label>
                                                </Col>
                                                <Col>
                                                <div>
                                                <Form.Control
                                                className="form-control customInput"
                                                type="text"
                                                />
                                                </div>
                                                </Col>
                                                <Col xs='1'></Col>
                                                <Col>
                                                <label>
                                                Black-African American
                                                {/* <i class="text-error">*</i> */}
                                                </label>
                                                </Col>
                                                <Col>
                                                <div>
                                                <Form.Control
                                                className="form-control customInput"
                                                type="text"
                                                />
                                                </div>
                                                </Col>
                                            </Row>
                                            <br/>
                                            <Row>
                                                <Col>
                                                <label>
                                                    Confidence
                                                {/* <i class="text-error">*</i> */}
                                                </label>
                                                </Col>
                                                <Col>
                                                <div>
                                                <Form.Control
                                                className="form-control customInput"
                                                type="text"
                                                />
                                                </div>
                                                </Col>
                                                <Col xs='1'></Col>
                                                <Col>
                                                <label>
                                                American Indian-Eskimo-Aleut
                                                {/* <i class="text-error">*</i> */}
                                                </label>
                                                </Col>
                                                <Col>
                                                <div>
                                                <Form.Control
                                                className="form-control customInput"
                                                type="text"
                                                />
                                                </div>
                                                </Col>
                                            </Row>
                                            <br/>
                                            <Row>
                                                <Col></Col>
                                                <Col></Col>
                                                <Col xs='1'></Col>
                                                <Col>
                                                <label>
                                                Asian-Native Hawaiian-Other Pacific Islander
                                                {/* <i class="text-error">*</i> */}
                                                </label>
                                                </Col>
                                                <Col>
                                                <div>
                                                <Form.Control
                                                className="form-control customInput"
                                                type="text"
                                                />
                                                </div>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col></Col>
                                                <Col></Col>
                                                <Col xs='1'></Col>
                                                <Col>
                                                <label>
                                                    SouthEast Asian
                                                {/* <i class="text-error">*</i> */}
                                                </label>
                                                </Col>
                                                <Col>
                                                <div>
                                                <Form.Control
                                                className="form-control customInput"
                                                type="text"
                                                />
                                                </div>
                                                </Col>
                                            </Row>
                                        </Container>
                                    </fieldset>
                                    <fieldset>
                                        <legend>Select Ad Feed</legend>
                                        <Container>
                                            <Row>
                                                <Col>
                                                {
                                                    inputFields.map((inputField,index) => (
                                                        <>
                                                        <div key={index}>
                                                            <input type='text'/>
                                                        </div>
                                                        <button
                                                        onClick={handleAddFields}
                                                        
                                                        >+</button>
                                                        <button>-</button>
                                                        </>
                                                    ))
                                                }
                                                </Col>
                                            </Row>
                                        </Container>
                                    </fieldset>
                                    <br/>
                                    <Form.Group className="row">
                                        <label className="col-sm-3 col-form-label text-right"/>
                                        <div className="col-sm-4">
                                                <button
                                                type="button"
                                                className="btn btn-gradient-info btn-rounded btn-icon-text"
                                                >Save
                                                <FontAwesomeIcon icon="fa-save"/>
                                                </button>

                                        </div>
                                        
                                        
                                        {/* <Form.Text id="passwordHelpBlock" muted>
                                        (Sites: Provide the URL of the page where the impression will be shown)<br/>
                                        (Apps: Provide the App Store URL)     
                                        </Form.Text> */}
                                        
                                        </Form.Group>

                                </div>
                        </Form> 
                    </div>
              </div>

          </div>
          
      </div>
    )
  
}

export default AddNewChannel
                                        

                                    
                                            

                                            
                                            
                                            
                                            