import React from 'react';
import { Modal } from 'react-bootstrap';
import './UpdateAllowedNetworks.css'


function UpdateAllowedNetworks({showAssignHandler,handleCloseAssignHandler,userNetwork,onInputNetworkChange,onSubmitAssignHandler,data}) {
  
const {allowed_networks} = userNetwork

  return (
    
    <div>

      <Modal show={showAssignHandler} onHide={handleCloseAssignHandler} 
      className="custom-modal-style"
      size="md"
      >
        
        <Modal.Header closeButton>
        <Modal.Title><h3>Assign Network</h3></Modal.Title>
        </Modal.Header>
        <Modal.Body>

          <div className='container-fluid'>
            <div className='row'>
                
                    <div className='col-md-4'>
                    <form className="form" onSubmit={e => onSubmitAssignHandler(e)}>
                        <div className='row'>
                            <select 
                                className="form-control tableDropDown"
                                name="allowed_networks"
                                label="Select One"
                                value={allowed_networks}
                                sx={{width: 100,height: 10,}}
                                onChange={onInputNetworkChange}
                                >
                                  <option value="Admarvel" >Admarvel</option>
                                  <option value="MobClix" >MobClix</option>
                              </select>
                        </div>
                        <div className='row' style={{marginTop:"50px"}}>
                            <button type="submit" className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg">Submit</button>
                        </div>
                        </form>
                    </div>
                  
                  <div className='col text-justify'>
                      <div style={{ background: "#555759",width: "100%", marginBottom: "22px", height: "auto" ,display: "block" }}>
                        <div style={{ background: "#e9e8e8" ,color: "#555759", lineHeight: "18px" ,marginLeft: "16px",padding: "6px" ,textShadow:" 0 1px 0 rgb(255 255 255 / 50%)", fontSize:"12px" }}>
                          <strong>NOTE:</strong>
                          If you will change the allowed ad networks randomly, you will need to edit all the channels manually to set advance settings and advance parameters and there will be need to make changes in integration also according to networks.
                        </div>
                      </div>
                  </div>    
            </div>
          </div>
        
        </Modal.Body>
        <Modal.Footer>
        <button 
        className="btn btn-gradient-dark btn-rounded btn-icon-text btn-lg"
        variant="secondary" onClick={handleCloseAssignHandler}>Close </button>
        </Modal.Footer>
      </Modal>
    </div>

   
      
  )
}

export default UpdateAllowedNetworks