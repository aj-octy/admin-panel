import React from 'react';
import { Modal } from 'react-bootstrap';
import { Form , Row, Col, Container} from 'react-bootstrap';
import './UpdateSellerNetwork.css'

function UpdateSellerNetwork({showSeller,handleSellerClose,SellerUser ,onSellerInputChange,onSellerSubmit,data}) {

  
const {seller_network_id} = SellerUser

  return (
    
    <div>

      <Modal show={showSeller} onHide={handleSellerClose} 
      className="custom-modal-style"
      >
        
        <Modal.Header closeButton>
        <Modal.Title><h3>Update</h3></Modal.Title>
        </Modal.Header>
        <Modal.Body>

        <form className="form mt-4 mb-4" onSubmit={e => onSellerSubmit(e)}>
            <Container>
                <Row>
                        <Col>
                            <label>Seller Network ID</label>
                        </Col>
                        <Col>
                        <Form.Control
                            className="form-control customInput"
                            type="text"
                            name='seller_network_id'
                            value={seller_network_id}
                            onChange={e => onSellerInputChange(e)} 
                        />
                        </Col>
                </Row>
                <br/>
                <Row>
                    <Col></Col>
                    <Col align='left'>
                        <button
                            type='submit'
                            className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                        >Submit
                        </button>
                    </Col>
                </Row>
            </Container>
        </form>
        </Modal.Body>
        <Modal.Footer>
        <button 
        className="btn btn-gradient-dark btn-rounded btn-icon-text btn-lg"
        variant="secondary" onClick={handleSellerClose}>
            Close
          </button>
        </Modal.Footer>
      </Modal>
    </div>

   
      
  )
}

export default UpdateSellerNetwork