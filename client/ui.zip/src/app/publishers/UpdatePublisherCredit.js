import React from 'react';
import { Button,Modal } from 'react-bootstrap';
import { Form , Row, Col, Container} from 'react-bootstrap';
import './UpdatePublisherCredit.css'
import {toast} from 'react-toastify';

function Update({show,handleClose,data,onInputChange,onSubmit}) {
  
const {rev_share, email, effective_date} = data

  return (
    
    <div>

      <Modal show={show} onHide={handleClose} 
      className="custom-modal-style"
      >
        
        <Modal.Header closeButton>
        <Modal.Title><h3>Edit Revenue</h3></Modal.Title>
        </Modal.Header>
        <Modal.Body>

        <form className="form-inline mt-4 mb-4" onSubmit={e => onSubmit(e)}>
            <Container>
                <Row>
                    <Col xs={4} align='right'>
                        <label><h5>Publisher:</h5></label>
                    </Col>
                    <Col xs='auto'><p>{email}</p></Col>
                </Row>
                <br/>
                
                <Row>
                    <Col xs={4} align='right'>
                        <label><h5>Price Model:</h5></label>
                    </Col>
                    <Col xs='auto'><p>Rev Shared To Vdopia</p></Col>
                    <Col align='left'> 
                        <Form.Group>
                                <div className="input-group">
                                  <Form.Control
                                    type="text"
                                    className="form-control customInput"
                                    placeholder="5.00"
                                    value={rev_share}
                                    name='rev_share'
                                    style={{width:"80px"}}
                                    onChange={e => onInputChange(e)} 
                                  />
                                  <div className="input-group-prepend">
                                    <span style={{borderRadius: "0px 5px 5px 0px",}}className="input-group-text">%</span>
                                  </div>
                                </div>
                              </Form.Group>
                    </Col>
                </Row>
                <br/>
                <Row>
                    <Col xs={4} align='right'>
                        <label>
                            <h5>Effective Date:</h5>
                        </label>
                    </Col>
                    <Col xs='auto'>
                    <p> {effective_date} </p>
                    </Col>
                </Row>
                <br/>
                <Row>
                    {/* <Col xs={4} align='center'>
                    </Col> */}
                    {/* <Col xs='auto'> */}
                    {/* <button
                        type="button"
                        className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                        >View Logs
                    </button> */}
                    {/* </Col> */}
                    <Col className='text-center'>
                    <button
                        type='submit'
                        className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                        >Save
                        </button>
                    </Col>
                </Row>
            </Container>
        </form>
        </Modal.Body>
        <Modal.Footer>
        <Button  variant="light" size='sm' onClick={handleClose} className="btn btn-gradient-dark btn-rounded btn-icon-text btn-lg">
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>

   
      
  )
}

export default Update