import * as React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '@mui/material/styles';
import {useState, useEffect} from 'react';
import axios from 'axios';
import { Switch } from '@material-ui/core';
import { makeStyles } from "@material-ui/core/styles";
import { Form, Row, Col} from 'react-bootstrap'
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import TableContainer from '@mui/material/TableContainer';
import { tableCellClasses } from '@mui/material/TableCell';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import IconButton from '@mui/material/IconButton';
import FirstPageIcon from '@mui/icons-material/FirstPage';
import KeyboardArrowLeft from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRight from '@mui/icons-material/KeyboardArrowRight';
import LastPageIcon from '@mui/icons-material/LastPage';
import {library} from '@fortawesome/fontawesome-svg-core'
import { faSearch} from '@fortawesome/free-solid-svg-icons'
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import  UpdatePublisherCredit from './UpdatePublisherCredit'
import UpdateAllowedNetworks from './UpdateAllowedNetworks'
import UpdatePublisherFloor from './UpdatePublisherFloor'
import UpdateSellerNetwork from './UpdateSellerNetwork'
import UpdateRtbPartner from './UpdateRtbPartner'
import Crud from '../common/Calls_methods'
import {toast} from 'react-toastify';
library.add(faSearch);
const useStyles = makeStyles({
  root: {
    width: 700,
    height: 600,
  },
  tableCell: {
    padding: "0px 16px"
  }
});
function TablePaginationActions(props) {
  const theme = useTheme();
  const { count, page, rowsPerPage, onPageChange } = props;
  const handleFirstPageButtonClick = (event) => {
    onPageChange(event, 0);
  };
  const handleBackButtonClick = (event) => {
    onPageChange(event, page - 1);
  };
  const handleNextButtonClick = (event) => {
    onPageChange(event, page + 1);
  };
  const handleLastPageButtonClick = (event) => {
    onPageChange(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };
  return (
    <Box sx={{ flexShrink: 0, ml: 2.5 }}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton
        onClick={handleBackButtonClick}
        disabled={page === 0}
        aria-label="previous page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </Box>
  );
}
TablePaginationActions.propTypes = {
  count: PropTypes.number.isRequired,
  onPageChange: PropTypes.func.isRequired,
  page: PropTypes.number.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
};
function Publishers() 
{
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(50);
  const [data,setData]=useState([]);
  // const [checked, setChecked] = useState([]);
  const [emailDirection, setemailDirection] = useState("asc");
  const [companyDirection, setcompanyDirection] =useState("asc");
  const [nameDirection, setnameDirection] = useState("asc");
  const [countryDirection, setCountryDirection] = useState("asc");
  const [addtimeDirection, setaddtimeDirection] = useState("asc");
  const [acctypeDirection, setacctypeDirection] = useState("asc");
  const [creditDirection, setCreditDirection] = useState("asc");
  const [addcreditDirection, setaddCreditDirection] = useState("asc");
  const classes = useStyles();
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  const sortByAddCredit=() => {
    if (addcreditDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return b.id - a.id;
        })
      );
      setaddCreditDirection("desc");
    }
    if (addcreditDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return a.id - b.id;
        })
      );
      setaddCreditDirection("asc");
    }
  }
  const sortByCredit =() => {
    if (creditDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return b.id - a.id;
        })
      );
      setCreditDirection("desc");
    }
    if (creditDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return a.id - b.id;
        })
      );
      setCreditDirection("asc");
    }
  }
  const sortByacctype =()=>{
    if (acctypeDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return b.id - a.id;
        })
      );
      setacctypeDirection("desc");
    }
    if (acctypeDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return a.id - b.id;
        })
      );
      setacctypeDirection("asc");
    }
  }
  const sortByaddtime =() =>{
    if (addtimeDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return b.id - a.id;
        })
      );
      setaddtimeDirection("desc");
    }
    if (addtimeDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return a.id - b.id;
        })
      );
      setaddtimeDirection("asc");
    }
  }
  const sortByCountry =() =>{
    if (countryDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return b.id - a.id;
        })
      );
      setCountryDirection("desc");
    }
    if (countryDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return a.id - b.id;
        })
      );
      setCountryDirection("asc");
    }
  };
  const sortByname =()=> {
    if (nameDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return b.id - a.id;
        })
      );
      setnameDirection("desc");
    }
    if (nameDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return a.id - b.id;
        })
      );
      setnameDirection("asc");
    }
  }
  const sortBycompany =()=> {
    if (companyDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return b.id - a.id;
        })
      );
      setcompanyDirection("desc");
    }
    if (companyDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          // console.log(a.id);
          return a.id - b.id;
        })
      );
      setcompanyDirection("asc");
    }
  };
  const sortByemail = () => {
    if (emailDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.id - a.id;
        })
      );
      setemailDirection("desc");
    }
    if (emailDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setemailDirection("asc");
    }
  };
  useEffect(()=>{
    getData("");
  },[]);
  const getData=()=>{
   let keyword = search.publishers_name
    Crud.getTableData(`publisher/search?${keyword}`).then((res)=> {
    setData(res.data);
  });
  };
  const handleStatus=()=>{
    alert("status updated!!!")
  }
  const handleAccountType=()=>{
    alert("done!")
  }
const initialValue={ rev_share : "", email : "", effective_date: ""}
const[user,setUser]=useState(initialValue);
const handleEdit = (EditData) => {
  setUser(EditData);
  handleShow();
};
const {rev_share, email, effective_date}= user;
const onInputChange=e=>{
  setUser({ ...user, [e.target.name]: e.target.value });
}
const onSubmit=async e=>{
    e.preventDefault();    
    const res = await Crud.update(`revenue_share`,user.id,user)
       await  handleClose();
       await getData()
       if(res.status == 200) {
         console.log(user.rev_share)
         toast.success("Account Type Updated",{
            position: "top-right",
            autoClose: 4000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            })
        }
}
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - data.length) : 0;
  const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: '#21364e',
      color: theme.palette.common.white,
      fontSize: 15,
      height: 0,
      // FontFace: "arial",
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 0,
      height: 0,
    },
  }));
  const handleaddAdvertiser=()=>{
  }
  //Assign Network code starts here
  const initial={ allowed_networks : "Admarvel"}
const[userNetwork,setNetworkUser]=useState(initial);
const handleassignNetwork = (EditData) => {
  setNetworkUser(EditData);
  console.log(userNetwork);
  handleShowAssignHandler();
};
const {allowed_networks }= userNetwork;
const onInputNetworkChange=e=>{
  setNetworkUser({ ...userNetwork, [e.target.name]: e.target.value });
}
const onSubmitAssignHandler=async e=>{
    e.preventDefault();
    // const res = await Crud.update(`revenue_share`,user.id,user)
    const res = await Crud.update(`publisher/allowed_networks`,userNetwork.id ,userNetwork)
       await  handleCloseAssignHandler();
       await getData();
       if(res.status == 200) {
         console.log(user.rev_share)
         toast.success("Allowed Network Updated",{
            position: "top-right",
            autoClose: 4000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            })
        }
}
  const [showAssignHandler, setShowAssignHandler] = useState(false);
  const handleCloseAssignHandler = () => setShowAssignHandler(false);
  const handleShowAssignHandler = () => setShowAssignHandler(true);
  //Assign Network code ends here....
  //Configure Floor Code Starts Here...
  const [selected, setSelected]= useState([]);
  const isButtonSelected=(value)=>{
    if(selected===value){
    return true;
    }
  }
  const initialfloorvalue={price_settle_method:"floor",psm_trickle_rate:""}
  const[ConfigureFloor,setConfigureFloor]=useState(initialfloorvalue)
  const handleConfigureFloor=(EditData)=>{
    console.log(EditData);
    setConfigureFloor(EditData);
    console.log(ConfigureFloor);
    handleConfigureFloorShow()
  }
  const{price_settle_method,psm_trickle_rate}=ConfigureFloor;
  const onConfigureFloorInputChange = e => {
    setConfigureFloor({ ...ConfigureFloor, [e.target.name]: e.target.value });
    setSelected({...ConfigureFloor,[e.target.name]: e.target.value});
  };
  const onSubmitConfigureFloor = async e => {
      e.preventDefault();
      const res = await Crud.update(`publisher/ConfigureFloor`,ConfigureFloor.id ,ConfigureFloor);
      await  handleConfigureFloorClose();
      await getData();
      if(res.status == 200) {
        console.log(user.rev_share)
        toast.success("Config Floor Updated",{
           position: "top-right",
           autoClose: 4000,
           hideProgressBar: false,
           closeOnClick: true,
           pauseOnHover: false,
           draggable: true,
           progress: undefined,
           })
       }
  }
  const [showConfigure, setshowConfigure]=useState(false);
  const handleConfigureFloorShow=()=>setshowConfigure(true);
  const handleConfigureFloorClose=()=>setshowConfigure(false);
  //Configure Floor COde  Ends Here...
  const handleSelectChange=(e,select)=>{
    let acc_type=e.target.value;
    Crud.update(`publisher/acc_type`,select,{acc_type : acc_type})
    .then(()=>{
      getData()
      toast.success("Account Type Updated",{
      position: "top-right",
      autoClose: 4000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: false,
      draggable: true,
      progress: undefined,
      })});
  }
  //For Activated Button
  const initialActivatedValueToggle={
    activated: "yes",
  }
  const [togglActivatedestate, settoggleState]=useState(initialActivatedValueToggle);
  useEffect(()=>{
  })
  const {activated}= togglActivatedestate;
  const handleChangeActivatedStatus=(e,select)=>{
      let activated = e.target.checked ? "yes":"no";
      Crud.update(`publisher/activated`, select,{
        activated:activated,
      })
      .then(()=>{
        getData()
        toast.success("Status Updated",{
        position: "top-right",
        autoClose: 4000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        })});
  }
  //For Activated Button
  //For Is Seller Enabled
  const initialSellerToggleValue={
    is_seller_json_enabled: 1,
  }
  const [toggleSellerValue, setToggleSellerValue]=useState(initialSellerToggleValue);
  useEffect(()=>{
  })
  const {is_seller_json_enabled}=toggleSellerValue;
  const handleChangeSellerStatus=(e, select)=>{
    console.log(select);
    let is_seller_json_enabled= e.target.checked ? 1:0;
    console.log(e.target.checked);
    console.log(is_seller_json_enabled);
    Crud.update(`publisher/is_seller_json_enabled`,select,{is_seller_json_enabled:is_seller_json_enabled})
    .then(()=>{
      getData()
      toast.success("Seller Json Updated",{
      position: "top-right",
      autoClose: 4000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: false,
      draggable: true,
      progress: undefined,
      })})
  }
  //For Is Seller Enabled
  //For Truncated IP
  const initialTruncatedToggleValue={
    is_truncated_ip_enabled: 1,
  }
  const [toggleTruncatedValue, setToggleTruncatedValue]=useState(initialTruncatedToggleValue);
  useEffect(()=>{
  })
  const {is_truncated_ip_enabled}=toggleTruncatedValue;
  const handleChangeTruncatedip=(e, select)=>{
    let is_truncated_ip_enabled= e.target.checked ? 1:0;
    Crud.update(`publisher/is_truncated_ip_enabled`,select,{is_truncated_ip_enabled:is_truncated_ip_enabled})
    .then(()=>{
      getData()
      toast.success("Truncated IP Updated",{
      position: "top-right",
      autoClose: 4000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: false,
      draggable: true,
      progress: undefined,
      })})
  }
  //For Truncated IP
  //Authenticated With
// chocolate
// silverpush
  // let test = { authenticated_with: "silverpush" };
  // const [values, setValue] = useState(test);
  // const { authenticated_with } = values;
  const handleSelectChangeAuthWith=(e, select)=>{
    let authenticated_with=e.target.value;
    Crud.update(`publisher/authenticated_with`,select,{authenticated_with : authenticated_with})
    .then(()=>{
      getData()
      console.log(authenticated_with)
      toast.success("Authenticated with Updated",{
      position: "top-right",
      autoClose: 4000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: false,
      draggable: true,
      progress: undefined,
      })})
    //   const acc_type = e.target.value;
    // console.log(acc_type)
    // Curd.update(`advertiser/acc_type`, select,{
    //     acc_type: acc_type,
    //   })
    //   .then(toast.success("Account Type Updated",{
    //     position: "top-right",
    //     autoClose: 4000,
    //     hideProgressBar: false,
    //     closeOnClick: true,
    //     pauseOnHover: false,
    //     draggable: true,
    //     progress: undefined,
    //     }));
  }
  // Authenticated with 
  const AntSwitch = styled(Switch)(({ theme }) => ({
    width: 28,
    height: 16,
    padding: 0,
    display: 'flex',
    '&:active': {
      '& .MuiSwitch-thumb': {
        width: 15,
      },
      '& .MuiSwitch-switchBase.Mui-checked': {
        transform: 'translateX(9px)',
      },
    },
    '& .MuiSwitch-switchBase': {
      padding: 2,
      '&.Mui-checked': {
        transform: 'translateX(12px)',
        color: '#fff',
        '& + .MuiSwitch-track': {
          opacity: 1,
          backgroundColor: theme.palette.mode === 'dark' ? '#177ddc' : '#1890ff',
        },
      },
    },
    '& .MuiSwitch-thumb': {
      boxShadow: '0 2px 4px 0 rgb(0 35 11 / 20%)',
      width: 12,
      height: 12,
      borderRadius: 6,
      transition: theme.transitions.create(['width'], {
        duration: 200,
      }),
    },
    '& .MuiSwitch-track': {
      borderRadius: 16 / 2,
      opacity: 1,
      backgroundColor:
        theme.palette.mode === 'dark' ? 'rgba(255,255,255,.35)' : 'rgba(0,0,0,.25)',
      boxSizing: 'border-box',
    },
  }));
  //Data Center
  const [dataCenter,setDataCenterData]=useState([]);
  const getDataCenterData=(authenticatedWithId)=>{
    Crud.getData(`dataCenter`, authenticatedWithId).then((res)=> {
       setDataCenterData(res.data)
      console.log(res.data)  
  });
}
  // useEffect(()=>{
  // },[]);
  //For Seller Network ID and Open RTB Partner
  const sellerinitial={seller_network_id : "",}
  const[SellerUser,setSellerUser]=useState(sellerinitial);
  const handleSellerNetwork=(select)=>{
    setSellerUser(select);
    handleSellerShow();
  }
const {seller_network_id}= SellerUser;
const onSellerInputChange=e=>{
  setSellerUser({ ...SellerUser, [e.target.name]: e.target.value });
}
const onSellerSubmit=async e=>{
  e.preventDefault();
  const res = await Crud.update(`publisher/seller_network_id`,SellerUser.id ,SellerUser);
       await  handleClose();
       await getData()
       if(res.status == 200) {
         console.log(user.rev_share)
         toast.success("Seller Network Updated",{
            position: "top-right",
            autoClose: 4000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            })
        }
}
  const [showSeller, setShowSeller] = useState(false);
  const handleSellerClose = () => setShowSeller(false);
  const handleSellerShow = () => setShowSeller(true);
  //For Seller Network ID and Open RTB Partner
  //For Open RTB Partner
  const Rtbinitial={identifier : "",}
  const[RtbUser,setRtbUser]=useState(Rtbinitial);
  const handleRtbNetwork=(select)=>{
    console.log(select.id);
    getDataCenterData(select.id);
    setRtbUser(select);
    console.log(RtbUser);
    handleRtbShow();
  }
const {identifier}= RtbUser;
const onRtbInputChange=e=>{
  setRtbUser({ ...RtbUser, [e.target.name]: e.target.value });
}
  const [showRtb, setShowRtb] = useState(false);
  const handleRtbClose = () => setShowRtb(false);
  const handleRtbShow = () => setShowRtb(true);
  //For Open RTB Partner
  // searching 
  const initialValueForSearch = { publishers_name:"" }
  const [search,setSearch] = useState(initialValueForSearch);
  const {publishers_name} = search;
  const onInputChangeKeyword=(e)=>{
    setSearch(item1=>({publishers_name: e.target.value }));
  }
  const onSubmitKeyword = e => {
    e.preventDefault();
    getData();
  }
  // seraching 
  return (
    <>
      <h3 style={{color:"#343a40"}}>Publishers</h3>
      <Form onSubmit={(e) => onSubmitKeyword(e)}>
        <Row>
          <Col xs="4">
            <Form.Control
              className="form-control customInput"
              type="text"
              name="publishers_name"
              // value={""}
              placeholder="Search Advertisers"
              onChange={(e) => onInputChangeKeyword(e)}
            />
          </Col>
          <button
            type="submit"
            className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
            >Search <FontAwesomeIcon icon="search" />
          </button>
        </Row>
      </Form>
      <br /><Paper sx={{ width: '100%', overflow: 'hidden' }}>
        <TableContainer className='tablewidth'>
          <Table sx={{ minWidth: 2800 }} size='small' stickyHeader aria-label="customized table">
            <TableHead sx={{ width: '100%' }}>
              <StyledTableRow>
                <StyledTableCell align='center' onClick={() => sortByemail("email")}
                  style={{ position: "sticky", left: 0, zIndex: 10 }}
                >Email</StyledTableCell>
                <StyledTableCell align="center" onClick={() => sortBycompany("company_name")}>Company Name</StyledTableCell>
                <StyledTableCell align="center" onClick={() => sortByname("name")}>Name</StyledTableCell>
                <StyledTableCell align='center'>Country</StyledTableCell>
                <StyledTableCell align='center'>Currency</StyledTableCell>
                <StyledTableCell align='center'>Rev Share To Vdopia</StyledTableCell>
                <StyledTableCell align='center'>Add Time</StyledTableCell>
                <StyledTableCell align='center'>Account Type</StyledTableCell>
                <StyledTableCell align='left'>Assign Network</StyledTableCell>
                <StyledTableCell align='left'>Publisher Mapping</StyledTableCell>
                <StyledTableCell align='left'>Publisher Floor</StyledTableCell>
                <StyledTableCell align='left'>Authenticated With</StyledTableCell>
                <StyledTableCell align='left'>Status</StyledTableCell>
                <StyledTableCell align='left'>Seller Enabled</StyledTableCell>
                <StyledTableCell align='left'>Truncated ID Enabled</StyledTableCell>
              </StyledTableRow>
            </TableHead>
            <TableBody sx={{ width: '100%' }}>
              {(rowsPerPage > 0
                ? data.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                : data
              ).map((row, index) => (
                <StyledTableRow align="right" key={index} selected={row.selected}>
                  <StyledTableCell
                    style={(index % 2) ? { position: "sticky", left: 0, zIndex:8, background: "white" } : { position: "sticky", left: 0,zIndex:8, background: "whitesmoke" }}
                  >{row.email}</StyledTableCell>
                  <StyledTableCell>{row.company_name}</StyledTableCell>
                  <StyledTableCell>{row.fname}</StyledTableCell>
                  <StyledTableCell>{row.country}</StyledTableCell>
                  <StyledTableCell>{row.currency}</StyledTableCell>
                  <StyledTableCell>
                    <a
                      style={{ color: "#0088cc" }}
                      role="button"
                      onClick={() => handleEdit(row)}>
                      {row.rev_share}
                    </a>
                  </StyledTableCell>
                  <StyledTableCell>{row.addtime}</StyledTableCell>
                  <StyledTableCell>
                    {/* <FormControl key={index}> */}
                    <div className='container p-0'>
                      <select className="form-control tableDropDown"
                        name="acc_type"
                        size='small'
                        style={{width:"100px"}}
                        onChange={(e) => handleSelectChange(e, row.id)}
                      >
                        <option selected={row.acc_type == "external"} value="external">external</option>
                        <option selected={row.acc_type == "internal"} value="internal">internal</option>
                      </select>
                      {/* {selectState} */}
                    </div>
                  </StyledTableCell>
                  <StyledTableCell>
                    <button
                      type="button"
                      className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                      style={{ fontSize: "13px" }}
                      onClick={() => handleassignNetwork(row)}
                    >Assign Network
                    </button>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Row>
                      <button
                        type="button"
                        className="btn btn-gradient-success btn-rounded btn-icon-text btn-lg"
                        disabled={row.seller_network_id == null ? true : false}
                        style={{ fontSize: "10px", marginBottom: "4px" }}
                        onClick={() => handleSellerNetwork(row)}
                      >Seller Network ID
                      </button>
                    </Row>
                    <Row>
                      <button
                        type="button"
                        className="btn btn-gradient-success btn-rounded btn-icon-text btn-lg"
                        disabled={row.identifier == null ? true : false}
                        style={{ fontSize: "10px" }}
                        onClick={() => handleRtbNetwork(row)}
                      >Open RTB Partner
                      </button>
                    </Row>
                  </StyledTableCell>
                  <StyledTableCell>
                    <button
                      type="button"
                      className="btn btn-gradient-success btn-rounded btn-icon-text btn-lg"
                      style={{ fontSize: "13px" }}
                      onClick={() => handleConfigureFloor(row)}
                    >Configure Floor
                    </button>
                  </StyledTableCell>
                  <StyledTableCell >
                        <div className='container p-0'>
                            <select className="form-control tableDropDown" onChange={(e)=>handleSelectChangeAuthWith(e,row.id)} name="authenticated_with" style={{width:"100px"}}>
                                <option selected={row.authenticated_with == "chocolate"} value="chocolate" >Chocolate</option>
                                <option selected={row.authenticated_with == "silverpush"} value="silverpush" >SilverPush</option> 
                            </select>
                        </div>
                    </StyledTableCell>
                  <StyledTableCell>
                    <AntSwitch inputProps={{ 'aria-label': 'ant design' }}
                      color='primary'
                      size='small'
                      defaultChecked={row.activated == "yes" ? true : false}
                      onChange={(e) => handleChangeActivatedStatus(e, row.id)}
                      name="activated" />
                  </StyledTableCell>
                  <StyledTableCell>
                    <AntSwitch inputProps={{ 'aria-label': 'ant design' }}
                      color='primary'
                      size='small'
                      defaultChecked={row.is_seller_json_enabled == 1 ? true : false}
                      onChange={(e) => handleChangeSellerStatus(e, row.id)}
                      name="is_seller_json_enabled" />
                  </StyledTableCell>
                  <StyledTableCell>
                    <AntSwitch inputProps={{ 'aria-label': 'ant design' }}
                      color='primary'
                      size='small'
                      defaultChecked={row.is_truncated_ip_enabled == 1 ? true : false}
                      onChange={(e) => handleChangeTruncatedip(e, row.id)}
                      name="" />
                  </StyledTableCell>
                </StyledTableRow>
              ))}
              {emptyRows > 0 && (
                <StyledTableRow style={{ height: 53 * emptyRows }}>
                  <StyledTableCell colSpan={10} />
                </StyledTableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper><Paper>
        <TableContainer>
          <Table>
            <TableBody>
              <TablePagination
                rowsPerPageOptions={[50, 100, 200, 250, { label: 'All', value: -1 }]}
                count={data.length}
                rowsPerPage={rowsPerPage}
                page={page}
                SelectProps={{
                  inputProps: {
                    'aria-label': 'rows per page',
                  },
                  native: true,
                }}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                ActionsComponent={TablePaginationActions} />
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
      <UpdatePublisherCredit show={show} handleClose={handleClose} data={user} onInputChange={onInputChange} onSubmit={onSubmit} />
      <UpdateAllowedNetworks showAssignHandler={showAssignHandler} handleCloseAssignHandler={handleCloseAssignHandler} userNetwork={userNetwork} onInputNetworkChange={onInputNetworkChange} onSubmitAssignHandler={onSubmitAssignHandler} />
      <UpdatePublisherFloor showConfigure={showConfigure} handleConfigureFloorClose={handleConfigureFloorClose} ConfigureFloor={ConfigureFloor} isButtonSelected={isButtonSelected} onConfigureFloorInputChange={onConfigureFloorInputChange} onSubmitConfigureFloor={onSubmitConfigureFloor} />
      <UpdateSellerNetwork showSeller={showSeller} handleSellerClose={handleSellerClose} SellerUser={SellerUser} onSellerInputChange={onSellerInputChange} onSellerSubmit={onSellerSubmit} />
      <UpdateRtbPartner showRtb={showRtb} handleRtbClose={handleRtbClose} RtbUser={RtbUser} dataCenter={dataCenter} onRtbInputChange={onRtbInputChange}/>
      </>
  );
}
export default Publishers