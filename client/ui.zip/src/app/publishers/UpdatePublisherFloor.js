import React, { useEffect, useState } from 'react';
import { Modal } from 'react-bootstrap';
import { Form , Row, Col, Container} from 'react-bootstrap';
import './UpdatePublisherFloor.css'


function UpdateAllowedNetworks({showConfigure,handleConfigureFloorClose,ConfigureFloor,isButtonSelected,onConfigureFloorInputChange,onSubmitConfigureFloor,data}) {


  
const {price_settle_method,psm_trickle_rate} = ConfigureFloor
const[visible,setVisible]=useState(true);
useEffect(()=>{
  ConfigureFloor.price_settle_method =="both" ?  setVisible(true) : setVisible(false)  
})


  return (
    
    <div>
      <Modal show={showConfigure} onHide={handleConfigureFloorClose} 
      className="custom-modal-style"
      
      >
        
        <Modal.Header closeButton>
        <Modal.Title><h3>Update</h3></Modal.Title>
        </Modal.Header>
        <Modal.Body>

        <form className="form mt-4 mb-4" onSubmit={e => onSubmitConfigureFloor(e)}>
            <Container>
                
                 <div className='row text-center'>
                     <div className='col text-center'>


                     <div className="form-check text-left">           
                        <label className="form-check-label">
                          <input
                            value="floor"
                            type="radio"
                            className="form-check-input"
                            name="price_settle_method"
                            id="membershipRadios1"
                            checked={ConfigureFloor.price_settle_method=='floor'}
                            onChange={e=>onConfigureFloorInputChange(e)}
                            onClick={()=>setVisible(false)}
                          />
                          Settle Price On Floor
                          <i className="input-helper"></i>
                        </label>
                        </div>
 
                <div className="form-check text-left">
                        <label className="form-check-label">
                          <input
                            value="margin"
                            type="radio"
                            className="form-check-input"
                            name="price_settle_method"
                            id="membershipRadios1"
                            checked={ConfigureFloor.price_settle_method=='margin'}
                            onChange={e=>onConfigureFloorInputChange(e)}
                            onClick={()=>setVisible(false)}
                          />
                          Settle Price On Margin
                          <i className="input-helper"></i>
                        </label>
                        </div>
   
                <div className="form-check text-left">
                        <label className="form-check-label">
                          <input
                            value="both"
                            type="radio"
                            className="form-check-input"
                            name="price_settle_method"
                            id="membershipRadios1"
                            checked={ConfigureFloor.price_settle_method=='both'}
                            onChange={e=>onConfigureFloorInputChange(e)}
                            onClick={()=>setVisible(true)}
                          />
                          both
                          <i className="input-helper"></i>
                        </label>
                        <br/>
                        { visible &&
                                    <Form.Group className="row">
                                        <label className='col-sm-6 mt-2'> Specify trickle rate for settle price on the margin </label>
                                        <div className="col-sm-2 input-group" style={{marginLeft:"-40px"}}>
                                            <Form.Control
                                                className="form-control customInput"
                                                type="text"
                                                name="psm_trickle_rate"
                                                style={{width:"30px"}}
                                                value={psm_trickle_rate}
                                                onChange={e => onConfigureFloorInputChange(e)}
                                            />
                                            <div className="input-group-prepend">
                                              <span style={{borderRadius: "0px 5px 5px 0px",}}className="input-group-text">%</span>
                                            </div>
                                        </div>
                                        
                                        {/* <label className='col-sm-2' align='center'>%</label> */}
                                       
                                    </Form.Group>
                        }
                        </div>
                        
                        <button
                            type="submit"
                            className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg mt-4"
                            >Submit
                        </button>

                     </div>
                 </div>
                        

                
                <br/>

                <Row>

                        
                        {/* </label> */}
                    {/* </Col> */}
                    
                </Row>
                <br/>
                
            </Container>
        </form>
        </Modal.Body>
        <Modal.Footer>
        <button 
        className="btn btn-gradient-dark btn-rounded btn-icon-text btn-lg"
        variant="secondary" onClick={handleConfigureFloorClose}>
            Close
          </button>
        </Modal.Footer>
      </Modal>
    </div>

   
      
  )
}

export default UpdateAllowedNetworks