import React, { useState, useEffect } from "react";
import { Modal } from "react-bootstrap";
import { Row, Col, Container } from "react-bootstrap";
import "./UpdateRtbPartner.css";
import axios from "axios";

function UpdateRtbPartner({
  showRtb,
  handleRtbClose,
  RtbUser,
  onRtbChange,
  data,
  dataCenter
}) {
  console.log(dataCenter)
  const { identifier } = RtbUser;
  const [dataCenterData, setDataCenterData] = useState([]);

  // const getDataCenterData = () => {
  //   axios.get("http://localhost:5000/dataCenter").then((res) => {
  //     setDataCenterData(res.data);
  //   });
  // };

  const [hyperText, setHyperText] = useState("http");

  const onInputChange = (e) => {
    setHyperText(e.target.value);
    console.log(e.target.value);
  };
  useEffect(() => {
    console.log("Value of Selected client in State is: ", hyperText);
  }, [hyperText]);
  useEffect(() => {
    // getDataCenterData();
  }, []);

  return (
    <div>
      <Modal show={showRtb} onHide={handleRtbClose}>
        <Modal.Header closeButton>
          <Modal.Title>
            <h3>Update</h3>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Container>
            <Row>
              <Col>
                <h4>Open RTB Partner(Identifier)</h4>
              </Col>
            </Row>
            <br />
            <Row>
              <Col></Col>
              <Col>
                <div className="row">
                  <select
                    className="form-control tableDropDown"
                    name="protocolType"
                    onChange={(e) => onInputChange(e)}
                    value={hyperText}
                    style={{ width: "200px" }}
                  >
                    <option value="http">http</option>
                    <option value="https">https</option>
                  </select>
                </div>
              </Col>
              <Col></Col>
            </Row>
            <Row></Row>
            <br />

            <div className="row">
              {dataCenter.map((item) => (
                <>
                  <div className="col-md-3 text-right">
                    <h6>{item.dc_name}:</h6>
                  </div>
                  <div className="col-md-9">
                    <p>
                      {hyperText}://{item.dc_url}/bidder/?identifier=
                      {identifier}
                    </p>
                  </div>
                </>
              ))}
            </div>

            <br />
          </Container>
        </Modal.Body>
        <Modal.Footer>
          <button
            className="btn btn-gradient-dark btn-rounded btn-icon-text btn-lg"
            variant="secondary"
            onClick={handleRtbClose}
          >
            Close
          </button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default UpdateRtbPartner;
