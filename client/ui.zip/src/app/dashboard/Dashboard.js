import React, { Component } from 'react';

export class Dashboard extends Component {


  render () {
    return (
      
        <div className="page-header">
          <h3 className="page-title">
             Dashboard 
             
          </h3>
          <nav aria-label="breadcrumb">
            <ul className="breadcrumb">
              <li className="breadcrumb-item active" aria-current="page">
                <span></span>Real-Time Revenue  <i className="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
              </li>
            </ul>
          </nav>
        </div>
        
      
    );
  }
}

export default Dashboard;