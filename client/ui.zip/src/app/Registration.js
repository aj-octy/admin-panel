import React from "react";
import { Row, Col} from 'react-bootstrap';
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { useHistory } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Registration() {
  
  let history = useHistory();
  const initialValues = {
    username: "",
    password: "",
  };

  const validationSchema = Yup.object().shape({
    username: Yup.string().min(3).max(15).required(),
    password: Yup.string().min(4).max(20).required(),
  });

  const onSubmit = (data) => {
    axios.post("http://localhost:5000/auth", data).then(() => {
      console.log(data);
      // history.push("/login");
    })
    .catch((err)=>toast.error(err.response.data))
    toast("welcome !", {
      position: "top-center",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      });
    history.push("/login");
    // setTimeout(()=> history.push("/login"), 2000)
  };

  return (
    <div>
      <div className="d-flex align-items-center auth px-0" style={{marginLeft: "-260px"}}>
        <div className="row w-100 mx-0">
          <div className="mx-auto">
            <div className="brand-logo">
                <img src={require("../assets/images/admin-logo-login.png")} alt="logo" />
            </div>
              <div className="auth-form-light text-left py-5 px-4 px-sm-5">  
              <h4 className="text-center login-text">Welcome Admin</h4>
                <div className="mt-3 ">
                  <Formik
                    initialValues={initialValues}
                    onSubmit={onSubmit}
                    validationSchema={validationSchema}
                  >
                    <Form>
                    <Row className="justify-content-md-center">
                      <Col  md={{  offset: 2 }}>
                        <ErrorMessage name="username" component="span" />
                      </Col>
                    </Row> 
                    <Row>
                      <Col sm="3">
                      <label>Username: </label>
                      </Col>
                      <Col sm="7">
                      
                      <Field
                        autocomplete="off"
                        id="inputCreatePost"
                        name="username"
                        placeholder="(Ex. John123...)"
                      />
                      
                      </Col>
                      </Row>

                      <label>Password: </label>
                      <ErrorMessage name="password" component="span" />
                      <Field
                        autocomplete="off"
                        type="password"
                        id="inputCreatePost"
                        name="password"
                        placeholder="Your Password..."
                      />

                      <button type="submit"> Register</button>
                    </Form>
                  </Formik>
                  <ToastContainer />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Registration;