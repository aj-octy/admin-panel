import * as React from "react";
import PropTypes from "prop-types";
import { useTheme } from "@mui/material/styles";
import { useState, useEffect } from "react";
import { Switch } from "@material-ui/core";
import { Form, Row, Col } from "react-bootstrap";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableContainer from "@mui/material/TableContainer";
import { tableCellClasses } from "@mui/material/TableCell";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import IconButton from "@mui/material/IconButton";
import FirstPageIcon from "@mui/icons-material/FirstPage";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import KeyboardArrowRight from "@mui/icons-material/KeyboardArrowRight";
import LastPageIcon from "@mui/icons-material/LastPage";
import { library } from "@fortawesome/fontawesome-svg-core";
import { faSearch } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Curd from '../common/Calls_methods'
import {toast} from 'react-toastify';
import {ADVERTISER_DASHBOARD} from '../config/Config'
import axios from 'axios';

library.add(faSearch);
const initialValue = { credit: "" };


function TablePaginationActions(props) {
  const theme = useTheme();
  const { count, page, rowsPerPage, onPageChange } = props;
  const handleFirstPageButtonClick = (event) => {
    onPageChange(event, 0);
  };
  const handleBackButtonClick = (event) => {
    onPageChange(event, page - 1);
  };
  const handleNextButtonClick = (event) => {
    onPageChange(event, page + 1);
  };
  const handleLastPageButtonClick = (event) => {
    onPageChange(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };
  return (
    <Box sx={{ flexShrink: 0, ml: 2.5 }}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === "rtl" ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton
        onClick={handleBackButtonClick}
        disabled={page === 0}
        aria-label="previous page"
      >
        {theme.direction === "rtl" ? (
          <KeyboardArrowRight />
        ) : (
          <KeyboardArrowLeft />
        )}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === "rtl" ? (
          <KeyboardArrowLeft />
        ) : (
          <KeyboardArrowRight />
        )}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === "rtl" ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </Box>
  );
}
TablePaginationActions.propTypes = {
  count: PropTypes.number.isRequired,
  onPageChange: PropTypes.func.isRequired,
  page: PropTypes.number.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
};
export default function Advertiser() {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(50);
  const [data, setData] = useState([]);
  const [emailDirection, setemailDirection] = useState("asc");
  const [companyDirection, setcompanyDirection] = useState("asc");
  const [nameDirection, setnameDirection] = useState("asc");
  const [countryDirection, setCountryDirection] = useState("asc");
  const [idDirection, setIdDirection] = useState("asc");
  const [addtimeDirection, setaddtimeDirection] = useState("asc");
  const [acctypeDirection, setacctypeDirection] = useState("asc");
  const [creditDirection, setCreditDirection] = useState("asc");

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const sortByCredit = () => {
    if (creditDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.id - a.id;
        })
      );
      setCreditDirection("desc");
    }
    if (creditDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setCreditDirection("asc");
    }
  };
  const sortByacctype = () => {
    if (acctypeDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.id - a.id;
        })
      );
      setacctypeDirection("desc");
    }
    if (acctypeDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setacctypeDirection("asc");
    }
  };
  const sortByaddtime = () => {
    if (addtimeDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.id - a.id;
        })
      );
      setaddtimeDirection("desc");
    }
    if (addtimeDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setaddtimeDirection("asc");
    }
  };
  const sortByCountry = () => {
    if (countryDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.id - a.id;
        })
      );
      setCountryDirection("desc");
    }
    if (countryDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setCountryDirection("asc");
    }
  };
  const sortById = () => {
    if (idDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.id - a.id;
        })
      );
      setIdDirection("desc");
    }
    if (idDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setIdDirection("asc");
    }
  };

  const sortByname = () => {
    if (nameDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.id - a.id;
        })
      );
      setnameDirection("desc");
    }
    if (nameDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setnameDirection("asc");
    }
  };
  const sortBycompany = () => {
    if (companyDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.id - a.id;
        })
      );
      setcompanyDirection("desc");
    }
    if (companyDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setcompanyDirection("asc");
    }
  };
  const sortByemail = () => {
    if (emailDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.email - a.email;
        })
      );
      setemailDirection("desc");
    }
    if (emailDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setemailDirection("asc");
    }
  };

  const [searchData, setSearchData] = useState("");

  useEffect(() => {
    
    getData(search.bidder_name);
  }, []);

  const getData = (search) => {    
    Curd.getTableData(`advertiser?${search}`, ).then((res) => {
      setData(res.data);
    });
  };



  // searching 

  const initialValueForSearch = { bidder_name:"" }
  const [search,setSearch] = useState(initialValueForSearch);
  const {bidder_name} = search;

  const onInputChange=(e)=>{
    setSearch(item1=>({bidder_name: e.target.value }));
  }
  
  const onSubmit = e => {
    e.preventDefault();
    let t = search.bidder_name
    getData(t);
  }


  // searching 


  const [user, setUser] = useState(initialValue);
  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - data.length) : 0;
  const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: "#21364e",
      color: theme.palette.common.white,
      fontSize: 15,
      height: 0,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    "&:nth-of-type(odd)": {
      backgroundColor: theme.palette.action.hover,
    },
    "&:last-child td, &:last-child th": {
      border: 0,
      height: 0,
    },
  }));

  const initialValueToggle = { activated: "yes" };
  const [state, setState] = useState(initialValueToggle);
  const { activated } = state;

  const handleChange = (e, index) => {

    let activated = e.target.checked ? "yes":"no";
    Curd.update(`advertiser/activated`,index,{activated: activated})
    .then(toast.success("Status Updated",{
      position: "top-right",
      autoClose: 4000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: false,
      draggable: true,
      progress: undefined,
      }))
  };

  let test = { acc_type: "internal" };
  const [values, setValue] = useState(test);

  const { acc_type } = values;

  const handleSelectChange = (e, select) => {
    const acc_type = e.target.value;
    console.log(acc_type)
    Curd.update(`advertiser/acc_type`, select,{
        acc_type: acc_type,
      })
      .then(toast.success("Account Type Updated",{
        position: "top-right",
        autoClose: 4000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        }));

  };

  const AntSwitch = styled(Switch)(({ theme }) => ({
    width: 28,
    height: 16,
    padding: 0,
    display: "flex",
    "&:active": {
      "& .MuiSwitch-thumb": {
        width: 15,
      },
      "& .MuiSwitch-switchBase.Mui-checked": {
        transform: "translateX(9px)",
      },
    },
    "& .MuiSwitch-switchBase": {
      padding: 2,
      "&.Mui-checked": {
        transform: "translateX(12px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          opacity: 1,
          backgroundColor:
            theme.palette.mode === "dark" ? "#177ddc" : "#1890ff",
        },
      },
    },
    "& .MuiSwitch-thumb": {
      boxShadow: "0 2px 4px 0 rgb(0 35 11 / 20%)",
      width: 12,
      height: 12,
      borderRadius: 6,
      transition: theme.transitions.create(["width"], {
        duration: 200,
      }),
    },
    "& .MuiSwitch-track": {
      borderRadius: 16 / 2,
      opacity: 1,
      backgroundColor:
        theme.palette.mode === "dark"
          ? "rgba(255,255,255,.35)"
          : "rgba(0,0,0,.25)",
      boxSizing: "border-box",
    },
  }));

  const advOnclick = (id)=>{
    let adminToken = localStorage.getItem("accessToken")
    const data = { adv_id: id,admin_id: localStorage.getItem("id") ,token:localStorage.getItem("accessToken")};
    console.log(id)

    axios.post("http://localhost:5000/auth/check",data).then((response) => {
      // if(response){}
      console.log(response)
      // console.log(response.data.error.name)
      if(!response.data.error){
          window.open(ADVERTISER_DASHBOARD+"/advertiser-login?id="+id+"?access_token="+adminToken, '_blank').focus();
      }else{console.log("no")}
    })




    // let token =  localStorage.getItem("accessToken")
    // axios.post("http://localhost:5000/auth/check",data).then((response) => {
    //   console.log("response.data : " +  response.data)
    //   console.log(response.data)
    //   window.open(ADVERTISER_DASHBOARD+"/advertiser/advertisers/"+id, '_blank').focus();
      

    // // =====================
    // const data = { username: response.data.email, password: response.data.password };
    // axios.post("http://localhost:5000/auth/vadmin-advertiser-login", data).then((response) => {
    //   console.log(response)
    //   console.log("response.data : " +  response.data)
    //   console.log("response.data.username : " +  response.data.username)
      
    //   if (response.data.error){
    //     alert(response.data.error);

    //   }
    // })
    // // =====================

    // })



  }
  

  return (
    <>
        <h3>Advertisers</h3>

      <Form onSubmit={(e) => onSubmit(e)}>
        <Row>
          <Col xs="4">
            <Form.Control
              className="form-control customInput"
              type="text"
              name="bidder_name"
              // value={""}
              placeholder="Search Advertisers"
              onChange={(e) => onInputChange(e)}
            />
          </Col>
          <button
            type="submit"
            className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
            >Search <FontAwesomeIcon icon="search" />
          </button>
        </Row>
      </Form>
      <br />
      
      <Paper sx={{ overflow: 'hidden' }}>
        <TableContainer className='tablewidth'>
          <Table sx={{ minWidth: 1600 }} size='small' stickyHeader aria-label="customized table">
            
            <TableHead sx={{width: '100%'}}>
              <StyledTableRow>
                      <StyledTableCell align='left' style={{position: "sticky", left:0,zIndex:3}} >Advertiser Email</StyledTableCell>
                      <StyledTableCell align="left" >Company Name</StyledTableCell>
                      <StyledTableCell align="left" >Name </StyledTableCell>
                      <StyledTableCell align='left' >Status</StyledTableCell>
                      <StyledTableCell align="left" >Country</StyledTableCell>
                      <StyledTableCell align="left" >id</StyledTableCell>
                      <StyledTableCell align="left" >Add Time</StyledTableCell>
                      <StyledTableCell align="center" >Account Type</StyledTableCell>
                      <StyledTableCell align="center" >Credit Amount</StyledTableCell>
                      <StyledTableCell align="center"></StyledTableCell>
              </StyledTableRow>
            </TableHead>

            
            <TableBody sx={{width: '100%'}}>

              {(rowsPerPage > 0
                ? data.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                : data
              ).map((row,index) => (
                    <StyledTableRow  align="right" key={row.id}>
                    <StyledTableCell key={index} style={(index % 2) ? { position: "sticky", left: 0,background: "white" } : { position: "sticky", left: 0,background: "whitesmoke" }}>
                    {/* <a href={ADVERTISER_DASHBOARD+"/advertiser/advertisers"} target="_blank">{row.email}</a>   */}
                    <a onClick={() => advOnclick(row.id)} target="_blank">{row.email}</a>  
                    </StyledTableCell>
                    <StyledTableCell >{row.company_name}</StyledTableCell>
                    <StyledTableCell >{row.name}</StyledTableCell>
                    <StyledTableCell>
                      <AntSwitch inputProps={{ 'aria-label': 'ant design' }} 
                        color='primary'
                        size='small'
                        defaultChecked={row.activated == "yes" ?  true : false}
                        onChange={(e)=>handleChange(e,row.id) }
                        name="activated"
                      />
                    </StyledTableCell>
                    <StyledTableCell>{row.country}</StyledTableCell>
                    <StyledTableCell>{row.id}</StyledTableCell>
                    <StyledTableCell>{row.addtime}</StyledTableCell>
                    <StyledTableCell >
                        <div className='container p-0'>
                            <select className="form-control tableDropDown" onChange={(e)=>handleSelectChange(e,row.id)} name="acc_type" style={{width:"100px"}}>
                                <option selected={row.acc_type == "external"} value="external" >external</option>
                                <option selected={row.acc_type == "internal"} value="internal" >internal</option>
                            </select>
                        </div>
                    </StyledTableCell>
                    <StyledTableCell >{row.credit}</StyledTableCell>
                    <StyledTableCell>
                    </StyledTableCell>
                  </StyledTableRow>
              ))}
              {emptyRows > 0 && (
                <StyledTableRow style={{ height: 53 * emptyRows }}>
                  <TableCell colSpan={10} />
                </StyledTableRow>
              )}

            </TableBody>
            

            


          </Table>
        </TableContainer>
      </Paper>
      {/* <Footer> */}
      <Paper>
          <TableContainer>
              <Table>
                  <TableBody>
                      <TablePagination
                        rowsPerPageOptions={[50, 100, 200, 250, { label: 'All', value: -1 }]}
                        count={data.length}
                        rowsPerPage={rowsPerPage}
                        page={page}
                        SelectProps={{
                          inputProps: {
                            'aria-label': 'rows per page',
                          },
                          native: true,
                        }}
                        onPageChange={handleChangePage}
                        onRowsPerPageChange={handleChangeRowsPerPage}
                        ActionsComponent={TablePaginationActions}
                      />
                  </TableBody>
              </Table>
            </TableContainer>
        </Paper>


    </>
  );
}
