import React,{useState, useEffect} from "react";
import styles from "../../styles.module.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { Row, Col, Container } from "react-bootstrap";
import { Form } from "react-bootstrap";
import { library } from "@fortawesome/fontawesome-svg-core";
import { faSave } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import axios from 'axios';
import {useParams, useHistory} from 'react-router-dom';
import {toast} from 'react-toastify';
// import UpdateApproveList from './UpdateApproveList';
// import UpdateBlockList from './UpdateBlockList'
import { event } from "jquery";
library.add(faSave);
const initialValue={
  ApproveThisList: "salman", 
  BlockThisList: "block", 
  BidderId: "",
  BidderCurrency:"USD",
  BidderModel:"CPM",
  tagid:"",
  BidderType:"rtb21",
  BidderPrice: "0",
  BidderAdformat: "video",
  BidderAuctionType: "first_price_auction",
  SecurityType: "protocol_relative_url",
  BidderUrl: "",
  viewability_score:"",
  BidderWinUrl: "",
  DailyFreqPerDeviceId: "-1",
  IsVdopiaBidder: "",
  BidderVdopiaMargin: "50",
  bidRequestCompression: "",
  IsAppIdEncoding: "",
  GdprApplicability: "",
}
function AddConnection() {
  let history = useHistory();
  const { id } = useParams();
  if(id==""){createBidder=''}
  const [createBidder,setBidder]=useState(initialValue);
  const [checked, setChecked] = useState(false);
  const [checkedvpaid, setCheckedVpaid] = useState(false);
  const [checkedmraid, setCheckedmraid] = useState(false);
  //For Other Filters Fropdown
  const [visibleSkippable, setVisibleSkippable]= useState(false);
  const [visibleAutoplay, setvisibleAutoplay]= useState(false);
  const [visibleadsizedesktop, setAdsizedesktop]= useState(false);
  const [visibleadsizemt, setVisibleadsizemt]=useState(false);
  const [visiblesound, setVisiblesound]=useState(false);
  const [visibleincentivized, setVisibleincentivized]=useState(false);
  const [visibleinstream,setVisibleinstream]=useState(false);
  const [visibleclickable, setVisibleclickable]=useState(false);
  const [visibleintegration, setVisibleintegration]=useState(false);
  const [visibleifa, setVisibleifa]=useState(false);
  const [visiblegpslatlong, setVisiblegpslatlong]=useState(false);
  const [visibleviewability, setVisibleviewability]=useState(false);
  const [visiblevdoadformat, setVisiblevdoadformat]=useState(false);
  const [visibledomainnamebundleid, setVisibledomainnamebundleid]=useState(false);
  const [visibleadunitfilter, setVisibleadunitfilter]=useState(false);
  const [visiblehandleRtb21, setVisiblehandleRtb21]=useState(false);
  const [visibleDealIdTargeting, setVisibleDealIdTargeting]=useState(false);
  const [visiblehandleunlimited, setVisiblehandleunlimited]=useState(true);
  const [visiblehandlevpaid, setVisiblevpaid]=useState(false);
  const [visiblehandlemraid, setVisibleMraid]=useState(false);
  const handleClick=(e)=>{
    const otherfiltersvalue=e.target.value;
    console.log(otherfiltersvalue);
    if(otherfiltersvalue == "skippable"){
      setVisibleSkippable(true);
    }else if(otherfiltersvalue == "autoplay"){
      setvisibleAutoplay(true);
    }else if(otherfiltersvalue == "adsizedesktop"){
      setAdsizedesktop(true);
    }else if(otherfiltersvalue == "adsizemt"){
      setVisibleadsizemt(true);
    }else if(otherfiltersvalue == "sound"){
      setVisiblesound(true);
    }else if(otherfiltersvalue == "incentivized"){
      setVisibleincentivized(true);
    }else if(otherfiltersvalue == "instream"){
      setVisibleinstream(true);
    }else if(otherfiltersvalue == "clickable"){
      setVisibleclickable(true);
    }else if(otherfiltersvalue == "integration"){
      setVisibleintegration(true);
    }else if(otherfiltersvalue == "ifa"){
      setVisibleifa(true);
    }else if(otherfiltersvalue == "gpslatlong"){
      setVisiblegpslatlong(true);
    }else if(otherfiltersvalue == "viewability"){
      setVisibleviewability(true);
    }else if(otherfiltersvalue == "vdoadformat"){
      setVisiblevdoadformat(true);
    }else if(otherfiltersvalue == "domainnamebundleid"){
      setVisibledomainnamebundleid(true);
    }else if(otherfiltersvalue == "adunitfilter"){
      setVisibleadunitfilter(true);
    }else if(otherfiltersvalue == "others"){
      alert("Please Select An Option")
    }
  }
  const handleRtb21=e=>{
    setVisiblehandleRtb21(true);
    setVisibleDealIdTargeting(false);
  }
  const handleRtb22=e=>{
    setVisiblehandleRtb21(true);
    setVisibleDealIdTargeting(false);
  }
  const handleRtb24=e=>{
    setVisiblehandleRtb21(true);
    setVisibleDealIdTargeting(false);
  }
  const handleVastFixedPrice=e=>{
    setVisiblehandleRtb21(false);
    setVisibleDealIdTargeting(true);
  }
  const handleVastVdopiaExtnPrice=e=>{
    setVisiblehandleRtb21(false);
    setVisibleDealIdTargeting(true);
  }
  const handleVpaidFixedPrice=e=>{
    setVisiblehandleRtb21(false);
    setVisibleDealIdTargeting(true);
  }
  const handleVpaidVdopiaExtnPrice=e=>{
    setVisiblehandleRtb21(false);
    setVisibleDealIdTargeting(true);
  }
  //For Handle Approve Pop Up
  const initialapprovevalue={ApproveThisList : ""}
  const [user,setUser]=useState(initialapprovevalue)
  const handleApprove=(ApproveData)=>{
    setUser(ApproveData);
    handleApproveShow();
  }
  const onApproveInputChange=e=>{
    setUser({ ...user, [e.target.name]: e.target.value });
    console.log(user);
  }
  const onApproveSubmit=e=>{
    e.preventDefault();
    console.log(user.ApproveThisList);
    console.log(initialapprovevalue);
    handleApproveClose();
  }
  const [showApprove, setShowApprove]=useState(false)
  const handleApproveClose= () =>setShowApprove(false);
  const handleApproveShow= () =>setShowApprove(true);
  //END: For Handle Approve Pop Up
  //For HandleBlock Pop Up
  const initialblockvalue={BlockThisList : ""}
  const [blockeduser, setBlockedUser]=useState(initialblockvalue)
  const handleBlock=(BlockedData)=>{
    setBlockedUser(BlockedData)
    handleBlockShow();
  }
  const onBlockedInputChange=e=>{
    setBlockedUser({ ...blockeduser, [e.target.name]: e.target.value });
    console.log(blockeduser);
  }
  const onBlockedSubmit=e=>{
    e.preventDefault();
    console.log("****************************")
    console.log(blockeduser.BlockThisList);
    console.log(initialblockvalue);
    console.log("****************************")
    handleBlockClose();
  }
  const [showBlock, setShowBlock]=useState(false)
  const handleBlockClose =()=>setShowBlock(false);
  const handleBlockShow=()=>setShowBlock(true);
  //END For Handle Block Pop Up
  const handleClickClose=e=>{
    setVisibleSkippable(false);
  }
  const handleAutoPlayClose=e=>{
    setvisibleAutoplay(false)
  }
  const handleClickAdSizeDesktopClose=e=>{
    setAdsizedesktop(false)
  }
  const handleClickAdSizeMTClose=e=>{
    setVisibleadsizemt(false)
  }
  const handleSoundClose=e=>{
    setVisiblesound(false)
  }
  const handleIncentivizedClose=e=>{
    setVisibleincentivized(false)
  }
  const handleInstreamClose=e=>{
    setVisibleinstream(false)
  }
  const handleClickableClose=e=>{
    setVisibleclickable(false)
  }
  const handleClickIntegrationClose=e=>{
    setVisibleintegration(false)
  }
  const handleIfaClose=e=>{
    setVisibleifa(false)
  }
  const handleGpsLatLongClose=e=>{
    setVisiblegpslatlong(false)
  }
  const handleViewAbilityClose=e=>{
    setVisibleviewability(false)
  }
  const handleClickVdoAdFormatClose=e=>{
    setVisiblevdoadformat(false)
  }
  const handleDomainBundleClose=e=>{
    setVisibledomainnamebundleid(false)
  }
  const handleClickAdUnitFilterClose=e=>{
    setVisibleadunitfilter(false)
  }
//For Other Filters Fropdown
  const getData = () => {
    axios(`http://localhost:5000/hudsonBidder/${id}`).then((res) => {
        setBidder(res.data);     
    });
  }
  useEffect(() => {
    if(id !=  undefined){
    getData()
    }else if(id == ''){
    alert('no id found')
  }
    // getData()
  }, []);
    const { BidderIdentifier,
          BidderId,BidderCurrency,BidderModel,
          tagid,BidderType,BidderPrice,BidderAdformat,
          BidderAuctionType,BidderUrl,viewability_score,SecurityType,
          // ClientSideUnwrapping,
          BidderWinUrl,DailyFreqPerDeviceId,ApproveThisList, BlockThisList,
          IsVdopiaBidder,BidderVdopiaMargin, bidRequestCompression, IsAppIdEncoding, GdprApplicability } = createBidder;
    const onInputChange = e => {
      setBidder({ ...createBidder, [e.target.name]: e.target.value });
      console.log(e.target.value)
      };
      const getRandomNumber = (min, max) => {
        const num= Math.floor(Math.random() * (max - min + 1)) + min;
        console.log("{{{{{{{{{{{{{{{{{{{{")
        console.log(num);
        console.log("}}}}}}}}}}}}}}}}}}}}")
      };
//   const onInputChangeCheck = e => {
//     const { value, checked } = e.target;
//     if(checked){
//         setBidder(item1=>({
//             ...item1,[e.target.name]: [...item1[e.target.name], e.target.value]
//         }));
//     }else{
//         setBidder(item1=>({
//             ...item1,ClientSideUnwrapping: ClientSideUnwrapping.filter((e) => e !== value)
//         }));
//     }
// }
  const onSubmit = e => {
    e.preventDefault();
        id !=  undefined ? 
        axios.put(`http://localhost:5000/hudsonBidder/${id}`, createBidder)
        .then(()=>{console.log(createBidder) 
         toast.success("Bidder Updated !",{
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            });}) 
        :
        axios.post(`http://localhost:5000/hudsonBidder`, createBidder)
        .then(()=>{console.log("data inserted" + createBidder) 
         toast.success("Bidder Added !",{
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            });})
  };
  return (
    <><div>
      <div align="left" className={styles.container}>
        <h4>Create Connection {id}</h4>
      </div>
      <div className="container-fluid">
        {/* Connection Details */}
        <div className="row">
          <div className="col-md-12">
            <Form onSubmit={e => onSubmit(e)}>
              <div>
                <fieldset>
                  <legend>Connection Details</legend>
                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right">
                      Connection ID
                    </label>
                    <div className="col-sm-9">
                      <p
                        className="mt-1"
                        // onChange={e => onInputBidderIdChange(e)}
                      >{createBidder.BidderId || ""}</p>
                    </div>
                  </Form.Group>
                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right">
                      Currency
                    </label>
                    <div className="col-sm-9">
                      <p className="mt-1">
                        {createBidder.BidderCurrency || ""}
                      </p>
                    </div>
                  </Form.Group>
                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right">
                      Pricing Units
                    </label>
                    <div className="col-sm-9">
                      <p className="mt-1">{createBidder.BidderModel || ""}</p>
                    </div>
                  </Form.Group>
                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right">
                      Connection Identifier
                    </label>
                    <div className="col-sm-4">
                      <Form.Control
                        className="form-control customInput"
                        type="text"
                        name="BidderIdentifier"
                        value={BidderIdentifier || ''}
                        onChange={e => onInputChange(e)} />
                    </div>
                  </Form.Group>
                  <Form.Group className="row mb-3">
                    <label className="col-sm-2 col-form-label text-right">
                      Seat
                    </label>
                    <div className="col-sm-4">
                      <textarea
                        className="form-control customTextarea"
                        id="exampleTextarea1"
                        rows="4"
                      ></textarea>
                    </div>
                  </Form.Group>
                  <Form.Group className="row">
                    <label className="col-sm-2 col-form-label text-right">
                      Tag Id
                    </label>
                    <div className="col-sm-4">
                      <Form.Control
                        className="form-control customInput"
                        type="text"
                        name="tagid"
                        value={createBidder.tagid || ""}
                        onChange={e => onInputChange(e)} />
                    </div>
                  </Form.Group>
                </fieldset>
              </div>
              {/* Connection Details */}
              {/* Ad Request Setup  */}
              <div className="row mt-4">
                <div className="col-md-12">
                  <div>
                    <fieldset>
                      <legend>Ad Request Setup</legend>
                      <Form.Group className="row">
                        <label className="col-sm-2 col-form-label text-right">
                          Connection Type
                        </label>
                        <div className="col text-left">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderType"
                                value="rtb21"
                                checked={createBidder.BidderType == "rtb21"}
                                onChange={e => onInputChange(e)}
                                onClick={handleRtb21} />
                              OpenRTB 2.1
                              <i className="input-helper"></i>
                            </label>
                          </div>
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderType"
                                value="rtb22"
                                checked={createBidder.BidderType == "rtb22"}
                                onChange={e => onInputChange(e)}
                                onClick={handleRtb22} />
                              OpenRTB 2.2
                              <i className="input-helper"></i>
                            </label>
                          </div>
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderType"
                                value="rtb24"
                                checked={createBidder.BidderType == "rtb24"}
                                onChange={e => onInputChange(e)}
                                onClick={handleRtb24} />
                              OpenRTB 2.4
                              <i className="input-helper"></i>
                            </label>
                          </div>
                          <div className="row">
                            <div className="col-md-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="BidderType"
                                    value="vast_fixed_price"
                                    checked={createBidder.BidderType == "vast_fixed_price"}
                                    onChange={e => onInputChange(e)}
                                    onClick={handleVastFixedPrice}
                                     />
                                  VAST Fixed Price
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-md-8">
                              <div className="row">
                                <div className="col-md-3 text-right mt-1">
                                  <p>Price (in CPM):</p>
                                </div>
                                <div className="col-md-4">
                                  <Form.Group>
                                    <div className="input-group">
                                      <Form.Control
                                        type="text"
                                        className="form-control customInput"
                                        placeholder="5.00"
                                        name="BidderPrice"
                                        value={createBidder.BidderPrice || ""}
                                        disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24' || createBidder.BidderType=='vast_vdopia_extn_price' || createBidder.BidderType=='vpaid_fixed_price' || createBidder.BidderType=='vpaid_vdopia_extn_price'}
                                        onChange={e => onInputChange(e)} />
                                      <div className="input-group-prepend">
                                        <span
                                          style={{
                                            borderRadius: "0px 5px 5px 0px",
                                          }}
                                          className="input-group-text"
                                        >
                                          $
                                        </span>
                                      </div>
                                    </div>
                                  </Form.Group>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderType"
                                value="vast_vdopia_extn_price"
                                checked={createBidder.BidderType == "vast_vdopia_extn_price"}
                                onChange={e => onInputChange(e)} 
                                onClick={handleVastVdopiaExtnPrice}/>
                              VAST with Vdopia Extension Price
                              <i className="input-helper"></i>
                            </label>
                          </div>
                          <div className="row">
                            <div className="col-md-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="BidderType"
                                    value="vpaid_fixed_price"
                                    checked={createBidder.BidderType == "vpaid_fixed_price"}
                                    onChange={e => onInputChange(e)}
                                    onClick={handleVpaidFixedPrice} />
                                  VPAID Fixed Price
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-md-8">
                              <div className="row">
                                <div className="col-md-3 text-right mt-1">
                                  <p>Price (in CPM):</p>
                                </div>
                                <div className="col-md-4">
                                  <Form.Group>
                                    <div className="input-group">
                                      <Form.Control
                                        type="text"
                                        className="form-control customInput"
                                        placeholder="5.00"
                                        name="BidderPrice"
                                        value={createBidder.BidderPrice || ""}
                                        onChange={e => onInputChange(e)}
                                        disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24' || createBidder.BidderType=='vast_vdopia_extn_price' || createBidder.BidderType=='vast_fixed_price' || createBidder.BidderType=='vpaid_vdopia_extn_price'}
                                         />
                                      <div className="input-group-prepend">
                                        <span
                                          style={{
                                            borderRadius: "0px 5px 5px 0px",
                                          }}
                                          className="input-group-text"
                                        >
                                          $
                                        </span>
                                      </div>
                                    </div>
                                  </Form.Group>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderType"
                                value="vpaid_vdopia_extn_price"
                                checked={createBidder.BidderType == "vpaid_vdopia_extn_price"}
                                onChange={e => onInputChange(e)}
                                onClick={handleVpaidVdopiaExtnPrice} />
                              VAST with Vdopia Extension Price
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                      </Form.Group>
                    {  visiblehandleRtb21 &&
                      <Form.Group className="row">
                        <label className="col-sm-2 col-form-label text-right">
                          Ad Format
                        </label>
                        <div className="col-md-2">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderAdformat"
                                value="video"
                                checked={createBidder.BidderAdformat == "video"}
                                onChange={e => onInputChange(e)} />
                              Video
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                        <div className="col-md-3">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderAdformat"
                                value="bannerNinterstitial"
                                checked={createBidder.BidderAdformat == "bannerNinterstitial"}
                                onChange={e => onInputChange(e)} />
                              Banner/Interstitial
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                      </Form.Group>
                    }
                      <Form.Group className="row">
                        <label className="col-sm-2 col-form-label text-right">
                          Auction Type
                        </label>
                        <div className="col-md-2">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderAuctionType"
                                value="first_price_auction"
                                checked={createBidder.BidderAuctionType == "first_price_auction"}
                                onChange={e => onInputChange(e)}
                                disabled={createBidder.BidderType=='vast_vdopia_extn_price' || createBidder.BidderType=='vast_fixed_price' || createBidder.BidderType=='vpaid_vdopia_extn_price' || createBidder.BidderType=='vpaid_fixed_price'} />
                              First Price Auction
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                        <div className="col-md-3">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderAuctionType"
                                value="second_price_auction"
                                checked={createBidder.BidderAuctionType == "second_price_auction"}
                                onChange={e => onInputChange(e)}
                                disabled={createBidder.BidderType=='vast_vdopia_extn_price' || createBidder.BidderType=='vast_fixed_price' || createBidder.BidderType=='vpaid_vdopia_extn_price' || createBidder.BidderType=='vpaid_fixed_price'} />
                              Second Price Auction
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                        <div className="col-md-2">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderAuctionType"
                                value="both"
                                checked={createBidder.BidderAuctionType == "both"}
                                onChange={e => onInputChange(e)} 
                                disabled={createBidder.BidderType=='vast_vdopia_extn_price' || createBidder.BidderType=='vast_fixed_price' || createBidder.BidderType=='vpaid_vdopia_extn_price' || createBidder.BidderType=='vpaid_fixed_price'}/>
                              Both
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                      </Form.Group>
                      <Form.Group className="row mb-3">
                        <label className="col-sm-2 col-form-label text-right">
                          VAST Tag URL
                        </label>
                        <div className="col-sm-7">
                          <textarea
                            className="form-control customTextarea"
                            rows="2"
                            name="BidderUrl"
                            value={createBidder.BidderUrl || ""}
                            onChange={e => onInputChange(e)}
                          ></textarea>
                        </div>
                      </Form.Group>
                      <Form.Group className="row">
                        <label className="col-sm-2 col-form-label text-right">
                          Security Type
                        </label>
                        <div className="col-md-3">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="SecurityType"
                                value="protocol_relative_url"
                                checked={createBidder.SecurityType == "protocol_relative_url"}
                                onChange={e => onInputChange(e)} />{" "}
                              Protocol Relative URL
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                        <div className="col-md-3">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="SecurityType"
                                value="secure_only_url"
                                checked={createBidder.SecurityType == "secure_only_url"}
                                onChange={e => onInputChange(e)} />
                              Secure Only URL
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                        <div className="col">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="SecurityType"
                                value="non_secure_only_url"
                                checked={createBidder.SecurityType == "non_secure_only_url"}
                                onChange={e => onInputChange(e)} />
                              Non-Secure Only URL
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                      </Form.Group>
                      {/* <Form.Group className="row">
                        <label className="col-sm-2 col-form-label text-right"></label>
                        <div className="col">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input type="checkbox"
                                className="form-check-input"
                                onChange={e => onInputChangeCheck(e)}
                                name="ClientSideUnwrapping"
                                value="1"
                                checked={Array.isArray(createBidder.ClientSideUnwrapping) && createBidder.ClientSideUnwrapping?.find(item => item == "1") ? true : "0"} />
                              <i className="input-helper"></i>
                              This is a client side unwrapping VAST Tag
                            </label>
                          </div>
                        </div>
                      </Form.Group> */}
                      <Form.Group className="row">
                        <label className="col-sm-2 col-form-label text-right">
                          Win Notice URL
                        </label>
                        <div className="col-sm-7">
                          <Form.Control
                            className="form-control customInput"
                            type="text"
                            name="BidderWinUrl"
                            value={createBidder.BidderWinUrl || ""}
                            onChange={e => onInputChange(e)}
                            />
                        </div>
                      </Form.Group>
                      <Form.Group className="row">
                        <label className="col-sm-2 col-form-label text-right">
                          Frequency Cap (Device ID Level) VAST Only
                        </label>
                        <div className="col text-left">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="DailyFreqPerDeviceId"
                                value="-1"
                                checked={createBidder.DailyFreqPerDeviceId == "-1"}
                                onChange={(e)=>onInputChange(e)}
                                disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24'}
                                />
                              None
                              <i className="input-helper"></i>
                            </label>
                          </div>
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="DailyFreqPerDeviceId"
                                value="1"
                                checked={createBidder.DailyFreqPerDeviceId == "1"}
                                onChange={(e)=>onInputChange(e)}
                                disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24'}
                                />
                              1 per unique device ID per day
                              <i className="input-helper"></i>
                            </label>
                          </div>
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="DailyFreqPerDeviceId"
                                value="2"
                                checked={createBidder.DailyFreqPerDeviceId == "2"}
                                onChange={(e)=>onInputChange(e)}
                                disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24'}
                                />
                              1 per unique device ID per day
                              <i className="input-helper"></i>
                            </label>
                          </div>
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="DailyFreqPerDeviceId"
                                value="3"
                                checked={createBidder.DailyFreqPerDeviceId =="3"}
                                onChange={(e)=>onInputChange(e)}
                                disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24'}
                                 />
                              3 per unique device ID per day
                              <i className="input-helper"></i>
                            </label>
                          </div>
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="DailyFreqPerDeviceId"
                                value="4"
                                checked={createBidder.DailyFreqPerDeviceId == "4"}
                                disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24'}
                                />
                              5 per unique device ID per day
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                      </Form.Group>
                      { visibleDealIdTargeting &&
                      <Form.Group className="row">
                        <label className="col-sm-2 col-form-label text-right">
                          Deal ID Targeting
                        </label>
                        <div className="col-sm-7">
                          <Form.Control
                            className="form-control customInput"
                            type="text" />
                        </div>
                      </Form.Group>
                    }
                    </fieldset>
                    <br />
                    <div>
                    <fieldset>
                            <legend>Performance Metrics</legend>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right"> Viewability Score</label>
                                <div className="col-sm-3">
                                    <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        name="viewability_score"
                                        value={createBidder.viewability_score || ""}
                                        onChange={e => onInputChange(e)}
                                    />
                                </div>
                                <div className='col-sm-3' align='left'>
                                [Range 0 to 1]
                                </div>
                            </Form.Group>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right"> Video Completetion Rate</label>
                                <div className="col-sm-3">
                                    <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        name="vtr"
                                        // value={packages.vtr || ""}
                                        onChange={e => onInputChange(e)}
                                    />
                                    {/* <div className='col-sm-3' align='left'>
                                        [Range 0 to 1]
                                    </div> */}
                                    <div className="controls min-controls" style={{color: "#49afcd" ,fontSize: "13px"}}>
                                        <b>Note: </b>This performance metrics will be applicable for video inventory only
                                    </div>
                                </div>
                            </Form.Group>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right"> Click Through Rate</label>
                                <div className="col-sm-3">
                                    <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        name="ctr"
                                        // value={packages.ctr || ""}
                                        onChange={e => onInputChange(e)}
                                    />
                                </div>
                                <div className='col-sm-3' align='left'>
                                [Range 0 to 1]
                                </div>
                            </Form.Group>
                        </fieldset>
                    </div>
                    <div>
                      <fieldset>
                        <legend>Ads.Txt and Seller Filter</legend>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Ads.Txt Domains
                          </label>
                          <div className="col-sm-4">
                            <Form.Control
                              className="form-control customInput"
                              type="text"
                              name="BidderIdentifier" />
                          </div>
                          <div className="col">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                Selected
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            AdsTxt
                          </label>
                          <div className="col">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                Ads.txt enabled for selected domain(s)
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Seller Enabled
                          </label>
                          <div className="col">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" disabled />
                                <i className="input-helper"></i>
                                Seller enabled for selected domain(s)
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Account Type
                          </label>
                          <div className="col">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" />
                                <i className="input-helper"></i>
                                RESELLER
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-8">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                REDIRECT
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Supply Chain Applicability
                          </label>
                          <div className="col-md-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="auctionType"
                                  id="membershipRadios1"
                                  defaultChecked />{" "}
                                All
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                          <div className="col-md-3">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="auctionType"
                                  id="membershipRadios2" />{" "}
                                Complete Only(complete=1)
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        {/* <Form.Group className="row">
    <label className="col-sm-2 col-form-label text-right"></label>
    <div className="col">
      <div className="form-check">
        <label className="form-check-label">
          <input type="checkbox" className="form-check-input" />
          <i className="input-helper"></i>
          This is a client side unwrapping VAST Tag
        </label>
      </div>
    </div>
  </Form.Group> */}
                      </fieldset>
                    </div>
                    <br />
                    <div>
                      <fieldset>
                        <legend>Request Filters</legend>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Supported Request Types
                          </label>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                // onChange={e => onInputChangeTypeCheck(e)}
                                // name="adRequestType"
                                // value="1"
                                // checked={(createBidder.adRequestType ) && createBidder.adRequestType?.find(item => item == "1") ? true : ""}
                                />
                                <i className="input-helper"></i>
                                VAST
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                // onChange={e => onInputChangeTypeCheck(e)}
                                name="adRequestType"
                                value="2"
                                checked={checkedvpaid}
                                onChange={()=>{
                                  if(checkedvpaid){
                                    setVisiblevpaid(false);
                                  }else{
                                    setVisiblevpaid(true);
                                  }
                                  setCheckedVpaid(!checkedvpaid);
                                }}
                                />
                                <i className="input-helper"></i>
                                VPAID
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                // onChange={e => onInputChangeTypeCheck(e)}
                                name="adRequestType"
                                value="3"
                                checked={checkedmraid}
                                onChange={()=>{
                                  if(checkedmraid){
                                    setVisibleMraid(false);
                                  }else{
                                    setVisibleMraid(true);
                                  }
                                  setCheckedmraid(!checkedmraid);
                                }}
                                />
                                <i className="input-helper"></i>
                                MRAID
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                // onChange={e => onInputChangeTypeCheck(e)}
                                name="adRequestType"
                                value="4"
                                // checked={Array.isArray(createBidder.adRequestType ) && createBidder.adRequestType?.find(item => item == "4") ? true : ""}
                                />
                                <i className="input-helper"></i>
                                JS
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Supported Bid Request Creative
                          </label>
                          { visiblehandlevpaid &&
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"></input>
                                <i className="input-helper"></i>
                                VPAID 2.0
                              </label>
                            </div>
                          </div>
                          }
                          { visiblehandlemraid &&
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                MRAID 1.0
                              </label>
                            </div>
                          </div>
                          }
                          { visiblehandlemraid &&
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                MRAID 2.0
                              </label>
                            </div>
                          </div>
                          }
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Maximum Requests/Second (QPS)
                          </label>
                          { visiblehandleunlimited &&
                              <div className="col-sm-4">
                                <Form.Control
                                  className="form-control customInput"
                                  type="text"
                                  name="BidderIdentifier"
                                  />
                              </div>
                          }
                          <div className="col">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                checked={checked}
                                onChange={()=>{
                                  if(checked){
                                    setVisiblehandleunlimited(true);
                                  }else{
                                    setVisiblehandleunlimited(false);
                                  }
                                  setChecked(!checked);
                                }}
                                />
                                <i className="input-helper"></i>
                                Unlimited
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Device Type
                          </label>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                Desktop
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                Mobile
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                Tablet
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                ConnectedTV
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Request Type
                          </label>
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="auctionType"
                                  id="membershipRadios1"
                                  defaultChecked />{" "}
                                Both(App And Site)
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="auctionType"
                                  id="membershipRadios2" />{" "}
                                App Only
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="auctionType"
                                  id="membershipRadios2" />{" "}
                                Site Only
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Device OS
                          </label>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="auctionType"
                                  id="membershipRadios1"
                                  defaultChecked />{" "}
                                All
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="auctionType"
                                  id="membershipRadios2" />{" "}
                                Android
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="auctionType"
                                  id="membershipRadios2" />{" "}
                                iOS
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            GDPR Applicability
                          </label>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name=""
                                  />{" "}
                                All
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="auctionType"
                                  id="membershipRadios2" />{" "}
                                True
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="auctionType"
                                  id="membershipRadios2" />{" "}
                                False
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">Other Filters</label>
                          <div className="col-sm-3">
                            <select className="form-control customDropDown" name="otherfilters"
                              style={{ width: "280px" }}
                              onChange={(e) => handleClick(e)}
                            >
                              <option value="others">Other Filters</option>
                              <option value="adsizedesktop">Ad Size Desktop</option>
                              <option value="adsizemt">Ad Size(Mobile/Tablet)</option>
                              <option value="skippable">Skippable-Yes/No</option>
                              <option value="sound">Sound On/Off</option>
                              <option value="autoplay">Autoplay-Yes/No</option>
                              <option value="incentivized">Incentivized-Yes/No</option>
                              <option value="instream">In-Stream - Yes/No</option>
                              <option value="clickable">Clickable - Yes/No</option>
                              <option value="integration">Integration Type</option>
                              <option value="ifa">Has IFA - Yes/No</option>
                              <option value="gpslatlong">Has GPS Based Lat/Long</option>
                              <option value="viewability">Viewability Measure</option>
                              <option value="vdoadformat">.VDO Ad Formats</option>
                              <option value="domainnamebundleid">Has Domain Name/Bundle ID-Yes</option>
                              <option value="adunitfilter">Ad Unit Filter(Desktop)</option>
                            </select>
                            {/* <br/> */}
                          </div>
                        </Form.Group>
                        {visibleSkippable &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Skippable-Yes/No
                            </label>
                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleClickClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibleAutoplay &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              AutoPlay-Yes/No
                            </label>
                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleAutoPlayClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibleadsizedesktop &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Ad Size Desktop
                            </label>
                            <div className="col text-left">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Small
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Medium
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Large
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleClickAdSizeDesktopClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibleadsizemt &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Ad Size(Mobile/Tablet)
                            </label>
                            <div className="col text-left">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  300 * 250
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  320 * 480
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  492 * 517
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Others
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleClickAdSizeMTClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visiblesound &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Sound-On/Off
                            </label>
                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  On
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  Off
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleSoundClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibleincentivized &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Incentivized-Yes/No
                            </label>
                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleIncentivizedClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibleinstream &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              In-Stream
                            </label>
                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleInstreamClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibleclickable &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Clickable-Yes/No
                            </label>
                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleClickableClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibleintegration &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Integration Type
                            </label>
                            <div className="col text-left">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Chocolate SSP
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Vdopia Direct
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Mediation Direct
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Indirect
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleClickIntegrationClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibleifa &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Has IFA-Yes/No
                            </label>
                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleIfaClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visiblegpslatlong &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Has GPS-based Lat/Long - Yes/No
                            </label>
                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleGpsLatLongClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibleviewability &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Viewability Measure
                            </label>
                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleViewAbilityClose}
                              >
                                Remove
                              </button>
                            </div>
                            {/* <Form.Group className="row"> */}
                            <div className="col-sm-2"></div>
                            <div className="col text-left">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Enable Moat Viewability Measurement
                                </label>
                              </div>
                            </div>
                          </Form.Group>}
                        {visiblevdoadformat &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              .VDO Ad Formats
                            </label>
                            <div className="col text-left">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Max. VDO
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  InView.VDO Push-Down
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  InView.VDO In-Line
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleClickVdoAdFormatClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibledomainnamebundleid &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Has Domain Name / Bundle ID - Yes
                            </label>
                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    disabled
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleDomainBundleClose}
                              >
                                Remove
                              </button>
                            </div>
                            {/* <Form.Group className="row"> */}
                            <div className="col-sm-2"></div>
                          </Form.Group>}
                        {visibleadunitfilter &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Ad Unit Filter(Desktop)
                            </label>
                            <div className="col text-left">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Interstitial
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  InBanner
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Outstream
                                </label>
                              </div>
                              <div className="form-check">
                                {/* <label className="form-check-label"> */}
                                Instream
                                {/* </label> */}
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Preroll
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Midroll
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Postroll
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Any
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                onClick={handleClickAdUnitFilterClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">Data Center Region</label>
                          <div className="col-sm-3">
                            <select className="form-control customDropDown" name="inventoryFilter"
                            >
                              <option value="adsize">Any Region</option>
                              <option value="adsizedesktop" defaultChecked>Region: us-west-2</option>
                              <option value="adsizemt">Region: us-east-1</option>
                              <option value="skippable">Region: eu-central-1</option>
                              <option value="gps">Region: ap-northeast-1</option>
                              <option value="ifa">Region: ap-southeast-1</option>
                              <option value="integration">Region: ap-southeast-1</option>
                            </select>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">Ad Skippable</label>
                          <div className="col-sm-6">
                            <select className="form-control customDropDown" name="inventoryFilter" style={{ width: "250px" }}
                            >
                              <option value="adsize">All</option>
                              <option value="adsizedesktop" defaultChecked>Yes</option>
                              <option value="adsizemt">No</option>
                            </select>
                            <div className="controls min-controls" style={{ color: "#49afcd", fontSize: "13px" }}>
                              <b>Note: </b>This Ad Duration metrics will be applicable for video inventory only
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">Ad Duration</label>
                          <div className="col-sm-6">
                            <select className="form-control customDropDown" name="inventoryFilter" style={{ width: "250px" }}
                            >
                              <option value="adsize">Any</option>
                              <option value="adsizedesktop" defaultChecked>15 seconds and above</option>
                              <option value="adsizemt">30 seconds and above</option>
                              <option value="skippable">60 seconds and above</option>
                              <option value="gps">90 seconds and above</option>
                            </select>
                            <div className="controls min-controls" style={{ color: "#49afcd", fontSize: "13px" }}>
                              <b>Note: </b>This Ad Skippable metrics will be applicable for matching with Ad-Request only
                            </div>
                          </div>
                        </Form.Group>
                      </fieldset>
                    </div>
                    <br />
                    <div>
                      <fieldset>
                        <legend>Vadmins Only</legend>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Vdopia Bidder
                          </label>
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="IsVdopiaBidder"
                                  value="1"
                                  checked={createBidder.IsVdopiaBidder == "1"}
                                  onChange={e => onInputChange(e)}
                                   />
                                Yes
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="IsVdopiaBidder"
                                  value="0"
                                  checked={createBidder.IsVdopiaBidder == "0"}
                                  onChange={e => onInputChange(e)}                                
                                  />
                                No
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Margin Percentage <br />(0-100)
                          </label>
                          <div className="col-sm-4">
                            <Form.Control
                              className="form-control customInput"
                              type="text"
                              name="BidderVdopiaMargin"
                              value={createBidder.BidderVdopiaMargin || ""} 
                              onChange={e => onInputChange(e)} 
                          />
                          </div>
                          <label className="col-sm-0 col-form-label text-left">
                            <span>
                              <strong>%</strong>  Vdopia Default is 50%
                            </span>
                          </label>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Companion Banner Resource Type
                          </label>
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                Static Resource
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                iFrame Resource
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Bid Request Compression
                          </label>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="bidRequestCompression"
                                  value="1"
                                  checked={createBidder.bidRequestCompression == "1"}
                                  onChange={e => onInputChange(e)}
                                   />{" "}
                                True
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="bidRequestCompression"
                                  value="0"
                                  checked={createBidder.bidRequestCompression == "0"}
                                  onChange={e => onInputChange(e)}
                                  />{" "}
                                False
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            App-Id Encoding
                          </label>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="IsAppIdEncoding"
                                  value="1"
                                  checked ={createBidder.IsAppIdEncoding == "1"}
                                  onChange={e => onInputChange(e)}
                                  />{" "}
                                Yes
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="IsAppIdEncoding"
                                  value="0"
                                  checked={createBidder.IsAppIdEncoding == "0"}
                                  onChange={e => onInputChange(e)}
                                  />
                                No
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                      </fieldset>
                    </div>
                    <br />
                    <div>
                      <fieldset>
                        <legend>Approve List</legend>
                        <div className="col-sm-4">
                          <div className="form-check">
                            <button
                              type="button"
                              className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                              onClick={() => handleApprove(createBidder.ApproveThisList)}
                            >
                              Add Apps Or Sites
                            </button>
                          </div>
                          <div className='box' style={{ height: "80px" }}>
                            <br />Sites(Domain):{user.ApproveThisList}
                          </div>
                        </div>
                      </fieldset>
                    </div>
                    <br />
                    <div>
                      <fieldset>
                        <legend>Block List</legend>
                        <div className="col-sm-4">
                          <div className="form-check">
                            <button
                              type="button"
                              className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                              onClick={()=> handleBlock(createBidder.BlockThisList)}
                            >
                              Add Apps Or Sites
                              <FontAwesomeIcon icon="save" />
                            </button>
                          </div>
                          <div className='box' style={{ height: "80px" }}>
                            <br />Sites(Domain):{blockeduser.BlockThisList}
                          </div>
                        </div>
                      </fieldset>
                    </div>
                    <br />
                    {/* <div>
      <fieldset>
          <legend>Publisher Channels</legend>
      <Form.Group className="row">
          <label className="col-sm-3 col-form-label text-right">
          Publisher Channels
          </label>
          <div className="col-sm-3">
            <Form.Control
              className="form-control customInput"
              placeholder="Find Channel..."
              type="text"
              name="BidderIdentifier"
              // value={BidderIdentifier || ''}
              // onChange={e => onInputChange(e)}
            />
          </div>
      </Form.Group>
      <Form.Group className="row">
          <div className="col-sm-auto"></div>
          <div className="col-sm-6 col-form-label">
          <div className="form-check">
          <label className="form-check-label">
            <input type="checkbox" className="form-check-input" />
            <i className="input-helper"></i>
            Showing 1 to 50 out of 506 entries
          </label>
        </div>
      </div>
      <div className="col-sm-3">
          <div className="form-check">
          <label className="form-check-label" >
            <input type="checkbox" className="form-check-input" />
            <i className="input-helper"></i>
            Showing 1 to 1 out of 1 entries
          </label>
        </div>
      </div>
      </Form.Group>
      </fieldset>
    </div> */}
                    <Form.Group className="row mt-4">
                      <label className="col-sm-2 col-form-label text-right"></label>
                      <div className="col-sm-9 ml-2">
                        <button
                          type="submit"
                          className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                          id="button" 
                          onClick={getRandomNumber}
                          // onclick={getElementById('random-number').value=Math.floor(Math.random()*10000)}
                        >
                          Submit
                          <FontAwesomeIcon icon="save" />
                        </button>
                      </div>
                    </Form.Group>
                  </div>
                </div>
              </div>
            </Form>
          </div>
        </div>
        {/* Ad Request Setup  */}
      </div>
    </div>
    {/* <UpdateApproveList showApprove={showApprove} handleApproveClose={handleApproveClose} onApproveInputChange={onApproveInputChange} onApproveSubmit={onApproveSubmit} /> */}
    {/* <UpdateBlockList showBlock={showBlock} handleBlockClose={handleBlockClose} onBlockedInputChange={onBlockedInputChange} onBlockedSubmit={onBlockedSubmit}/> */}
    </>
  );
}
export default AddConnection;