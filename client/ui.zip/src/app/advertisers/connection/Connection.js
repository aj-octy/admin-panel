import React, { useState } from "react";
import { useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import styles from "../../styles.module.css";
import { library } from "@fortawesome/fontawesome-svg-core";
import { faSearch, faPlus } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link } from "react-router-dom";

// import "rsuite-table/lib/less/index.less"; // or 'rsuite-table/dist/css/rsuite-table.css'
// import "../../"

library.add(faSearch, faPlus);

function Connection() {
  const [data, setData] = useState([]);

  const [name, setName] = useState([]);

  // const [action,setaction]

  useEffect(() => {
    getData();
  }, []);



  const getData = () => {
    axios("http://localhost:5000/hudsonBidder").then((res) => {
      //console.log(res.data);
      //setData(res.data);
      setData(res.data);
    });
  };


  const handleEdit = (EditData) => {
    console.log(EditData);
  
    
    console.log("***************")
      console.log("Edit");
      console.log("+++++++++++++++")
    // localStorage.setItem('id',rowId)
    
  };
  const handleDelete = () => {
  
    console.log("***************")
      console.log("Delete");
      console.log("+++++++++++++++")
    
  };

  


  return (
    <>
      <div align="left" className={styles.container}>
        <h4>Connection</h4>
        <div className="row mb-4">
          <div className="col-sm-8">
            <form className="form-inline">
              <input
                className="form-control form-control-md mr-4"
                type="text"
                placeholder="Search Advertisers..."
                aria-label="Search"
                onChange={(e) => {
                  setName(e.target.value);
                }}
              />
              <i class="fa-solid fa-cutlery"></i>
              <button
                type="button"
                className="btn btn-gradient-info btn-rounded btn-icon-text"
              >
                Search
                <FontAwesomeIcon icon="search" />
              </button>
            </form>
          </div>
          <div className="col-sm-4 text-right">
            <Link to={"/demand/addConnection"}>
              <button
                type="button"
                className="btn btn-gradient-info btn-rounded btn-icon-text"
              >
                Create
                <FontAwesomeIcon icon="plus" />
              </button>
            </Link>
          </div>
        </div>
      </div>

      {/* rsuit table  */}

      
      
    </>
  );
}

export default Connection;
