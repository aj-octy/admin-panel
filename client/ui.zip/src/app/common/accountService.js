import {BehaviorSubject} from 'rxjs';

const userSubject = new BehaviorSubject(localStorage.getItem('accessToken'));
export const accountService = {
	get userValue() {
		return userSubject._value;
	}
}
