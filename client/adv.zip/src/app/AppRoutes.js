import React, { Suspense, lazy, useState, useEffect } from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';
import axios from 'axios';
import Spinner from '../app/shared/Spinner';
import { AuthContext } from "../helpers/AuthContext";



const Dashboard = lazy(() => import('./dashboard/Dashboard'));




// User Profile 
const Login = lazy(() => import('./Login'));
const Registration = lazy(() => import('./Registration'));
// User Profile 

//Advertisers
const Advertisers = lazy(() => import('./advertisers/Advertiser'));
const Test = lazy(() => import('./advertisers/Test'));
const Connection = lazy(() => import('./advertisers/connection/Connection'));
const AddConnection = lazy(() => import('./advertisers/connection/AddConnection'));

//Advertisers



function AppRoutes() {
  
    return (
<>    
          <Route  path="/dashboard" component={ Dashboard } />
          <Route  path="/advertiser/advertisers" component={ Advertisers } />
          <Route  path="/test/:id?" component={ Test } />
          <Route  path="/advertiser/Connection" component={ Connection } />
          <Route  path="/advertiser/addConnection/:id?" component={ AddConnection } />
          <Route  path="/registration" component={ Registration } />
          <Route exact path="/"><Redirect to="/advertiser/advertisers" /></Route>
          
          </>
    );
  
}



function Page() {

  const [authState, setAuthState] = useState({
    username: "",
    id: 0,
    status: false,
  });

  const [load, setLoad] = useState(true);

  

  useEffect(() => {

    axios.get("http://localhost:5000/auth/auth",{
      headers:{
        accessToken: localStorage.getItem("accessToken")
      }
    }).then((response) => {
      
      if(response.data.error) {
        setAuthState({...authState, status: false});
      }else{
        setAuthState({
          username: response.data.username,
          id: response.data.id,
          status: true,
        });
      }
      setLoad(false);
    })

    
  },[])

  console.log("status---------:"  +  authState.status )

  return (
    <AuthContext.Provider value={{ authState, setAuthState }}>
      <Suspense fallback={<Spinner />}>
        {load ? <><Spinner animation="grow" /></>: 
        <Switch>
          <Route exact path="/advertiser-login" component={Login} />
          <Route  path="/advertiser-registration" component={ Registration } />
          <Route path="/">{authState.status ?  <><AppRoutes /></> : <Redirect to="/advertiser-login" exact/>}</Route>
          
        </Switch>}
        
      </Suspense>
    </AuthContext.Provider>
    )
}


export default Page;
