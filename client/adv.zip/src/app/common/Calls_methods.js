import axios from 'axios';
import {API_URL} from '../config/Config';
import {accountService} from './accountService'

function header() {
	const user = accountService.userValue;
	console.log(user)
	if (user != null) {
		const isLoggedIn = user;
		if (isLoggedIn) {
			return {
				Authorization: `Bearer ${user}`,
			};
		} else {
			return {};
		}
	} else {
		return {};
	}
}

const headers = {
	headers: header(),
};
const Crud = {
	all: (m) => {
		return axios.get(API_URL + '/' + m, headers);
	},
	create: (m,payload) => {
		return axios.post(API_URL + '/' + m , payload, headers);
	},
	details: (m) => {
		return axios.get(API_URL + '/' + m + '/', headers);
	},
	getData: (m , id) => {
		return axios.get(API_URL + '/' + m + '/' + id, headers);
	},
	getTableData: (m , payload) => {
		return axios.get(API_URL + '/' + m ,  payload, headers);
	},
	getTableDatas: (m ,payload, id ) => {
		return axios.get(API_URL + '/' + m + '/' +id, payload , headers);
	},
	update: (m, id, payload) => {
		return axios.put(API_URL + '/' + m + '/' + id, payload, headers);
	},
	delete: (m, id) => {
		return axios.delete(API_URL + '/' + m + '/' + id, headers);
	},
	upload: (m, data) => {
		return axios.post(API_URL + '/' + m, data, headers);
	},
	fetchData : (m ,id) => {
		return fetch(API_URL + '/' + m , id , headers);
	},
	fetchDatas : (m) => {
		return fetch(API_URL + '/' + m  , headers);
	},
	fetchData2 : (m,id,payload) => {
		return fetch(API_URL + '/' + m + '/' , payload , id , headers);
	}
};

export default Crud;