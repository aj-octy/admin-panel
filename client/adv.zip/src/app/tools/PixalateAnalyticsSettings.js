import React from 'react'

function PixalateAnalyticsSettings() {
  return (
    <div>PixalateAnalyticsSettings</div>
  )
}

export default PixalateAnalyticsSettings