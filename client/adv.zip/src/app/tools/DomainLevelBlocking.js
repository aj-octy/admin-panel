import React, { useState } from 'react';
import { useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Container,Row,Col } from 'react-bootstrap';
import {Dropdown} from 'react-bootstrap'


function DomainLevelBlocking() {

const [data,setData]=useState([]);

const [name,setName]=useState([]);

// const [action,setaction]
  
useEffect(()=>{
  getData();
},[]);


  

const getData=()=>{
  axios("http://localhost:5000/globally_blocked_domains").then((res)=> {
  //console.log(res.data);
  //setData(res.data);
  setData(res.data);
});
};



const handleDelete = (rowId, name) => {
  console.log(rowId, name);
  //1 YourCellName
};
const handleEdit = (rowId, name) => {
  console.log(rowId, name);
  //1 YourCellName
};

  return (
    <>
    {/* <div align="left" className={styles.container}> */}
        <h4>Domain Level Blocking</h4>
        <Container>
          <Row xs='auto'>
          
          
        <form className="form-inline mt-4 mb-4">
       
          <input style={{width:"250px"}} className="form-control form-control-sm"  type="text" placeholder="Search Domain/Bundle" aria-label="Search" onChange={(e)=>{
            setName(e.target.value)}} />
        
        <Col>
        <Dropdown style={{marginLeft:"10px"}} size='sm'>
        <Dropdown.Toggle variant="info">
          Platform
        </Dropdown.Toggle>
        <Dropdown.Menu>
          <Dropdown.Item href="#">
            Email
          </Dropdown.Item>
          <Dropdown.Item href="#">
            Product Id
          </Dropdown.Item>
          <Dropdown.Item href="#">
            Name
          </Dropdown.Item>
          <Dropdown.Item href="#">
            ID
          </Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
       
            
        </Col>
        <Col>
          <Button color="primary" size='sm' >Filter</Button>{' '}
          </Col>
        </form>
        </Row>
        </Container>
        <Container>
          <Row xs='auto'>
            
            <Button variant='success' size='sm'>Add New Domain/Bundle</Button>{' '}
            
            <Col>
            <Button variant='success' size='sm'>Delete</Button>{' '}
            </Col>
          </Row>
        </Container>
        <br/>
          
    {/* </div> */}

     
   
      </>
  )
}

export default DomainLevelBlocking