import React, { useState } from 'react';
import { useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Container,Row,Col } from 'react-bootstrap';
import {Dropdown} from 'react-bootstrap'


function DirectProperties() {

const [data,setData]=useState([]);

const [name,setName]=useState([]);

// const [action,setaction]
  
useEffect(()=>{
  getData();
},[]);


  

const getData=()=>{
  axios("http://localhost:5000/directProperties").then((res)=> {
  //console.log(res.data);
  //setData(res.data);
  setData(res.data);
});
};



const handleDelete = (rowId, name) => {
  console.log(rowId, name);
  //1 YourCellName
};
const handleEdit = (rowId, name) => {
  console.log(rowId, name);
  //1 YourCellName
};

  return (
    <>
    {/* <div align="left" className={styles.container}> */}
        <h4>Direct Properties - Site Domain And App Bundle</h4>
        <Container>
          <Row xs='auto'>
          
          
        <form className="form-inline mt-4 mb-4">
       
          <input style={{width:"250px"}} className="form-control form-control-sm"  type="text" placeholder="Search Domain/Bundle/Apikey..." aria-label="Search" onChange={(e)=>{
            setName(e.target.value)}} />
        
        <Col>
        <Dropdown style={{marginLeft:"10px"}} size='sm'>
        <Dropdown.Toggle variant="info">
          Columns
        </Dropdown.Toggle>
        <Dropdown.Menu>
          <Dropdown.Item href="#">
            Email
          </Dropdown.Item>
          <Dropdown.Item href="#">
            Product Id
          </Dropdown.Item>
          <Dropdown.Item href="#">
            Name
          </Dropdown.Item>
          <Dropdown.Item href="#">
            ID
          </Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
       
            
        </Col>
        <Col>
          <Button color="primary" size='sm' >Search</Button>{' '}
          </Col>
        </form>
        </Row>
        </Container>
        <Container>
          <Row xs='auto'>
            
            <Button variant='success' size='sm'>Active</Button>{' '}
            
            <Col>
            <Button variant='success' size='sm'>Inactive</Button>{' '}
            </Col>
          </Row>
        </Container>
        <br/>
          
    {/* </div> */}

     
   
      </>
  )
}

export default DirectProperties