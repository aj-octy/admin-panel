import React from 'react'

function FraudDataprovider() {
  return (
    <h2>Fraud Data Provider</h2>
  )
}

export default FraudDataprovider