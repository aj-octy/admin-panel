import React, { useState } from 'react';
import { useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Container,Row,Col } from 'react-bootstrap';


function SellersJson() {

const [data,setData]=useState([]);

const [name,setName]=useState([]);

// const [action,setaction]
  
useEffect(()=>{
  getData();
},[]);


  

const getData=()=>{
  axios("http://localhost:5000/seller_info").then((res)=> {
  //console.log(res.data);
  //setData(res.data);
  setData(res.data);
});
};



const handleDelete = (rowId, name) => {
  console.log(rowId, name);
  //1 YourCellName
};
const handleEdit = (rowId, name) => {
  console.log(rowId, name);
  //1 YourCellName
};

  return (
    <>
    {/* <div align="left" className={styles.container}> */}
        <h4>Sellers JSON</h4>
        <Container>
          <Row xs='auto'>
          
          
        <form className="form-inline mt-4 mb-4">
       
          <input style={{width:"250px"}} className="form-control form-control-sm"  type="text" placeholder="Search Sellers" aria-label="Search" onChange={(e)=>{
            setName(e.target.value)}} />
        
        
        <Col>
          <Button color="primary" size='sm' >Search</Button>{' '}
          </Col>
        </form>
        </Row>
        </Container>
        <Container>
          <Row xs='auto'>

          
            
            <Button variant='success' size='sm'>+Add New Seller</Button>{' '}
            <Col>
            <Button variant='success' size='sm'>Update Platform Info</Button>{' '}
            </Col>
            
            
          </Row>
        </Container>
        <br/>
          
    {/* </div> */}

     
   
      </>
  )
}

export default SellersJson