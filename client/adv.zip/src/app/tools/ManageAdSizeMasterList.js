import React, { useState } from 'react';
import { useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button,Modal  } from 'react-bootstrap';
import styles from '../styles.module.css';
import {BrowserRouter as Router, Route,Link, useHistory} from 'react-router-dom'
import Edit from './Edit'

const initialValue={  height: "",width: ""}
function ManageAdSizeMasterList() {

  const [data,setData]=useState([]);

  let history = useHistory();
  
  // const [action,setaction]
    
  useEffect(()=>{
    getData();
  },[]);
  

    
  
  const getData=()=>{
    axios("http://localhost:5000/adSizeMasterList").then((res)=> {
    //console.log(res.data);
    //setData(res.data);
    setData(res.data);
  });
  };
  
  


const deleteUser = async id => {
  await axios.delete(`http://localhost:5000/adSizeMasterList/${id}`);
  // getData();
  // setData();
  history.push("/tools/manageAdSizeMasterList");
};




const [user, setUser] = useState(initialValue);

const handleEdit = (EditData) => {
  console.log(EditData);
  setUser(EditData);
  // console.log("***************")
  //   console.log(setUser.id);
  //   console.log("+++++++++++++++")
  // localStorage.setItem('id',rowId)
  handleShow();
};

const { height, width, name } = user;
const onInputChange = e => {
  setUser({ ...user, [e.target.name]: e.target.value });
  console.log(e.target.value)
  
};

const onSubmit = async e => {
  // const ID = (setUser.id);
    
  if(user.id){
    console.log("***************")
    console.log(user.id);
    console.log("+++++++++++++++")
    e.preventDefault();
    //   await axios.put("http://localhost:5000/post", user);
       await axios.put(`http://localhost:5000/adSizeMasterList/${user.id}`, user);
      // history.push("/tools/manageAdSizeMasterList");
      getData();
      handleClose();
    
  }else{
    e.preventDefault();
    await axios.post("http://localhost:5000/adSizeMasterList", user);
    console.log("data submitted");
      getData();
      handleClose();
      setUser(initialValue);
  }
 
  
};



const [show, setShow] = useState(false);

const handleClose = () => setShow(false);
const handleShow = () => setShow(true);



  return (
    <>
    {/* <Edit /> */}
    <div align="left" className={styles.container}>
        <h4>Manage AdSize Master List</h4>
        <form className="form-inline mt-4 mb-4">
          <input style={{width:"250px"}} className="form-control form-control-sm"  type="text" placeholder="Search AdSize..." aria-label="Search" />
          <Button style={{marginLeft:"10px"}} color="primary" size='sm'>Search</Button>{' '}
        </form>

        <Button variant="primary" onClick={handleShow}> add Size List</Button>


          
    </div>
   
     
   
    
     <Edit show={show} handleClose={handleClose} data={user} onInputChange={onInputChange} onSubmit={onSubmit}/>
      </>
      
  )
}

export default ManageAdSizeMasterList
