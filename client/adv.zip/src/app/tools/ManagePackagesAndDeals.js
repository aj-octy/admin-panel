import React, { useState } from 'react';
import { useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Tabs,Tab } from 'react-bootstrap';
import ManagePackage from './PackageAndDeal/ManagePackage';
import ManageDeal from './PackageAndDeal/ManageDeal';


function ManagePackagesAndDeals() {

const [data,setData]=useState([]);


useEffect(()=>{
  getData();
},[]);
 

const getData=()=>{
  axios("http://localhost:5000/managepackagesanddeals").then((res)=> {
  //console.log(res.data);
  //setData(res.data);
  setData(res.data);
});
};

const [key, setKey] = useState('home');
useEffect(() => {
  const getActiveTab = JSON.parse(localStorage.getItem("activeTab"));
   if (getActiveTab) {
   setKey(getActiveTab);
   }
  }, []);
  
  useEffect(() => {
  localStorage.setItem("activeTab", JSON.stringify(key));
  }, [key]);

  return (
    <>
    
        <h4 style={{color:"#343a40"}}>Manage Packages And Deals</h4>
        <Tabs
          id="controlled-tab-example"
          activeKey={key}
          onSelect={(k) => setKey(k)}
          className="mb-3"
        >
          <Tab eventKey="home" title="Manage Packages">
            <ManagePackage />
            
          </Tab>
          <Tab eventKey="profile" title="Manage Deals">
            <ManageDeal />
            
          </Tab>
          
        </Tabs>


   
      </>
  )
}

export default ManagePackagesAndDeals
