import React, { useEffect, useRef, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles.module.css';
import { Form } from "react-bootstrap";
import axios from 'axios';
import DatePicker from "react-datepicker";
import AsyncSelect from "react-select/async";
import makeAnimated from "react-select/animated";
import '../../styles.module.css'
import { library } from "@fortawesome/fontawesome-svg-core";
import { faSave } from "@fortawesome/free-solid-svg-icons";
import {faChevronRight} from "@fortawesome/free-solid-svg-icons";
import {faChevronLeft} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {useParams, useHistory} from 'react-router-dom'
import {toast} from 'react-toastify';
import Crud from '../../common/Calls_methods';
import Select from "react-select";
import { data } from 'jquery';
import { Table } from "react-bootstrap";


library.add(faSave);
library.add(faChevronRight);
library.add(faChevronLeft);

function AddEditPackages() {
    let history = useHistory();
    const { id } = useParams();
    if(id == ""){ packages='' }


    // Populate Form
    const getPackagesData = () => {
        Crud.getData(`packages` , id).then((res) => {
            setPackages({...res.data});     
            FetchDeviceOs(res.data)
            FetchDeviceIdType(res.data)
            FetchMakeMultiselect(res.data)
            fetchCountryList(res.data.country)
            fetchStateList(res.data)
            fetchCitiesList(res.data)
            FetchContentCategory(res.data)
            fetchNetworkCarrier(res.data)
            fetchNetworkISP(res.data)
          if(res.data.channel_choice !=''){
            let getChannelItem = res.data.channel_choice;
            //if(getChannelItem ==''){ getChannelItem='00'; }
            console.log(res.data)
            console.log(getChannelItem.length)
            Crud.getData(`channels`,getChannelItem).then((channelRes)=>{
            setsearchbyid(channelRes.data);
            // setUserInfo(res.data)
            })
          }
            
        });
      }
      useEffect(() => {
        if(id && id>0){
            getPackagesData()
        }else if(id == ''){
      }
      }, []);
      

    //   Publisher channels
    
    const [channels, setChannels]=useState([]);
    
    useEffect(()=>{
      getChannelsData(search.name);
    },[]);

    const getChannelsData = (search) => {
      Crud.getTableData(`channels/search?${search}`).then((res)=>{
          setChannels(res.data);
        })
    }

    //   Publisher channels
      
      useEffect( () => {
        loadDeviceOs()
        loadDeviceMake()
        loadDeviceIdType()
        loadCountryList()
        loadStatesList()
        // loadCitiesList()
        loadContentCategory()
        loadNetworkCarrier()
        loadNetworkISP()
      },[])
      
      
    // Populate Form

    
    const initialValue={  
        name: "",
        opratingSystem: [],
        deviceOs: [],
        deviceID:[],
        deviceMake:[],
        category:[],
        network_carrier:[],
        network_ISP:[],
        deviceModel: "",
        adsize:[],
        gps:"no",
        ifa:"no",
        adsizedesk:[],
        adunitdesk:[],
        deviceOSVersion: "",
        inventoryFilter: "",
        inventoryFilterGPS: "",
        adSkippable: "no",
        adDuration: "any",
        app_mobile_target:"any",
        site_domain_bundle_target:"",
        site_domain_bundle_target_include_exclude: "include",
        content_categories_include_exclude: "include",
        deviceOSinclude: "yes",
        adult_content: "no_adult_content",
        wifiTargeting:"any",
        country:"",
        state:"",
        cities:"",
        viewability_score:0.000,
        vtr:0.000,
        ctr:0.000,
        ads_default_domains:"chocolateplatform.com",
        ads_default_domains_select:[],
        account_type:[],
        supply_chain_applicability:"yes",
        adsTxt:[],
        seller_enabled:[],
        channel_choice: "",
    }
    const [packages, setPackages] = useState(initialValue);
    const { name, 
            definition, 
            opratingSystem,
            deviceOs, 
            deviceID,
            deviceMake,
            category,
            network_carrier,
            network_ISP,
            adsize,
            gps,
            ifa,
            adunitdesk,
            adsizedesk,
            deviceModel, 
            deviceOSVersion, 
            inventoryFilter,
            inventoryFilterGPS, 
            adSkippable, 
            adDuration, 
            adult_content,
            app_mobile_target,
            site_domain_bundle_target,
            site_domain_bundle_target_include_exclude,
            content_categories_include_exclude,
            deviceOSinclude,
            wifiTargeting,
            country,
            state,
            cities,
            viewability_score,
            vtr,
            ctr,
            ads_default_domains,
            ads_default_domains_select,
            account_type,
            supply_chain_applicability,
            adsTxt,
            seller_enabled,
            channel_choice } = packages;

            const [createBidder,setBidder]=useState(initialValue);

    // device os 
    let [OSdeviceOs, setOSDeviceOs] = useState([ ])
    let [queryDeviceOs, setQueryDeviceOs] = useState('')
    let [defaultDataForDeviceOs, setdefaultDataForDeviceOs] = useState([ ])


       const loadDeviceOs = () => {
        Crud.fetchDatas(`packages/operating_system?${queryDeviceOs}`
        ).then((res) => res.json()
        .then(data => {
          let newData = data.map( ol => {
            return {label:ol.os_name , value: ol.os_name}
          })
          setOSDeviceOs(newData)
        }));
      };
      

      const mymultiselect =(e) => {
         setdefaultDataForDeviceOs(e);
         console.log(defaultDataForDeviceOs)
         setPackages(item1=>({...item1,deviceOs: [e]}));
       }

       const FetchDeviceOs = (data) =>{
        console.log(data.deviceOs)
           if(data.deviceOs.length > 0) {
                const t =data.deviceOs[0];
                console.log(t)
                t.forEach(element => {
                        setdefaultDataForDeviceOs(o=>([...o,{label: element.label, value: element.value}]));  
                })
            }
       }
    // device os 

    //Content Categories
    let [contentCategory, setContentCategory] = useState([ ])
    let [queryContentCategory, setQueryContentCategory] = useState('')
    let [defaultDataForContentCategory, setdefaultDataForContentCategory] = useState([ ])

    const loadContentCategory = () =>{
        Crud.fetchDatas(`packages/category_search?${queryContentCategory}`
        ).then((res) => res.json()
        .then(data => {
          let newData = data.map( ol => {
            return {label:ol.category_name , value: ol.category_code}
          })
          setContentCategory(newData)
        }));
    }
    const contentCategoryMultiselect =(e)=>{
        setdefaultDataForContentCategory(e);
         console.log(defaultDataForContentCategory)
         setPackages(item1=>({...item1,category: [e]}));
    }

    const FetchContentCategory = (data) =>{
        console.log(data.category)
           if(data.category.length > 0) {
                const t =data.category[0];
                console.log(t)
                t.forEach(element => {
                    setdefaultDataForContentCategory(o=>([...o,{label: element.label, value: element.value}]));  
                })
            }
       }
    //Content Categories

    // Carrier Whitelist
    let [networkCarrier, setNetworkCarrier] = useState([ ])
    let [queryNetworkCarrier, setQueryNetworkCarrier] = useState('')
    let [defaultDataForNetworkCarrier, setdefaultDataForNetworkCarrier] = useState([ ])

    const loadNetworkCarrier =()=>{
        Crud.fetchDatas(`packages/networkCarrier?${queryNetworkCarrier}`
        ).then((res) => res.json()
        .then(data => {
          let newData = data.map( ol => {
            return {label:ol.carrier , value: ol.ccode}
          })
          setNetworkCarrier(newData)
        }));  
    }

    const networkCarrierMultiselect =(e)=>{
        setdefaultDataForNetworkCarrier(e);
        console.log(defaultDataForNetworkCarrier)
        setPackages(item1=>({...item1,network_carrier: [e]}));
    }

    const fetchNetworkCarrier =(data) =>{
        console.log(data.network_carrier)
           if(data.network_carrier.length > 0) {
                const t =data.network_carrier[0];
                console.log(t)
                t.forEach(element => {
                    setdefaultDataForNetworkCarrier(o=>([...o,{label: element.label, value: element.value}]));  
                })
            }
    }
    // Carrier Whitelist

    // ISP Whitelist
    let [networkISP, setNetworkISP] = useState([ ])
    let [queryNetworkISP, setQueryNetworkISP] = useState('')
    let [defaultDataForNetworkISP, setdefaultDataForNetworkISP] = useState([ ])

    const loadNetworkISP =()=>{
        Crud.fetchDatas(`packages/networkISP?${queryNetworkISP}`
        ).then((res) => res.json()
        .then(data => {
          let newData = data.map( ol => {
            return {label:ol.isp_name , value: ol.ccode}
          })
          setNetworkISP(newData)
        }));  
    }

    const networkISPMultiselect =(e)=>{
        setdefaultDataForNetworkISP(e);
        console.log(defaultDataForNetworkISP)
        setPackages(item1=>({...item1,network_ISP: [e]}));
    }

    const fetchNetworkISP =(data) =>{
        console.log(data.network_ISP)
           if(data.network_ISP.length > 0) {
                const t =data.network_ISP[0];
                console.log(t)
                t.forEach(element => {
                    setdefaultDataForNetworkISP(o=>([...o,{label: element.label, value: element.value}]));  
                })
            }
    }

    // ISP Whitelist

    // device id type 
    let [deviceIdType, setDeviceIdType] = useState([ ])
    let [queryDeviceIdType, setQueryDeviceIdType] = useState([ ])
    let [defaultDataForDeviceIdType, setdefaultDataForDeviceIdType] = useState([ ])

    const deviceIdTypeMultiselect =(e) =>{
        setdefaultDataForDeviceIdType(e)
        setPackages(item1=>({...item1,deviceID: [e]}));
        
    }

    const loadDeviceIdType = () => {
        Crud.fetchDatas(`packages/device_type?${queryDeviceIdType}`
        ).then((res) => res.json()
        .then(data => {
          let newData = data.map( ol => {
            return {label:ol.model , value: ol.model}
          })
          setDeviceIdType(newData)
        }));
      }

    const FetchDeviceIdType = (data) =>{
        if(data.deviceID.length > 0) {
            const t =data.deviceID[0];
            console.log(t)
            t.forEach(element => {
                setdefaultDataForDeviceIdType(o=>([...o,{label: element.label, value: element.value}]));  
            })
        }
    }
    // device id type 

    // device make 
    let [deviceMakeSelect, setDeviceMakeSelect] = useState();
    let [queryDeviceMakeSelect, setQueryDeviceMakeSelect] = useState([ ])
    let [defaultDataForDeviceMakeSelect, setdefaultDataForDeviceMakeSelect] = useState([ ])

    const loadDeviceMake = () => {
        Crud.fetchDatas(`packages/device_model?${queryDeviceMakeSelect}`
        ).then((res) => res.json()
        .then(data => {
          let newData = data.map( ol => {
            return {label:ol.os_name , value: ol.os_name}
          })
          setDeviceMakeSelect(newData)
        }));
      };

    const deviceMakeMultiselect = (e) =>{
        setdefaultDataForDeviceMakeSelect(e);
        console.log(defaultDataForDeviceMakeSelect)
        setPackages(item1=>({...item1,deviceMake: [e]}));
    }

    const FetchMakeMultiselect = (data) =>{
        if(data.deviceMake.length > 0) {
             const t =data.deviceMake[0];
             console.log(t)
             t.forEach(element => {
                setdefaultDataForDeviceMakeSelect(o=>([...o,{label: element.label, value: element.value}]));  
             })
         }
    }
    // device make 

    const onInputChangeCheck = e => {
        console.log(e.target.name)
        console.log(e.target.value)
        const { value, checked } = e.target;
        if(checked){
            setPackages(item1=>({
                ...item1,[e.target.name]: [...item1[e.target.name], e.target.value]
            }));
        }else{
            setPackages(item1=>({
                ...item1,opratingSystem: opratingSystem.filter((e) => e !== value)
            }));
        }
    }

    const onInputChangeAdsize =e=>{
        const { value, checked } = e.target;
        if(checked){
            setPackages(item1=>({
                ...item1,[e.target.name]: [...item1[e.target.name], e.target.value]
            }));
        }else{
            setPackages(item1=>({
                ...item1,adsize: adsize.filter((e) => e !== value)
            }));
        }
    }


    const onInputChangeAdsTxtDomain = e =>{
        const { value, checked } = e.target;
        if(checked){
            setPackages(item1=>({
                ...item1,[e.target.name]: [...item1[e.target.name], e.target.value]
            }));
            
        }else{
            setPackages(item1=>({
                ...item1,ads_default_domains_select: ads_default_domains_select.filter((e) => e !== value)
            }));
        }
    }

    const onInputChangeAdsTxt = e =>{
        const { value, checked } = e.target;
        if(checked){
            setPackages(item1=>({
                ...item1,[e.target.name]: [...item1[e.target.name], e.target.value]
            }));
            onInputChangeSellerEnabled(e)
        }else{
            setPackages(item1=>({
                ...item1,adsTxt: adsTxt.filter((e) => e !== value)
            }));
            onInputChangeSellerEnabled(e)
        }
    }

    const onInputChangeSellerEnabled =(e)=>{
        const { value, checked } = e.target;
        console.log(e.target.value)
        console.log(e.target.name)
        if(checked){
            setPackages(item1=>({
                ...item1,seller_enabled: ["135711"]
            }));
        }else{
            setPackages(item1=>({
                ...item1,seller_enabled: seller_enabled.pop((e) => e !== value)
            }));
        }
    }

    const onInputChangeAccTypeCheck = e =>{
        const { value, checked } = e.target;
        if(checked){
            setPackages(item1=>({
                ...item1,[e.target.name]: [...item1[e.target.name], e.target.value]
            }));
        }else{
            setPackages(item1=>({
                ...item1,account_type: account_type.filter((e) => e !== value)
            }));
        }
    }

    

    //Publishers Channels
  const handleTableRowSelect=e=>{
    console.log("table data!!!");
  }
  const [userinfo, setUserInfo]=useState({
    channelsleftarray: [],
    channelsrightarray: [],
  });

  console.log(userinfo.channelsrightarray)
  
  const [finaloutput, setFinalOutput]=useState({
    res: []
  });
  
  //For searching
  const initialvalueforsearch = {name:""}
  const [search,setSearch]=useState(initialvalueforsearch)
  const onInputSearchChange=e=>{
    setSearch(item1=>({name: e.target.value}));
  }
  const onSearchSubmit = e => {
    e.preventDefault();
    let t = search.name
    getChannelsData(t);
  }
  const [searchbyid,setsearchbyid]=useState([]);
  console.log(searchbyid)

  let getSelectedKeys=[];
 const leftCheckboxContainer=(e)=>{ 
  
    const val=e.target.value
    const checked=e.target.checked;
    

    // if(id != undefined){
      const {channelsrightarray}=userinfo;
      let keys=[]
      console.log("ui========================",searchbyid)
      if(searchbyid != undefined){
        for (let key in searchbyid){
        keys.push(searchbyid[key].id)
        }
      }
      console.log(keys);

      
      if(checked == true){
            getSelectedKeys.push(val)
          }
      console.log(getSelectedKeys)
      if(checked == false){
        getSelectedKeys.pop(val)
      }
      console.log(getSelectedKeys)
      
    // }

}



function uncheckElements()
{
 var uncheck=document.querySelectorAll('.checkboxRight');
 for(var i=0;i<uncheck.length;i++)
 {
  
   uncheck[i].checked=false;
  
 }
}

  const LeftClickHandle=e=>{
    uncheckElements()
    console.log(searchbyid)
  let keys =[]
      if(searchbyid != undefined){
        for (let key in searchbyid){
          keys.push(searchbyid[key].id)
          }
      }
      
    let alteredKeys = keys.join().split(',')
    console.log(alteredKeys)
    console.log(getSelectedKeys)
    var filteredKeysFromRightArr = alteredKeys.filter(x => getSelectedKeys.indexOf(x) === -1);
    console.log(filteredKeysFromRightArr)

    Crud.getTableData(`channels/${filteredKeysFromRightArr}`).then((res)=>{
      const resdata=res.data;
      console.log(resdata)
      console.log(channels)
      if(resdata.length == channels.length){
        console.log(filteredKeysFromRightArr)
        setPackages((item) => ({
          ...item,
          channel_choice:filteredKeysFromRightArr
        }));
        setsearchbyid([]);

      }else{
        setsearchbyid(res.data);
        setPackages((item) => ({
          ...item,
          channel_choice:filteredKeysFromRightArr
        }));
      }
    })
    

  }
  

  const RightClickHandle=e=>{

    const {channelsleftarray}=userinfo;
    const searchid=userinfo.channelsleftarray;

    if(id && id >0){

      let keys =[]
      if(searchbyid != undefined && searchbyid !=''){
        for (let key in searchbyid){
          keys.push(searchbyid[key].id)
          }
      }
      console.log(keys)
      

      let t = searchid.concat(keys.join().split(','))
      console.log(t)
      
      let unique = t.filter((item, i, ar) => ar.indexOf(item) === i);
      console.log(unique);
      
      Crud.getTableData(`channels/${t}`).then((chRes)=>{
        setsearchbyid(chRes.data);
        console.log(chRes)
      setPackages((item) => ({
          ...item,
          channel_choice:t
        }));
        
      })

    }else{
      setUserInfo(({...userinfo,channelsrightarray: channelsleftarray}));
      Crud.getTableData(`channels/${searchid}`).then((res)=>{
      setsearchbyid(res.data);
      setPackages((item) => ({
        ...item,channel_choice: userinfo.channelsleftarray}));
    })
    console.log(channel_choice)
    console.log(userinfo)
    }
    
    
  }
  const onInputChannelChoiceChange=e=>{
    console.log("its just a text area nothing else!!!")
  }
  const rightCheckboxContainer=e=>{
    //Destructuring
    const {value, checked}=e.target;
    const {channelsleftarray}=userinfo;
    console.log(`${value} is ${checked}`)
    // console.log(e.target.id)
    //In case the user checks the box
    if(checked){
      setUserInfo(item1=>({
        ...item1,[e.target.id]: [...item1[e.target.id], e.target.value]
    }));
      console.log(userinfo.channelsleftarray);
    }
    else{
      setUserInfo(({...userinfo,channelsleftarray: channelsleftarray.filter((e) => e !== value)}));
      console.log(value+"unselected");
    }
  }
  const handleSelectAll=e=>{
    const checked=e.target.checked;
    const val=e.target.value;
    const element = document.querySelectorAll('.check12');
    console.log(element);
    const {channelsleftarray}=userinfo;
    for(var i=0; i< element.length; i++){
      const value=element[i].value;
      if(checked){
        element[i].checked=true;
        setUserInfo(item1=>({
          ...item1,[e.target.id]: [...item1[e.target.id], value]
        }));
      }else{
        setUserInfo(({...userinfo,channelsleftarray: channelsleftarray.filter((e) => e === val)}));
        console.log(userinfo.channelsleftarray)
        element[i].checked=false;
      }
    }
  }
  const handleRightSelectAll=e=>{
    const checked=e.target.checked;
    console.log(checked);
    const val=e.target.value;
    const element = document.querySelectorAll('.check11');
    for(var i=0; i < element.length; i++){
      if(checked){
        element[i].checked=true;
        const {channelsrightarray}=userinfo;
        setUserInfo(({...userinfo,channelsrightarray: channelsrightarray.filter((e) => e == val)}));
      }else{
        console.log("do nothing!");
        element[i].checked=false;
        setUserInfo(item1=>({
          ...item1,[e.target.id]: [...item1[e.target.id], val]
        }));
        console.log(userinfo.channelsrightarray);
      }
    }
  }
  //Publishers Channels

    const onInputChange = e => {
        console.log(e.target.name)
        console.log(e.target.value)
        console.log(defaultCountryData.length)
        setPackages(item1=>({...item1,[e.target.name]: e.target.value }));
    }


    const testRef = useRef()
    

    // Country List 
    var [countryData, setCountryData] = useState([]);
    var [queryCountryData, setQueryCountryData] = useState([]);
    var [defaultCountryData, setdefaultCountryData] = useState([]);

    const loadCountryList = () => {
        Crud.fetchDatas(`packages/country?${queryCountryData}`).then(
          (res) =>{
            // if(res.status == 200) console.log(res.status)
            res.json().then(async (data) => {
              let mydata = await data.map((it) => {
                return { label: it.country_name, value: it.alpha_3_code };
              });
              setCountryData(mydata);
            })
          }
        );
      }
      
      const onInputChangeCountry = (e) => {
        setPackages((item) => ({
          ...item,
          country: e?.value,
        }))
        setdefaultCountryData([{ label: e.label, value: e.value }]);
        testRef.current = "ture"
        console.log(testRef.current)
      }


      
      let optional = [];
        const fetchCountryList = (country) => {
            console.log(country)
            Crud.fetchData(`packages/country/` + country).then((res) =>{
            res.json()
            .then((el) => {
                optional.push({ label: el[0].country_name, value: el[0].alpha_3_code });
                setdefaultCountryData([{ label: el[0].country_name, value: el[0].alpha_3_code }]);
            }).catch( er =>{
                console.error(er)
            })
            }
            
            )
        };

    // country List 
    var cname = packages.country
    console.log(cname)
   
    // States List 
    var [stateData, setStateData] = useState([]);
    var [queryStatesData, setQueryStatesData] = useState([]);
    var [defaultStateData, setdefaultStateData] = useState([]);
    

    let loadStatesList = () => {
      console.log("loadStates")
      console.log(packages.country)
      console.log(cname)
      
        Crud.fetchDatas(`packages/stateByCountry?${cname}`).then(
          (res) =>
            res.json().then(async (data) => {
                
              let mydata = await data.map((it) => {
                return { label: it.state_name, value: it.ccode_alpha_3 };
              });
              setStateData(mydata);
            })
        ); 
         
      }

     

      
        // if(testRef.current != undefined ){
        //   loadStatesList()
        //   // test()
        //   console.log("cname is not empty")
        // }else{
        //   console.log("cname is empty")
        // }
      
      


      const stateMultiselect = (e) => {
        console.log(testRef.current)
          console.log(e)
        setPackages((item) => ({
          ...item,
          state: [e],
        }));
        setdefaultStateData(e);
      }

      const fetchStateList = (data) =>{
        if(data.state.length > 0) {
            console.log(data)
            const t =data.state[0]
            console.log(t)
            t.forEach(element => {
                setdefaultStateData(o=>([...o,{label: element.label, value: element.value}]));  
            })
        }
    }

        //     console.log(data.deviceOs)
        //     if(data.deviceOs.length > 0) {
        //         const t =data.deviceOs[0];
        //         console.log(t)
        //         t.forEach(element => {
        //                 setdefaultDataForDeviceOs(o=>([...o,{label: element.label, value: element.value}]));  
        //         })
        //     }
        // }

    // States List 

    // Cities List
    var [citiesData, setCitiesData] = useState([]);
    var [queryCitiesData, setQueryCitiesData] = useState([]);
    var [defaultCitiesData, setdefaultCitiesData] = useState([]);

    const loadCitiesList = () => {
        Crud.fetchDatas(`packages/city_mapping?${queryCitiesData}`).then(
          (res) =>
            res.json().then(async (data) => {
              let mydata = await data.map((it) => {
                return { label: it.city_name, value: it.city_name };
              });
              setCitiesData(mydata);
            })
        );
      }

      const onInputChangeCities = (e) => {
        console.log("**************8")
        setPackages((item) => ({
          ...item,
          cities:[e] 
        }));
        setdefaultCitiesData(e);
      }

    //   let optionalCities = [];
        const fetchCitiesList = (data) => {

            if(data.cities.length > 0) {
                console.log(data)
                const t =data.cities[0]
                console.log(t)
                t.forEach(element => {
                    setdefaultCitiesData(o=>([...o,{label: element.label, value: element.value}]));  
                })
            }

        };
    // Cities List

    const onSubmit = e => {
        
        e.preventDefault();
        console.info(defaultDataForDeviceOs)
        console.log(deviceIdType)
        console.log(packages)
        
    if(id && id >0 ){
        Crud.update(`packages`,id, packages)
        .then(()=>{console.log(packages) 
         toast.success("Package Updated !",{
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            })
            history.push("/tools/ManagePackagesAndDeals");
        }) 
        }else{
        Crud.create(`packages`, packages)
        .then(()=>{console.log("data inserted" + packages) 
         toast.success("Package Added !",{
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            })
            history.push("/tools/ManagePackagesAndDeals");
        })
    }
        
        
    }


    const [collapsePackage, setCollapsePackage] = useState(true);
    const [collapseDevice, setCollapseDevice] = useState(true);
    const [collapseVideoInventory, setCollapseVideoInventory] = useState(true ? id!=undefined : false);
    const [collapsePubChannel, setCollapsePubChannel] = useState(true ? id!=undefined : false);
    const [collapseContentCategory, setCollapseContentCategory] = useState(true ? id!=undefined : false);
    const [collapseUrlTargetting, setCollapseUrlTargetting] = useState(true ? id!=undefined : false);
    const [collapseCarrierNetwork, setCollapseCarrierNetwork] = useState(true ? id!=undefined : false);
    const [collapseLocation, setCollapseLocation] = useState(true ? id!=undefined : false);
    const [collapsePerformanceMatrix, setCollapsePerformanceMatrix] = useState(true ? id!=undefined : false);
    const [collapseAdsTxtSeller, setCollapseAdsTxtSeller] = useState(true ? id!=undefined : false);
    

    const handleClick = () => {setCollapsePackage(!collapsePackage)};
    const handleCollapseDevice = () => {setCollapseDevice(!collapseDevice);}
    const handleCollapseVideoInventory = () => {setCollapseVideoInventory(!collapseVideoInventory)}
    const handleCollapsePubChannel = () => {setCollapsePubChannel(!collapsePubChannel)}
    const handleCollapseContentCategory = () => {setCollapseContentCategory(!collapseContentCategory)}
    const handleCollapseUrlTargetting = () => {setCollapseUrlTargetting(!collapseUrlTargetting)}
    const handleCollapseCarrierNetwork = () => {setCollapseCarrierNetwork(!collapseCarrierNetwork)}
    const handleCollapseLocation = () => {setCollapseLocation(!collapseLocation)}
    const handleCollapsePerformanceMatrix = () => {setCollapsePerformanceMatrix(!collapsePerformanceMatrix)}
    const handleCollapseAdsTxtSeller = () => {setCollapseAdsTxtSeller(!collapseAdsTxtSeller)}
    
  return (
    <>
    <div align="left" className={styles.container}>
        <h4>Create New Package</h4>
    </div>
    <div className="container-fluid">
        <div className="row">
            <div className="col-md-12">
                <Form onSubmit={e => onSubmit(e)}>
                    <div>
                        <fieldset>
                            <legend>
                              <span onClick={handleClick}  style={{fontSize:"18px"}} className={ collapsePackage ? "mdi mdi-minus-box" : "mdi mdi-plus-box"}></span> 
                              <span> Package Setting</span>
                            </legend>
                            {collapsePackage ?
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right"> Package Name</label>
                                <div className="col-sm-8">
                                    <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        name="name"
                                        value={packages.name || ""}
                                        onChange={e => onInputChange(e)}
                                    />
                                </div>
                            </Form.Group>
                            :
                            <></>
                          }
                        </fieldset>
                    </div>
                    {/* Device */}
                        <div>
                            <fieldset>
                                <legend>
                                <span onClick={handleCollapseDevice}  style={{fontSize:"18px"}} className={ collapseDevice ? "mdi mdi-minus-box" : "mdi mdi-plus-box"}></span> 
                                  <span> Device</span>
                                  </legend>
                                {collapseDevice ?
                                <>
                                <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label text-right"> Operating System</label>
                                    <div className="col">
                                        <div className='row'>
                                            <div className="col-sm-9">
                                            <Select
                                                isMulti
                                                options={OSdeviceOs}
                                                onChange={(e) => mymultiselect(e)}
                                                isLoading={false}
                                                value={defaultDataForDeviceOs}
                                                isClearable={false} 
                                                isSearchable={true}
                                                isRtl={false}
                                            />
                                            </div>
                                        </div>
                                        <div className='row'>
                                            <div className="col-sm-1 text-left">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input
                                                        type="radio"
                                                        className="form-check-input"
                                                        name="deviceOSinclude"
                                                        value="yes"
                                                        checked={packages.deviceOSinclude == "yes"}
                                                        onChange={e => onInputChange(e)}
                                                    />
                                                    Include
                                                    <i className="input-helper"></i>
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="col-sm-1">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input
                                                        type="radio"
                                                        className="form-check-input"
                                                        name="deviceOSinclude"
                                                        value="no"
                                                        checked={packages.deviceOSinclude == "no"}
                                                        onChange={e => onInputChange(e)}
                                                    />
                                                    Exclude
                                                    <i className="input-helper"></i>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Form.Group>
                                
                                <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label text-right"> Device Id Types</label>
                                    <div className="col-sm-8">
                                    <Select
                                        isMulti
                                        options={deviceIdType}
                                        onChange={(e) => deviceIdTypeMultiselect(e)}
                                        isLoading={false}
                                        value={defaultDataForDeviceIdType }
                                        isClearable={false} 
                                        isSearchable={true}
                                        isRtl={false}
                                    />
                                    </div>
                                </Form.Group>
                                
                                <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label mt-1 text-right">Device Type</label>
                                    <div className="col-sm-1">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input 
                                                type="checkbox" 
                                                className="form-check-input" 
                                                onChange={e => onInputChangeCheck(e)}
                                                name="opratingSystem"
                                                value="desktop"
                                                checked={Array.isArray(packages.opratingSystem ) && packages.opratingSystem?.find(item => item == "desktop") ? true : ""}
                                            />
                                            <i className="input-helper"></i>Desktop</label>
                                        </div>
                                    </div>
                                    <div className="col-sm-1">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input 
                                                type="checkbox"
                                                className="form-check-input" 
                                                onChange={e => onInputChangeCheck(e)}
                                                name="opratingSystem"
                                                value="mobile"
                                                checked={Array.isArray(packages.opratingSystem ) && packages.opratingSystem?.find(item => item == "mobile") ? true : ""}
                                            />
                                            <i className="input-helper"></i>Mobile</label>
                                        </div>
                                    </div>
                                    <div className="col-sm-1">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input 
                                                type="checkbox" 
                                                className="form-check-input" 
                                                onChange={e => onInputChangeCheck(e)}
                                                name="opratingSystem"
                                                value={ "tablet" }
                                                // {packages.opratingSystem != "" ? packages.opratingSystem?.find(item => item == "tablet") ? true : "" :}
                                                checked={Array.isArray(packages.opratingSystem ) && packages.opratingSystem?.find(item => item == "tablet") ? true : ""}
                                            />
                                            <i className="input-helper"></i>Tablet</label>
                                        </div>
                                    </div>
                                    <div className="col-sm-2">
                                        <div className="form-check">
                                            <label className="form-check-label">
                                            <input 
                                                type="checkbox" 
                                                className="form-check-input" 
                                                onChange={e => onInputChangeCheck(e)}
                                                name="opratingSystem"
                                                value={"connectedTV" }
                                                // checked={packages.opratingSystem["connectedTV"] == "connectedTV"? true:false }
                                                checked={Array.isArray(packages.opratingSystem) && packages.opratingSystem?.find(item => item == "connectedTV") ? true : ""}
                                                // checked={id !== "" ? packages.opratingSystem.filter(element => element == 'connectedTV')  ? true : "" : "" }
                                            />
                                            <i className="input-helper"></i>Connected TV</label>
                                        </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label text-right"> Device Make</label>
                                    <div className="col-sm-8">
                                        <Select
                                            isMulti
                                            options={OSdeviceOs}
                                            // classNamePrefix="select"
                                            onChange={(e) => deviceMakeMultiselect(e)}
                                            isLoading={false}
                                            value={defaultDataForDeviceMakeSelect}
                                            isClearable={false} 
                                            isSearchable={true}
                                            isRtl={false}
                                        />
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label text-right"> Device Model</label>
                                    <div className="col-sm-8">
                                        <Form.Control
                                            className="form-control customTextarea"
                                            type="text"
                                            name="deviceModel"
                                            as="textarea"
                                            row={3}
                                            value={packages.deviceModel || ""}
                                            onChange={e => onInputChange(e)}
                                        />
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label text-right"> Device OS Version</label>
                                    <div className="col-sm-8">
                                        <Form.Control
                                            className="form-control customTextarea"
                                            type="text"
                                            name="deviceOSVersion"
                                            as="textarea"
                                            row={3}
                                            value={packages.deviceOSVersion || ""}
                                            onChange={e => onInputChange(e)}
                                        />
                                    </div>
                                </Form.Group>
                                </>:
                                <></>
                              }
                            </fieldset>
                        </div>
                    {/* Device */}
                    {/* Video Inventory Type  */}
                    <div>
                        <fieldset>
                             <legend>
                             <span onClick={handleCollapseVideoInventory}  style={{fontSize:"18px"}} className={ collapseVideoInventory ? "mdi mdi-minus-box" : "mdi mdi-plus-box"}></span> 
                               <span>Video Inventory Type</span> 
                              </legend>
                              {collapseVideoInventory ? <>
                                <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right">Ad Size(Mobile/Tablet)</label>
                                <div className="col text-left">
                                  <div className="form-check">
                                    <label className="form-check-label">
                                      <input type="checkbox" className="form-check-input" 
                                        onChange={e => onInputChangeAdsize(e)}
                                        name="adsize"
                                        value="300_250"
                                        checked={Array.isArray(packages.adsize ) && packages.adsize?.find(item => item == "300_250") ? true : ""}
                                      />
                                      <i className="input-helper"></i>300 * 250
                                    </label>
                                  </div>
                                  <div className="form-check">
                                    <label className="form-check-label">
                                      <input type="checkbox" className="form-check-input" 
                                        onChange={e => onInputChangeAdsize(e)}
                                        name="adsize"
                                        value="320_480"
                                        checked={Array.isArray(packages.adsize ) && packages.adsize?.find(item => item == "320_480") ? true : ""}
                                      />
                                      <i className="input-helper"></i>320 * 480
                                    </label>
                                  </div>
                                  <div className="form-check">
                                    <label className="form-check-label">
                                      <input type="checkbox" className="form-check-input" 
                                        onChange={e => onInputChangeAdsize(e)}
                                        name="adsize"
                                        value="492_517"
                                        checked={Array.isArray(packages.adsize ) && packages.adsize?.find(item => item == "492_517") ? true : ""}
                                      />
                                      <i className="input-helper"></i>492 * 517
                                    </label>
                                  </div>
                                  <div className="form-check">
                                    <label className="form-check-label">
                                      <input type="checkbox" className="form-check-input" 
                                        onChange={e => onInputChangeAdsize(e)}
                                        name="adsize"
                                        value="others"
                                        checked={Array.isArray(packages.adsize ) && packages.adsize?.find(item => item == "others") ? true : ""}
                                      />
                                      <i className="input-helper"></i>Others
                                    </label>
                                  </div>
                                </div>

                              </Form.Group>
                            
                            
                            
                                <Form.Group className="row">
                                
                                <label className="col-sm-2 col-form-label mt-1 text-right">Has GPS-based Lat/Long</label>
                                
                                        <div className="col-sm-1 text-left">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input
                                                    type="radio"
                                                    className="form-check-input"
                                                    name="gps"
                                                    value="yes"
                                                    checked={packages.gps == "yes"}
                                                    onChange={e => onInputChange(e)}
                                                />
                                                Yes<i className="input-helper"></i>
                                                </label>
                                            </div>
                                        </div>
                                        <div className="col-sm-1">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input
                                                    type="radio"
                                                    className="form-check-input"
                                                    name="gps"
                                                    value="no"
                                                    checked={packages.gps == "no"}
                                                    onChange={e => onInputChange(e)}
                                                />
                                                No
                                                <i className="input-helper"></i>
                                                </label>
                                            </div>
                                        </div>
                                        
                            </Form.Group>
                            
                            
                                <Form.Group className="row">
                                
                                <label className="col-sm-2 col-form-label mt-1 text-right">Has IFA - Yes/No</label>
                                        <div className="col-sm-1 text-left">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input
                                                    type="radio"
                                                    className="form-check-input"
                                                    name="ifa"
                                                    value="yes"
                                                    checked={packages.ifa == "yes"}
                                                    onChange={e => onInputChange(e)}
                                                />
                                                Yes<i className="input-helper"></i>
                                                </label>
                                            </div>
                                        </div>
                                        <div className="col-sm-1">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input
                                                    type="radio"
                                                    className="form-check-input"
                                                    name="ifa"
                                                    value="no"
                                                    checked={packages.ifa == "no"}
                                                    onChange={e => onInputChange(e)}
                                                />
                                                No
                                                <i className="input-helper"></i>
                                                </label>
                                            </div>
                                        </div>
                                        
                            </Form.Group>
                            

                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right">Ad Skippable</label>
                                <div className="col">
                                    <select className="form-control customDropDown" name="adSkippable" onChange={e => onInputChange(e)} style={{width:"160px"}}>
                                        <option selected={packages.adSkippable == "no"}  value="no">No</option>
                                        <option selected={packages.adSkippable == "yes"}  value="yes">Yes</option>
                                    </select>
                                    <div className="controls min-controls" style={{color: "#49afcd" ,fontSize: "13px"}}>
                                        <b>Note: </b>This Ad Skippable metrics will be applicable for matching with Ad-Request only
                                    </div>
                                </div>
                            </Form.Group>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right">Ad Duration</label>
                                <div className="col">
                                    <select className="form-control customDropDown" name="adDuration" onChange={e => onInputChange(e)} style={{width:"160px"}}>
                                        <option value="any" selected={packages.adDuration == "any"}>Any</option>
                                        <option value="15" selected={packages.adDuration == "15"}>15 Seconds &amp; Above</option>
                                        <option value="30" selected={packages.adDuration == "30"}>30 Seconds &amp; Above</option>
                                        <option value="60" selected={packages.adDuration == "60"}>60 Seconds &amp; Above</option>
                                        <option value="90" selected={packages.adDuration == "90"}>90 Seconds &amp; Above</option>
                                    </select>
                                    <div className="controls min-controls" style={{color: "#49afcd" ,fontSize: "13px"}}>
                                        <b>Note: </b>This Ad Duration metrics will be applicable for video inventory only 
                                    </div>
                                </div>
                            </Form.Group>
                            </> : <></>}
                        </fieldset>

                    <div>
                    <fieldset>
                        <legend>
                        <span onClick={handleCollapsePubChannel}  style={{fontSize:"18px"}} className={ collapsePubChannel ? "mdi mdi-minus-box" : "mdi mdi-plus-box"}></span> 
                          Publisher Channels
                        </legend>
                        {collapsePubChannel ? <>
                        <Form className="row">
                                  <div className="col-sm-3">
                                    <Form.Control
                                      className="form-control customInput"
                                      type="text"
                                      name="name"
                                      // value={""}
                                      placeholder="Search Publisher Channels..."
                                      onChange={(e) => onInputSearchChange(e)}
                                    />
                                  </div>
                                  <div className="col-sm-3">
                                  <button
                                    type="button"
                                    className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                    onClick={(e)=>onSearchSubmit(e)}
                                    >Search 
                                    {/* <FontAwesomeIcon icon="search" /> */}
                                  </button>
                                  </div>
                        </Form>
                        <br/>
                        <Form.Group className="row">
                        <div className="col-sm-5">
                     <div className="container-box2">
                       <div className="item-list block">
                        <Table 
                        sx={{ minWidth: 100 }}
                        >
                                  <tr>
                                    <th style={{background:"#f7f7f7"}}>
                                      <input 
                                      type="checkbox"
                                      id="channelsleftarray"
                                      name="channelsleftarray"
                                      value={channels}
                                      onChange={(e)=>handleSelectAll(e)}>
                                      </input>
                                    </th>
                                    <th style={{background:"#f7f7f7"}}>ID</th>
                                    <th style={{background:"#f7f7f7"}}>Channel Type</th>
                                    <th style={{background:"#f7f7f7"}}>Name</th>
                                  </tr>
                       {
                         channels.map((row)=>(
                          <><tr 
                          id={row.id}
                          onClick={(e)=>handleTableRowSelect(e)}>
                               <td>
                                  <label className="form-check-label">
                                    <input
                                      type="checkbox"
                                      id="channelsleftarray"
                                      name="channelsleftarray"
                                      className="check12"
                                      value={row.id}
                                      onChange={(e)=>rightCheckboxContainer(e)}/>
                                  </label>
                               </td>
                               <td style={{width:"30px"}}>{row.id}</td>
                               <td style={{width:"30px"}}>{row.channel_type}</td>
                               <td style={{width:"30px"}}>{row.name}</td>
                             </tr></>
                        ))}
                        </Table>
                        </div>
                        </div> 
                        </div>
                        <div className="col-xl-2">
                        <div>
                          <div className="form-check" align="center">
                            <button
                              type="button"
                              id="res"
                              name="res"
                              className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                              style={{ fontSize: "13px" }}
                              value={finaloutput.res}
                              onClick={(e) => RightClickHandle(e)}>
                                 {/* <FontAwesomeIcon icon="save" />faChevronRight */}
                                 <span className="mdi mdi-chevron-double-right"></span>
                            </button>
                          </div>
                        </div>
                        <div>
                          <div className="form-check" align="center">
                            <button
                              type="button"
                              id="channelsrightarray"
                              name="channelsrightarray"
                              className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                              style={{ fontSize: "13px" }}
                              value={userinfo.channelsrightarray}
                              onClick={(e) => LeftClickHandle(e)}
                            >
                              <span className="mdi mdi-chevron-double-left"></span>
                            </button>
                          </div>
                        </div>
                        </div>
                        <div className="col-xl-5">
                          <div className="container-box2">
                          <Table>
                                     <tr>
                                        <td style={{background:"#f7f7f7"}}>
                                        <input
                                        type="checkbox"
                                        id="channelsrightarray"
                                        name="channelsrightarray"
                                        className="checkboxRight"
                                        value={userinfo.channelsrightarray}
                                        onChange={(e)=>handleRightSelectAll(e)}
                                        >
                                        </input>
                                        </td>
                                        <td style={{background:"#f7f7f7"}}>ID</td>
                                        <td style={{background:"#f7f7f7"}}>Channel Type</td>
                                        <td style={{background:"#f7f7f7"}}>Name</td>
                                     </tr>
                             {
                               searchbyid.map((row,index) => (
                                   <tr>
                                     <td>
                                        <label className="form-check-label">
                                        <input
                                          type="checkbox"
                                          id="channelsrightarray"
                                          name="channelsrightarray"
                                          className="checkboxRight"
                                          // checked={checked}
                                          value={row.id || ""}
                                          onChange={(e)=>leftCheckboxContainer(e)} 
                                          />
                                          </label>
                                      </td>
                                      <td>{row.id}</td>
                                      <td>{row.channel_type}</td>
                                      <td>{row.name}</td>
                                    </tr>
                               )
                               )
                             }
                            </Table>
                            </div>
                          </div>
                      </Form.Group>
                      <Form.Group >
                      <label className="col-sm-3 col-form-label text-right"></label>
                        <div className="col-sm-4">
                          <Form.Control
                          className="form-control customTextarea"
                          type="text"
                          style={{display:"none"}}
                          as="textarea"
                          rows="4"
                          name="channel_choice"
                          value={createBidder.channel_choice || ""}
                          onClick={e => onInputChannelChoiceChange(e)}
                          >
                          </Form.Control>
                        </div>
                    </Form.Group>
                    </> : <></>}
                    </fieldset>
                    </div>

                        {/* App vs. Mobile Web | Content Category | Domain & App Bundle Targeting*/}
                        <fieldset>
                            <legend>
                              <span onClick={handleCollapseContentCategory}  style={{fontSize:"18px"}} className={ collapseContentCategory ? "mdi mdi-minus-box" : "mdi mdi-plus-box"}></span> 
                              <span>  App vs. Mobile Web | Content Category | Domain & App Bundle Targeting</span>
                            </legend>
                            {collapseContentCategory ? <>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right">App or Mobile Web Targeting</label>
                                <div className="col">
                                    <select className="form-control customDropDown" name="app_mobile_target" onChange={e => onInputChange(e)} style={{width:"160px"}}>
                                        <option selected={packages.app_mobile_target == "any"}  value="any">Any</option>
                                        <option selected={packages.app_mobile_target == "app"}  value="app">App</option>
                                        <option selected={packages.app_mobile_target == "mobile_web"}  value="mobile_web">Mobile Web</option>
                                    </select>
                                </div>
                            </Form.Group>
                            <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label text-right">Content Categories</label>
                                    <div className="col">
                                        <div className='row'>
                                            <div className="col-sm-9">
                                            <Select
                                                isMulti
                                                options={contentCategory}
                                                classNamePrefix="select"
                                                onChange={(e) => contentCategoryMultiselect(e)}
                                                isLoading={false}
                                                value={defaultDataForContentCategory}
                                                isClearable={false} 
                                                isSearchable={true}
                                                isRtl={false}
                                            />
                                            </div>
                                        </div>
                                        <div className='row'>
                                            <div className="col-sm-1 text-left">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input
                                                        type="radio"
                                                        className="form-check-input"
                                                        name="content_categories_include_exclude"
                                                        value="include"
                                                        checked={packages.content_categories_include_exclude == "include"}
                                                        onChange={e => onInputChange(e)}
                                                    />
                                                    Include
                                                    <i className="input-helper"></i>
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="col-sm-1">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input
                                                        type="radio"
                                                        className="form-check-input"
                                                        name="content_categories_include_exclude"
                                                        value="exclude"
                                                        checked={packages.content_categories_include_exclude == "exclude"}
                                                        onChange={e => onInputChange(e)}
                                                    />
                                                    Exclude
                                                    <i className="input-helper"></i>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label text-right">Site Domain & App Bundle Targeting</label>
                                    <div className="col">
                                        <div className='row'>
                                            <div className="col-sm-9">
                                            <Form.Control
                                                className="form-control customTextarea"
                                                type="text"
                                                name="site_domain_bundle_target"
                                                as="textarea"
                                                row={3}
                                                value={packages.site_domain_bundle_target || ""}
                                                onChange={e => onInputChange(e)}
                                            />
                                            </div>
                                        </div>
                                        <div className='row'>
                                            <div className="col-sm-1 text-left">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input
                                                        type="radio"
                                                        className="form-check-input"
                                                        name="site_domain_bundle_target_include_exclude"
                                                        value="include"
                                                        checked={packages.site_domain_bundle_target_include_exclude == "include"}
                                                        onChange={e => onInputChange(e)}
                                                    />
                                                    Include
                                                    <i className="input-helper"></i>
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="col-sm-1">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input
                                                        type="radio"
                                                        className="form-check-input"
                                                        name="site_domain_bundle_target_include_exclude"
                                                        value="exclude"
                                                        checked={packages.site_domain_bundle_target_include_exclude == "exclude"}
                                                        onChange={e => onInputChange(e)}
                                                    />
                                                    Exclude
                                                    <i className="input-helper"></i>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label mt-1 text-right">Adult Content</label>
                                    {/* <div className="col-sm-2"> */}
                                            <div className="col-sm-2 text-left" style={{maxWidth: "14%"}}>
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input
                                                        type="radio"
                                                        className="form-check-input"
                                                        name="adult_content"
                                                        value="no_adult_content"
                                                        checked={packages.adult_content == "no_adult_content"}
                                                        onChange={e => onInputChange(e)}
                                                    />
                                                    No adult content
                                                    <i className="input-helper"></i>
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="col-sm-2">
                                                <div className="form-check">
                                                    <label className="form-check-label">
                                                    <input
                                                        type="radio"
                                                        className="form-check-input"
                                                        name="adult_content"
                                                        value="any_content"
                                                        checked={packages.adult_content == "any_content"}
                                                        onChange={e => onInputChange(e)}
                                                    />
                                                    Any content
                                                    <i className="input-helper"></i>
                                                    </label>
                                                </div>
                                            </div>
                                        {/* </div> */}
                                </Form.Group>
                                </> : <></>}
                        </fieldset>
                        {/* App vs. Mobile Web | Content Category | Domain & App Bundle Targeting*/}

                        {/* Url Trageting */}
                        <fieldset>
                            <legend>
                            <span onClick={handleCollapseUrlTargetting}  style={{fontSize:"18px"}} className={ collapseUrlTargetting ? "mdi mdi-minus-box" : "mdi mdi-plus-box"}></span> 
                             <span> URL Targeting</span>
                            </legend>
                            {collapseUrlTargetting ? <>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right">URL Targeting</label>
                                <div className="col-sm-8">
                                    <Form.Control
                                        className="form-control customTextarea"
                                        type="text"
                                        name="url_targeting"
                                        as="textarea"
                                        row={3}
                                        value={packages.url_targeting || ""}
                                        onChange={e => onInputChange(e)}
                                    />
                                </div>
                            </Form.Group>
                            </>:<></>}
                        </fieldset>
                        {/* Url Trageting */}

                        {/* Carriers and Networks */}
                        <fieldset>
                            <legend>
                            <span onClick={handleCollapseCarrierNetwork}  style={{fontSize:"18px"}} className={ collapseCarrierNetwork ? "mdi mdi-minus-box" : "mdi mdi-plus-box"}></span> 
                                  <span> Carriers and Networks</span> </legend>
                            {collapseCarrierNetwork ? <>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right">
                                  Carrier Whitelist</label>
                                <div className="col-sm-8">
                                <Select
                                    isMulti
                                    options={networkCarrier}
                                    classNamePrefix="select"
                                    onChange={(e) => networkCarrierMultiselect(e)}
                                    isLoading={false}
                                    value={defaultDataForNetworkCarrier}
                                    isClearable={false} 
                                    isSearchable={true}
                                    isRtl={false}
                                />
                                </div>
                            </Form.Group>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right">ISP Whitelist</label>
                                <div className="col-sm-8">
                                    <Select
                                        isMulti
                                        options={networkISP}
                                        classNamePrefix="select"
                                        onChange={(e) => networkISPMultiselect(e)}
                                        isLoading={false}
                                        value={defaultDataForNetworkISP}
                                        isClearable={false} 
                                        isSearchable={true}
                                        isRtl={false}
                                    />
                                </div>
                            </Form.Group>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right">WiFi Targeting</label>
                                <div className="col">
                                    <select className="form-control customDropDown" name="wifiTargeting" onChange={e => onInputChange(e)} style={{width:"160px"}}>
                                        <option selected={packages.wifiTargeting == "any"}  value="any">Any</option>
                                        <option selected={packages.wifiTargeting == "cellular_networks_only"}  value="cellular_networks_only">Cellular Networks Only</option>
                                        <option selected={packages.wifiTargeting == "wifi_only"}  value="wifi_only">Wifi Only</option>
                                    </select>
                                </div>
                            </Form.Group>
                            </>:<></>}
                        </fieldset>
                        {/* Carriers and Networks */}

                        {/* Location  */}
                        <fieldset>
                            <legend>
                            <span onClick={handleCollapseLocation}  style={{fontSize:"18px"}} className={ collapseLocation ? "mdi mdi-minus-box" : "mdi mdi-plus-box"}></span> 
                             <span>Location</span> </legend>
                             {!collapseLocation ? <>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right">Country</label>
                                <div className="col">
                                <Select
                                    className="basic-single"
                                    classNamePrefix="select"
                                    isLoading={false}
                                    value={defaultCountryData[0]}
                                    isClearable={false} 
                                    isSearchable={true}
                                    name="country"
                                    onChange={(e) => onInputChangeCountry(e)}
                                    isRtl={false}
                                    options={countryData}
                                />
                                </div>
                            </Form.Group>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right">States</label>
                                <div className="col-sm-8">
                                <Select
                                    isMulti
                                    options={stateData}
                                    onChange={(e) => stateMultiselect(e)}
                                    isLoading={false}
                                    value={defaultStateData }
                                    isClearable={false} 
                                    isSearchable={true}
                                    isRtl={false}
                                />

                                </div>
                            </Form.Group>
                            <Form.Group className="row">
                                <label className="col-sm-2 col-form-label text-right">Cities</label>
                                <div className="col">
                                <Select
                                        isMulti
                                        options={citiesData}
                                        classNamePrefix="select"
                                        onChange={(e) => onInputChangeCities(e)}
                                        isLoading={false}
                                        value={defaultCitiesData}
                                        isClearable={false} 
                                        isSearchable={true}
                                        isRtl={false}
                                    />
                                </div>
                            </Form.Group>
                            </> : <></>}
                        </fieldset>
                        {/* Location  */}

                    {/* Performance Matrix  */}
                    <fieldset>
                            <legend>
                            <span onClick={handleCollapsePerformanceMatrix}  style={{fontSize:"18px"}} className={ collapsePerformanceMatrix ? "mdi mdi-minus-box" : "mdi mdi-plus-box"}></span> 
                              <span>Performance Metrics</span> </legend>
                              {collapsePerformanceMatrix ?  <>
                                <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label text-right"> Viewability Score</label>
                                    <div className="col-sm-3">
                                        <Form.Control
                                            className="form-control customInput"
                                            type="text"
                                            name="viewability_score"
                                            placeholder='0.000'
                                            value={packages.viewability_score || ""}
                                            onChange={e => onInputChange(e)}
                                        />
                                    </div>
                                    <div className='col-sm-3' align='left'>
                                    [Range 0 to 1]
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label text-right"> Video Completetion Rate</label>
                                    <div className="col-sm-3">
                                        <Form.Control
                                            className="form-control customInput"
                                            type="text"
                                            name="vtr"
                                            value={packages.vtr || ""}
                                            placeholder='0.000'
                                            onChange={e => onInputChange(e)}
                                        />
                                        
                                    </div>
                                    <div className='col-sm-3' align='left'>
                                    [Range 0 to 1]
                                    </div>
                                    <div className='container'>
                                    <div className='row '>
                                    <label className="col-sm-2 col-form-label text-right"></label>
                                    <div className="col-sm-8 controls min-controls" style={{color: "#49afcd",padding:0 ,fontSize: "13px"}}>
                                            <b>Note: </b>This performance metrics will be applicable for video inventory only
                                        </div>
                                    </div>
                                    </div>
                                </Form.Group>
                                <Form.Group className="row">
                                    <label className="col-sm-2 col-form-label text-right"> Click Through Rate</label>
                                    <div className="col-sm-3">
                                        <Form.Control
                                            className="form-control customInput"
                                            type="text"
                                            name="ctr"
                                            value={packages.ctr || ""}
                                            onChange={e => onInputChange(e)}
                                            placeholder='0.000'
                                        />
                                    </div>
                                    <div className='col-sm-3' align='left'>
                                    [Range 0 to 1]
                                    </div>
                                </Form.Group>
                              </> : <></>}
                        </fieldset>
                        <br/>
                        
                    {/* Performance Matrix  */}

                    {/* Ads Txt &  Seller  */}
                    <fieldset>
                    <legend>
                    <span onClick={handleCollapseAdsTxtSeller}  style={{fontSize:"18px"}} className={ collapseAdsTxtSeller ? "mdi mdi-minus-box" : "mdi mdi-plus-box"}></span> 
                      <span>Ads.Txt and Seller Filter</span> </legend>
                      {collapseAdsTxtSeller ? <>  
                        <Form.Group className="row">
                            <label className="col-sm-2 col-form-label text-right">
                              Ads.Txt Domains
                            </label>
                            <div className="col-sm-4">
                              <Form.Control
                                className="form-control customInput"
                                type="text"
                                name="ads_default_domains"
                                value={packages.ads_default_domains || ''}
                                onChange={e => onInputChange(e)}
                              />
                            </div>
                            <div className="col">
                            <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="checkbox" 
                                className="form-check-input"
                                onChange={e => onInputChangeAdsTxtDomain(e)}
                                name="ads_default_domains_select"
                                value="true"
                                
                                checked={Array.isArray(packages.ads_default_domains_select ) && packages.ads_default_domains_select?.find(item => item == "true") ? true : ""}
                              />
                              <i className="input-helper"></i>
                              Selected
                            </label>
                          </div>
                        </div>
                        </Form.Group>
                        <Form.Group className="row">
                            <label className="col-sm-2 col-form-label text-right">AdsTxt</label>
                            <div className="col">
                                <div className="form-check">
                                    <label className="form-check-label">
                                    <input 
                                            type="checkbox" 
                                            className="form-check-input"
                                            onChange={e => onInputChangeAdsTxt(e)}
                                            name="adsTxt"
                                            value="ture"
                                            checked={Array.isArray(packages.adsTxt ) && packages.adsTxt?.find(item => item == "ture") ? true : ""}
                                    />
                                    <i className="input-helper"></i>Ads.txt enabled for selected domain(s)</label>
                                </div>
                            </div>                  
                        </Form.Group>
                        <Form.Group className="row">
                            <label className="col-sm-2 col-form-label text-right">Seller Enabled</label>
                            <div className="col">
                                <div className="form-check">
                                <label className="form-check-label">
                                    <input 
                                        type="checkbox" 
                                        className="form-check-input"
                                        onChange={e => onInputChangeSellerEnabled(e)}
                                        // name="seller_enabled"
                                        // value="12345678999098765432"
                                        checked={Array.isArray(packages.seller_enabled ) && packages.seller_enabled?.find(item => item == "135711") ? true : ""}
                                        disabled
                                    />
                                    <i className="input-helper"></i>Seller enabled for selected domain(s)
                                </label>
                                </div>
                            </div>                  
                        </Form.Group>
                        <Form.Group className="row">
                            <label className="col-sm-2 col-form-label text-right">
                              Account Type
                            </label>
                            <div className="col">
                            <div className="form-check">
                            <label className="form-check-label">
                            <input 

                                // onChange={e => onInputChangeAdsTxt(e)}
                                // name="ads_default_domains_select"
                                // value="true"
                                // checked={Array.isArray(packages.ads_default_domains_select ) && packages.ads_default_domains_select?.find(item => item == "true") ? true : ""}

                                type="checkbox" 
                                className="form-check-input" 
                                onChange={e => onInputChangeAccTypeCheck(e)}
                                name="account_type"
                                value="reseller"
                                checked={Array.isArray(packages.account_type ) && packages.account_type?.find(item => item == "reseller") ? true : ""}
                            />
                              <i className="input-helper"></i>
                              RESELLER
                            </label>
                            </div>
                            </div> 
                            <div className="col-sm-8">
                            <div className="form-check">
                            <label className="form-check-label">
                              <input 
                              type="checkbox" 
                              className="form-check-input"
                              onChange={e => onInputChangeAccTypeCheck(e)}
                              name="account_type"
                              value="direct"
                              checked={Array.isArray(packages.account_type ) && packages.account_type?.find(item => item == "direct") ? true : ""}
                              />
                              <i className="input-helper"></i>
                              DIRECT
                            </label>
                            </div>
                            </div>                    
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Supply Chain Applicability
                          </label>
                          <div className="col" style={{flexGrow: "0"}}>
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="supply_chain_applicability"
                                  value="yes"
                                  checked={packages.supply_chain_applicability == "yes"}
                                  onChange={e => onInputChange(e)}
                                />
                                All
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                          <div className="col-md-3">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="supply_chain_applicability"
                                  value="no"
                                  checked={packages.supply_chain_applicability == "no"}
                                  onChange={e => onInputChange(e)}
                                />
                                Complete Only(complete=1)
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                      </>:<></>}
                  </fieldset>
                    {/* Ads Txt & Seller  */}

                    </div>
                    {/* Video Inventory Type  */}
                    <Form.Group className="row mt-4">
                        <label className="col-sm-2 col-form-label text-right"></label>
                        <div className="col-sm-9 ml-2">
                            <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                >
                                Submit
                                <FontAwesomeIcon icon="save" />
                            </button>
                        </div>
                    </Form.Group>
                </Form>
            </div>
        </div>
    </div>
    </>
  )
}
export default AddEditPackages
