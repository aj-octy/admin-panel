import * as React from 'react';
import { Link ,useHistory} from 'react-router-dom';
import PropTypes from 'prop-types';
import { useTheme } from '@mui/material/styles';
import {useState, useEffect} from 'react';
import { Switch } from '@material-ui/core';
import { Form, Row, Col} from 'react-bootstrap'
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import TableContainer from '@mui/material/TableContainer';
import { tableCellClasses } from '@mui/material/TableCell';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import IconButton from '@mui/material/IconButton';
import FirstPageIcon from '@mui/icons-material/FirstPage';
import KeyboardArrowLeft from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRight from '@mui/icons-material/KeyboardArrowRight';
import LastPageIcon from '@mui/icons-material/LastPage';
import {library} from '@fortawesome/fontawesome-svg-core'
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import { faSearch,faEdit,faGear } from '@fortawesome/free-solid-svg-icons'
import Curd from '../../common/Calls_methods'
import {toast} from 'react-toastify';


library.add(faSearch)
library.add(faEdit)
library.add(faGear)



function TablePaginationActions(props) {
  const theme = useTheme();
  const { count, page, rowsPerPage, onPageChange } = props;

  const handleFirstPageButtonClick = (event) => {
    onPageChange(event, 0);
  };

  const handleBackButtonClick = (event) => {
    onPageChange(event, page - 1);
  };

  const handleNextButtonClick = (event) => {
    onPageChange(event, page + 1);
  };

  const handleLastPageButtonClick = (event) => {
    onPageChange(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };

  return (
    <Box sx={{ flexShrink: 0, ml: 2.5 }}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton
        onClick={handleBackButtonClick}
        disabled={page === 0}
        aria-label="previous page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </Box>
  );
}

TablePaginationActions.propTypes = {
  count: PropTypes.number.isRequired,
  onPageChange: PropTypes.func.isRequired,
  page: PropTypes.number.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
};





function Packages() {

  
  let history= useHistory();
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(50);
  const [data,setData]=useState([]);
  const [assoc_details, setassoc_details] = useState("asc");
  const [created_at, setcreated_at] =useState("asc");
  const [statusDirection, setstatusDirection] = useState("asc");

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };


  const sortBystatus =()=> {
    if (statusDirection === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.id - a.id;
        })
      );
      setstatusDirection("desc");
    }

    if (statusDirection === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setstatusDirection("asc");
    }
  }


  const sortBycreated_at =()=> {
    if (created_at === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.id - a.id;
        })
      );
      setcreated_at("desc");
    }

    if (created_at === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setcreated_at("asc");
    }
  };

  const sortByassoc_details = () => {
    if (assoc_details === "asc") {
      setData(
        data.slice().sort((a, b) => {
          return b.id - a.id;
        })
      );
      setassoc_details("desc");
    }

    if (assoc_details === "desc") {
      setData(
        data.slice().sort((a, b) => {
          return a.id - b.id;
        })
      );
      setassoc_details("asc");
    }
  };


  useEffect(()=>{
    getData();
  },[]);
  
  const getData=()=>{
  //   Curd.details("packages").then((res)=> {
  //   setData(res.data);
  // });

  let keyword = search.packagesName
    Curd.getTableData(`packages/searchPackageData?${keyword}`).then((res)=> {
    setData(res.data);
    });
  };

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - data.length) : 0;
  const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: '#21364e',
      color: theme.palette.common.white,
      fontSize: 15,
      height: 0,
      // FontFace: "arial",
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));
  
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 0,
      height: 0,
    },
  }));
  
  const AntSwitch = styled(Switch)(({ theme }) => ({
    width: 28,
    height: 16,
    padding: 0,
    display: 'flex',
    '&:active': {
      '& .MuiSwitch-thumb': {
        width: 15,
      },
      '& .MuiSwitch-switchBase.Mui-checked': {
        transform: 'translateX(9px)',
      },
    },
    '& .MuiSwitch-switchBase': {
      padding: 2,
      '&.Mui-checked': {
        transform: 'translateX(12px)',
        color: '#fff',
        '& + .MuiSwitch-track': {
          opacity: 1,
          backgroundColor: theme.palette.mode === 'dark' ? '#177ddc' : '#1890ff',
        },
      },
    },
    '& .MuiSwitch-thumb': {
      boxShadow: '0 2px 4px 0 rgb(0 35 11 / 20%)',
      width: 12,
      height: 12,
      borderRadius: 6,
      transition: theme.transitions.create(['width'], {
        duration: 200,
      }),
    },
    '& .MuiSwitch-track': {
      borderRadius: 16 / 2,
      opacity: 1,
      backgroundColor:
        theme.palette.mode === 'dark' ? 'rgba(255,255,255,.35)' : 'rgba(0,0,0,.25)',
      boxSizing: 'border-box',
    },
  }));
  
//For Activated(Status)

    const initialValueToggle={status : "active"}
    const [statusState, setStatusState]=useState(initialValueToggle);
    const { status } = statusState;
    const handleChange=(e, index)=>{
      let status = e.target.checked ? "active":"inactive";
      Curd.update(`packages/status`,index,{status:status})
      .then(toast.success("Status Updated",{
        position: "top-right",
        autoClose: 4000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        }))
    }

//For Activated(Status)

// serach 

const initialValueForSearch = { packagesName:"" }
const [search,setSearch] = useState(initialValueForSearch);
const {packagesName} = search;

const onInputChangeKeyword=(e)=>{
  setSearch(item1=>({packagesName: e.target.value }));
}

const onSubmitKeyword = e => {
  console.log()
  e.preventDefault();
  getData();
}

// serach 

  return (
    <>
    
        <Row>
          <Col xs='4'>
          <Form onSubmit={(e) => onSubmitKeyword(e)}>
            <Row>
              <Col>
                <Form.Control
                  className="form-control customInput"
                  type="text"
                  name="name"
                  // value={""}
                  placeholder="Search Deal"
                  onChange={(e) => onInputChangeKeyword(e)}
                />
              </Col>
              <button
                type="submit"
                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                >Search <FontAwesomeIcon icon="search" />
              </button>
            </Row>
          </Form>
          </Col>
          <Col align='right'>
          <Link to={"/tools/AddEditPackages"}>
          <button 
                type="button"
                className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
          >Create New Package
          <i className="mdi mdi-account-multiple mdi-plus"></i>
          </button>
          </Link>
          </Col>
          
        </Row>
      
      <br/>
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      
        <TableContainer className='tablewidth'>
          <Table sx={{ minWidth: 200 }} size='small' stickyHeader aria-label="customized table">
            <TableHead sx={{width: '50%'}}>
              <StyledTableRow>
                  <StyledTableCell  align='left' onClick={() => sortByassoc_details("assoc_details")}>Associated Details</StyledTableCell>
                  <StyledTableCell align="left" onClick={() => sortBycreated_at("created_at")}>Created At</StyledTableCell>
                  <StyledTableCell align="left" onClick={() => sortBystatus("status")}>Status</StyledTableCell>
                  <StyledTableCell align='center'><FontAwesomeIcon icon="gear" /></StyledTableCell>
              </StyledTableRow>
            </TableHead>
            <TableBody sx={{width: '100%'}}>
              {(rowsPerPage > 0
                ? data.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                : data
              ).map((row,index) => (
                    <StyledTableRow  key={index} defaultValue={row.selected}>
                        <StyledTableCell>{row.name}</StyledTableCell>
                        <StyledTableCell>{row.created_at}</StyledTableCell>
                        <StyledTableCell >
                        <AntSwitch inputProps={{ 'aria-label': 'ant design' }} 
                          color='primary'
                          size='small'
                          defaultChecked={row.status == "active" ?  true : false}
                          onChange={(e)=>handleChange(e,row.id) }
                          name="status"
                        />
                        </StyledTableCell>
                        <StyledTableCell align='center'>
                        <Link to={`/tools/AddEditPackages/${row.id}`}><FontAwesomeIcon icon="edit" /></Link>
                        </StyledTableCell>
                  </StyledTableRow>
 
              ))}

              {emptyRows > 0 && (
                <StyledTableRow style={{ height: 53 * emptyRows }}>
                </StyledTableRow>
              )}
            </TableBody>
            
          </Table>
         </TableContainer>
      </Paper>
      <Paper>
          <TableContainer>
              <Table>
                  <TableBody>
                      <TablePagination
                        rowsPerPageOptions={[50, 100, 200, 250, { label: 'All', value: -1 }]}
                        count={data.length}
                        rowsPerPage={rowsPerPage}
                        page={page}
                        SelectProps={{
                          inputProps: {
                            'aria-label': 'rows per page',
                          },
                          native: true,
                        }}
                        onPageChange={handleChangePage}
                        onRowsPerPageChange={handleChangeRowsPerPage}
                        ActionsComponent={TablePaginationActions}
                      />
                  </TableBody>
              </Table>
            </TableContainer>
        </Paper>
      </>
  );

}

export default Packages