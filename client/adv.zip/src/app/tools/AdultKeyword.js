import React, { useState } from 'react';
import { useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button } from 'react-bootstrap';
import styles from '../styles.module.css';


function Adult_Keywords() {

const [data,setData]=useState([]);

const [name,setName]=useState([]);

// const [action,setaction]
  
useEffect(()=>{
  getData();
},[]);


  

const getData=()=>{
  axios("http://localhost:5000/adult_keywords").then((res)=> {
  //console.log(res.data);
  //setData(res.data);
  setData(res.data);
});
};


const handleDelete = (rowId, name) => {
  console.log(rowId, name);
  //1 YourCellName
};
const handleEdit = (rowId, name) => {
  console.log(rowId, name);
  //1 YourCellName
};

  return (
    <>
    <div align="left" className={styles.container}>
        <h4>Adult Keywords</h4>
        <form className="form-inline mt-4 mb-4">
          <input style={{width:"250px"}} className="form-control form-control-sm"  type="text" placeholder="Search Keywords..." aria-label="Search" onChange={(e)=>{
            setName(e.target.value)}} />
          <Button style={{marginLeft:"10px"}} color="primary" size='sm' >Search</Button>{' '}
          
        </form>
          
    </div>

     
   
      </>
  )
}

export default Adult_Keywords