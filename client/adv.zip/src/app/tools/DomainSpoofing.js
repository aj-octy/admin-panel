import React, { useState } from 'react';
import { useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Container,Row,Col } from 'react-bootstrap';


function DomainSpoofing() {

const [data,setData]=useState([]);

const [name,setName]=useState([]);

// const [action,setaction]
  
useEffect(()=>{
  getData();
},[]);


  

const getData=()=>{
  axios("http://localhost:5000/advertiser").then((res)=> {
  //console.log(res.data);
  //setData(res.data);
  setData(res.data);
});
};




const handleDelete = (rowId, name) => {
  console.log(rowId, name);
  //1 YourCellName
};
const handleEdit = (rowId, name) => {
  console.log(rowId, name);
  //1 YourCellName
};

  return (
    <>
    {/* <div align="left" className={styles.container}> */}
        <h4>Domain Spoofing</h4>
        <Container>
          <Row xs='auto'>
          
          
        <form className="form-inline mt-4 mb-4">
       
          <input style={{width:"250px"}} className="form-control form-control-sm"  type="text" placeholder="Search ApiKey/Publisher" aria-label="Search" onChange={(e)=>{
            setName(e.target.value)}} />
        
        
        <Col>
          <Button color="primary" size='sm' >Search</Button>{' '}
          </Col>
        </form>
        </Row>
        </Container>
        <Container>
          <Row xs='auto'>
            
            <Button variant='success' size='sm'>Mark As Spoof</Button>{' '}
            
            
          </Row>
        </Container>
        <br/>
          
    {/* </div> */}

     
   
      </>
  )
}

export default DomainSpoofing