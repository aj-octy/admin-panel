import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button,Modal } from 'react-bootstrap';


function Edit({show,handleClose,data,onInputChange,onSubmit}) {

  // const [show, setShow] = useState(false);

  // const handleClose = () => setShow(false);
  // const handleShow = () => setShow(true);

  
const {id, height, width} = data

  return (
    
    <div>
        {/* <Button variant="primary" onClick={handleShow}>
        Launch demo modal
      </Button> */}

      <Modal show={show} onHide={handleClose}
      className='custom-modal-style'>
        <Modal.Header closeButton>
          <Modal.Title>{id? "Update AdSize ":"Create AdSize"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <form className="form-inline mt-4 mb-4" onSubmit={e => onSubmit(e)}>
          <input name="height" value={height} onChange={e => onInputChange(e)} className="form-control form-control-sm"  type="text" placeholder='height'/>
          <input name="width" value={width} onChange={e => onInputChange(e)} className="form-control form-control-sm"  type="text" placeholder='width'/>
          <Button color="primary" type='submit' size='sm'>{id?"Update":"Submit"}</Button>
        </form>
        </Modal.Body>
        <Modal.Footer>
          {/* <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button> */}
        </Modal.Footer>
      </Modal>
    </div>

   
      
  )
}

export default Edit