import React from 'react'

function UploadFiles() {
  return (
    <div>UploadFiles</div>
  )
}

export default UploadFiles