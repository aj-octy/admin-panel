import React
// ,{ useState }
 from 'react';
// import { useEffect } from 'react';
// import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button,Modal } from 'react-bootstrap';
// import styles from '../styles.module.css';
// import { useParams,useHistory } from 'react-router-dom'

function Edit({show,handleClose,data,onInputChange,onSubmit}) {

    // const [show, setShow] = useState(false);
  
    // const handleClose = () => setShow(false);
    // const handleShow = () => setShow(true);
  
    
  const {credit} = data
  
    return (
      
      <div>
          {/* <Button variant="primary" onClick={handleShow}>
          Launch demo modal
        </Button> */}
  
        <Modal show={show} onHide={handleClose}
        className='custom-modal-style'>
          <Modal.Header closeButton>
            <Modal.Title>Add Credit To Advertiser</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <form className="form-inline mt-4 mb-4" onSubmit={e => onSubmit(e)}
        //   onSubmit={e => onSubmit(e)}
        >
            <input name="credit" value={credit} onChange={e => onInputChange(e)} className="form-control form-control-sm"  type="text" placeholder='credit'/>

            <Button color="primary" type='submit' size='sm'>Submit</Button>
          </form>
          </Modal.Body>
          <Modal.Footer>
          </Modal.Footer>
        </Modal>
      </div>
  
     
        
    )
  }
  
  export default Edit