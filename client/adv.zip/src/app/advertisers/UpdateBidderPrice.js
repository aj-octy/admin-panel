import React, { useState } from 'react';
import { Button,Modal } from 'react-bootstrap';
import { Form , Row, Col, Container} from 'react-bootstrap';
import './modal.css'

function UpdateBidderPrice({showBidderPrice,handleCloseBidderPrice,data,onInputChangeBidderPrice,onSubmitBidderPrice}){
    const {BidderPrice} = data;
    console.log("*************************  test ")
    console.log(data)
    console.log(BidderPrice)
    console.log("*************************  test ")
    return(
        <>
            <Modal show={showBidderPrice} onHide={handleCloseBidderPrice}
            className="custom-modal-style">
                <Modal.Header closeButton>
                    <Modal.Title><h3>Bidder Price</h3>  </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                <form className="form mt-4 mb-4" onSubmit={e => onSubmitBidderPrice(e)}>
                    <div className='container'>
                            <Row>
                                <Col xs={4} align='right' className='mt-2'>
                                    <label><h5>CPM:</h5></label>
                                </Col>
                                
                                <Col align='left' xs={4}> 
                                    <Form.Group>
                                            <div className="input-group">
                                            <Form.Control
                                                type="text"
                                                className="form-control customInput"
                                                placeholder="5.00"
                                                value={BidderPrice}
                                                name='BidderPrice'
                                                style={{width:"40px"}}
                                                onChange={e => onInputChangeBidderPrice(e)} 
                                            />
                                            <div className="input-group-prepend">
                                                <span style={{borderRadius: "0px 5px 5px 0px",}}className="input-group-text">%</span>
                                            </div>
                                            </div>
                                        </Form.Group>
                                </Col>
                                <Col className='text-center mt-1'>
                                <button
                                    type='submit'
                                    className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                    >Save
                                    </button>
                                </Col>
                            </Row>
                            <br/>

                            
                            {/* </div>
                        </div> */}
                    </div>
                </form>
                </Modal.Body>
            </Modal>
        </>
    )
}

export default UpdateBidderPrice