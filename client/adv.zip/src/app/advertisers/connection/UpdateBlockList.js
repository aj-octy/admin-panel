import React from 'react';
import { Modal } from 'react-bootstrap';
import './UpdateApproveList.css'


function UpdateApproveList({showBlock,handleBlockClose,onBlockedInputChange,onBlockedSubmit,data}) {

  const {domain,status,platform}=data
  return (
    
    <div>

      <Modal show={showBlock} onHide={handleBlockClose} 
      className="custom-modal-style"
      size="md"
      >
        
        <Modal.Header closeButton>
        <Modal.Title><h3>Media (Blacklist)</h3></Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <form className="form" onSubmit={e => onBlockedSubmit(e)}>
          <div className='container-fluid'>
            <div className='row'>
                    <div className='col-sm-5'></div>
                    <div className='col-sm-6-text-right'>Please limit each row to one media.</div>
                    <div className='col-sm-3'>
                        <div className='row'>
                            <select 
                                className="form-control tableDropDown"
                                label="Select One"
                                name="platform"
                                onChange={e=>onBlockedInputChange(e)}
                                // value={allowed_networks}
                                // onChange={onInputNetworkChange}
                                >
                                  <option 
                                  value="site"
                                  selected={platform == "site"}
                                  >Sites(Domain)</option>
                                  <option
                                  value="app"
                                  selected={platform == "app"}
                                  >Apps(Bundle)</option>
                              </select>
                        </div>
                        <br/>
                        {/* </form> */}
                    </div>
            </div>
            <div className="col-sm-14">
                          <textarea
                            className="form-control customTextarea"
                            rows="14"
                            name="domain"
                            value={domain}
                            // value={createBidder.BidderUrl || ""}
                            onChange={e => onBlockedInputChange(e)}
                          ></textarea>
                        </div>
          </div>
          <br/>
          <div className='row'>
          <div className='col-sm-11'></div>
          <div className='col-sm-1' style={{marginLeft:"-35px"}} >
                        <button align='center' type="submit" className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg">Submit</button>
          </div>
          </div>
          </form>
        </Modal.Body>
        <Modal.Footer>
        <button 
        className="btn btn-gradient-dark btn-rounded btn-icon-text btn-lg"
        variant="secondary" onClick={handleBlockClose}>Close </button>
        </Modal.Footer>
      </Modal>
    </div>

   
      
  )
}

export default UpdateApproveList