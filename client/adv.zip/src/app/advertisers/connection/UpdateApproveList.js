import React from 'react';
import { Modal } from 'react-bootstrap';
import './UpdateApproveList.css'


function UpdateApproveList({showApprove,data,handleApproveClose,onApproveInputChange,onApproveSubmit}) {

  const {domain,status,platform}=data
  return (
    
    <div>

      <Modal show={showApprove} onHide={handleApproveClose} 
      className="custom-modal-style"
      size="md"
      >
        
        <Modal.Header closeButton>
        <Modal.Title><h3>Media (Whitelist)</h3></Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <form className="form" onSubmit={e => onApproveSubmit(e)}>
          <div className='container-fluid'>
            <div className='row'>
                    <div className='col-sm-5'></div>
                    <div className='col-sm-6-text-right'>Please limit each row to one media.</div>
                    <div className='col-sm-3'>
                    
                        <div className='row'>
                            <select 
                                className="form-control tableDropDown"
                                name="platform"
                                label="Select One"
                                // value={allowed_networks}
                                onChange={e=>onApproveInputChange(e)}
                                >
                                  <option 
                                  value="site" 
                                  selected={platform == "site"}
                                  >Sites(Domain)</option>
                                  <option 
                                  value="app" 
                                  selected={platform == "app"}
                                  >Apps(Bundle)</option>
                              </select>
                        </div>
                        <br/>
                        
                    </div>
            </div>
            <div className="col-sm-14">
                          <textarea
                            className="form-control customTextarea"
                            rows="14"
                            name="domain"
                            value={domain}
                            onChange={e => onApproveInputChange(e)} 
                          ></textarea>
                          {/* <textarea
                            className="form-control customTextarea"
                            rows="14"
                            name="status"
                            value={status}
                            // onChange={e => onApproveInputChange(e)} 
                          ></textarea> */}
                        </div>
          </div>
          <br/>
          <div className='row'>
                <div className='col-sm-11' ></div>
                <div className='col-sm-1' style={{marginLeft:"-35px"}}>
                        <button  type="submit" className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg">Submit</button>
                </div>
          </div>
          </form>
        </Modal.Body>
        <Modal.Footer>
        <button 
        className="btn btn-gradient-dark btn-rounded btn-icon-text btn-lg"
        variant="secondary" onClick={handleApproveClose}>Close </button>
        </Modal.Footer>
      </Modal>
    </div>

   
      
  )
}

export default UpdateApproveList