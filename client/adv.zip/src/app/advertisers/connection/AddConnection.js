import React,{useState, useEffect} from "react";
import styles from "../../styles.module.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { Table } from "react-bootstrap";
import { Form } from "react-bootstrap";
import { library } from "@fortawesome/fontawesome-svg-core";
import { faSave } from "@fortawesome/free-solid-svg-icons";
import {faChevronRight} from "@fortawesome/free-solid-svg-icons";
import {faChevronLeft} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import axios from 'axios';
import {useParams, useHistory} from 'react-router-dom';
import {toast} from 'react-toastify';
import UpdateApproveList from './UpdateApproveList';
import UpdateBlockList from './UpdateBlockList'
import { data, event } from "jquery";
import { TableHead } from "@mui/material";
import { styled } from '@mui/material/styles';
import Crud from '../../common/Calls_methods';
import Box from '@mui/material/Box';
// import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
// import TableHead from '@mui/material/TableHead';
import TableContainer from '@mui/material/TableContainer';
import { tableCellClasses } from '@mui/material/TableCell';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import { create } from "@mui/material/styles/createTransitions";



library.add(faSave);
library.add(faChevronRight);
library.add(faChevronLeft);


function AddConnection() {

  

  const [countries, setCountries]=useState([]);
  const [channels, setChannels]=useState([]);
  const [adSizeList, setAdSizeList]=useState([]);

  const [userinfo, setUserInfo]=useState({
    channelsleftarray: [],
    channelsrightarray: [],
  });

  const [userinfoAdSizeList, setUserInfoAdSizeList]=useState({
    channelsleftarrayForAdSize: [],
    channelsrightarrayForAdSize: [],
  })

  const [userinfoCountryList, setUserInfoCountryList]=useState({
    leftarrayforCountry: [],
    rightarrayforCountry: [],
  })

  useEffect(()=>{
    getChannelsData(search.name);
  },[]);
  
  const getChannelsData = (search) => {
    axios(`http://localhost:5000/channels/search?${search}`).then((res)=>{
      console.log(res.data.length)
      setChannels(res.data);
    })
  }

  //Populate Form
  const { id } = useParams();
  if(id==""){createBidder=''}


  useEffect(()=>{
    getAdSizeFilterData(searchAdSize.height);
  },[]);

  const getAdSizeFilterData = (searchAdSize) => {
    axios(`http://localhost:5000/adSizeMasterList/search?${searchAdSize}`).then((res)=>{
      console.log(res.data)
      // setChannels(res.data)
      setAdSizeList(res.data);
    })
  }

  const getAdSizesData = (BidderId) =>{
    axios(`http://localhost:5000/bidderAdSizes/${BidderId}`).then((res)=>{
      console.log(res.data)
      const BidderAdSizeData=res.data;
      console.log(BidderAdSizeData);

      let keys=[]
      for(let i=0; i<BidderAdSizeData.length ; i++){
          const adSizeMasterListById=BidderAdSizeData[i].adSizeMasterListId;
          console.log(adSizeMasterListById)
          // axios.get(`http://localhost:5000/adSizeMasterList/${adSizeMasterListById}`).then((response)=>{
          //   console.log("data recieved+++++++++++++++++++",response.data);
          //   setsearchAdSizebyid(response.data);
          // })
          keys.push(BidderAdSizeData[i].adSizeMasterListId)
          // Crud.getData(`adSizeMasterList/${adSizeMasterListById}`).then((res)=>{
          //   console.log(res.data);
          // })
          // keys.push(BidderAdSizeData[i].adSizeMasterListId);
      }
      console.log(keys);
      // const keyvalue=keys.toString;
      // console.log(keyvalue);
      axios.get(`http://localhost:5000/adSizeMasterList/${keys}`).then((response)=>{
            console.log("data recieved+++++++++++++++++++",response.data);
            setsearchAdSizebyid(response.data);
      })
    })
  }
  

  const getCountriesData = () =>{
    axios(`http://localhost:5000/country`).then((res)=>{
       setCountries(res.data);
    })
  }
  useEffect(()=>{
    getCountriesData();
  },[]);

  const getData = () => {
    if(id != undefined){
    axios(`http://localhost:5000/hudsonBidder/${id}`).then((res) => {
        setBidder({...res.data});
        let sampleArr = Array.from(res.data.adRequestType)
        setBidder((item) => ({
          ...item,
          adRequestType:sampleArr 
        }))
        
        
        let key=res.data.BidderId;
        getSeatBidderData(key);
        let adsvalue=res.data.BidderId;
        getAdsFilterData(adsvalue); 
        let whiteblacklist=res.data.BidderId;
        getWhiteBlackListData(whiteblacklist);
        let blacklist=res.data.BidderId;
        getBlackListData(blacklist);
        let BidderAdSize=res.data.BidderId;
        if(BidderId != undefined && BidderId != ''){
            getAdSizesData(BidderAdSize);
        }
        if(res.data.channel_choice !=''){
          let getChannelItem = res.data.channel_choice;
          // const filter=getChannelItem.replaceAll(']','');
          // const newfilter=filter.replaceAll('[','');
          // const filteredarray=newfilter.replaceAll('"','');
          console.log(getChannelItem)
          if(getChannelItem == ''){
            setsearchbyid([])
          }else{
          Crud.getData(`channels`,getChannelItem).then((channelRes)=>{
              setsearchbyid(channelRes.data);
              console.log(searchbyid);
          })
        }
        }
        if(res.data.BidderCountryCode !=''){
          let getCountriesItem = res.data.BidderCountryCode;
          //if(getChannelItem ==''){ getChannelItem='00'; }
          console.log(res.data)
          // console.log(getChannelItem.length)
          console.log(getCountriesItem)
          // const countries=getCountriesItem.replaceAll('[','');
          // const cont=countries.replaceAll(']','');
          // const con=cont.replaceAll('"','');
          // console.log(cont);
          // console.log(countries);
          // console.log(con);
          if(getCountriesItem == ''){
            setsearchbyidCountries([]);
          }else{
          Crud.getTableData(`country/${getCountriesItem}`).then((res)=>{
            console.log(res.data)
              setsearchbyidCountries(res.data);
              console.log(searchbyidCountries);
              // setUserInfo(res.data)
          })
        }
        }
    });
  }
  }
  useEffect(() => {
    if(id !=  undefined){
      getData()
    }else {
      console.log("no id found!!!!")
    }
  }, []);

  //Populate Form

  const initialValue={
    BidderIdentifier: "",
    ApproveThisList: "", 
    BlockThisList: "", 
    BidderId: "devtest49",
    BidderCurrency:"USD",
    BidderModel:"CPM",
    tagid:"",
    BidderType:"rtb21",
    BidderPrice: "0",
    BidderAdformat: "video",
    BidderAuctionType: "first_price_auction",
    SecurityType: "protocol_relative_url",
    BidderUrl: "",
    BidderWinUrl: "",
    DailyFreqPerDeviceId: "-1",
    IsVdopiaBidder: "1",
    BidderVdopiaMargin: "50",
    bidRequestCompression: "1",
    IsAppIdEncoding: "1",
    GdprApplicability: "-1",
    DeviceOs: "All",
    BidderPlatform: "site,app",
    EnabledOnDesktop: "0",
    EnabledOnMobile: "0",
    EnabledOnTablet: "0",
    EnabledOnConnectedTV: "0",
    BidderQpsIsUnlimited: "0",
    adRequestType: [],
    // adRequestchannelsrightarray: [],
    DataCenterRegion: "any",
    supply_chain_applicability: "0",
    ClientSideUnwrapping: "1",
    BidderQpsValue: "0",
    cookie_sync_targeting:"0",
    channel_choice: "",
    BidderCountryCode: "",
    adsize: [],
    gps: "no",
    ifa: "no",
    ads_default_domains_select: [],
    adSkippableSelected: "all",
    adDuration: "any",
    adv_id:""
  }

  

  const [createBidder,setBidder]=useState(initialValue);

  useEffect(()=>{
    let adv_id = localStorage.getItem("id");
    setBidder((item) => ({
      ...item,
      adv_id:adv_id 
    }))
  },[])
  console.log(createBidder.adv_id)
    

  console.log(Array.isArray(createBidder.adRequestType))
//Seat_Bidder Table
  const initialSeatBidderValue={
    bidder_id : "",
    seat_id : "",
  }
  // const Bidder=createBidder.BidderId;
  const [seatBidder, setSeatBidder]=useState(initialSeatBidderValue);
  // console.log(BidderId);
  const {bidder_id,seat_id}=seatBidder

//Seat Bidder Table Ends here...

//hudson_bidder_whitelist_blacklist

  const hudson_bidder_whitelist_blacklist={
    bidder_id:"",
    domain: "",
    platform: "site",
    status: "whitelist",
  }

  const [whiteBlackList, setWhiteBlackList]=useState(hudson_bidder_whitelist_blacklist)

  const {domain,platform,status}=whiteBlackList
//hudson_bidder_whitelist_blacklist ends here...

//hudon_bidder_whitelist_blacklist for blocklist

const hudson_bidder_blacklist={
  bidder_id:"",
  domain: "",
  platform: "site",
  status: "blacklist",
}

const [Blacklist, setBlackList]=useState(hudson_bidder_blacklist)

// const {domain,platform,status}=Blacklist

//hudon_bidder_whitelist_blacklist for blocklist

//For Aads_txt_and_seller_filter table

  const initialadsTextFilterValue={
    ads_txt_targeting_id: "",
    targeting_type: "package",
    is_ads_txt_enabled: "0",
    is_seller_enabled: "0",
    ads_txt_domains: "chocolateplatform.com",
    account_type: [],
    viewability_score: null,
    vtr	: null,
    ctr: null,
  }

  const [adsFilter, setAdFilter]=useState(initialadsTextFilterValue);

  const {ads_txt_targeting_id,targeting_type,is_ads_txt_enabled,is_seller_enabled,
        ads_txt_domains,account_type,viewability_score,vtr,ctr}=adsFilter

  

//For Aads_txt_and_seller_filter table



  
  let history = useHistory();
  
  const { BidderIdentifier,
    BidderId,BidderCurrency,BidderModel,
    tagid,BidderType,BidderPrice,BidderAdformat,
    BidderAuctionType,BidderUrl,SecurityType,
    ClientSideUnwrapping,
    BidderWinUrl,DailyFreqPerDeviceId,ApproveThisList, BlockThisList,
    IsVdopiaBidder,BidderVdopiaMargin, bidRequestCompression, IsAppIdEncoding, GdprApplicability,
    DeviceOs,BidderPlatform, EnabledOnDesktop, EnabledOnMobile, EnabledOnTablet ,
    EnabledOnConnectedTV,BidderQpsValue, BidderQpsIsUnlimited,
     adRequestType,
    //  adRequestchannelsrightarray,
      DataCenterRegion, supply_chain_applicability,cookie_sync_targeting,channel_choice,BidderCountryCode,adsize,BidderAdditionalSettings,
      ads_default_domains_select,adSkippableSelected,adDuration} = createBidder;

// error form 
 const [validation, setValidation] = useState({
    BidderIdentifier: '',
    BidderUrl: '',
    BidderQpsValue: '',
    BidderQpsIsUnlimited: '',
    EnabledOnDesktop: '',
    EnabledOnMobile: '',
    EnabledOnTablet: '',
    EnabledOnConnectedTV: '',
    // pack_id:'',
    // auction_price_type: "fixed",
    // price: '',
    // deal_type: "guaranteed",
    // targetimpression: '',
    // start_date:'',
    // end_date: "",
    // onGoing:0,
  });
// error form



  const [checked, setChecked] = useState(false);
  const [checkedvpaid, setCheckedVpaid] = useState(false);
  const [checkedmraid, setCheckedmraid] = useState(false);

  //For Other Filters Fropdown
  const [visibleSkippable, setVisibleSkippable]= useState(false);
  const [visibleAutoplay, setvisibleAutoplay]= useState(false);
  const [visibleadsizedesktop, setAdsizedesktop]= useState(false);
  const [visibleadsizemt, setVisibleadsizemt]=useState(false);
  const [visiblesound, setVisiblesound]=useState(false);
  const [visibleincentivized, setVisibleincentivized]=useState(false);
  const [visibleinstream,setVisibleinstream]=useState(false);
  const [visibleclickable, setVisibleclickable]=useState(false);
  const [visibleintegration, setVisibleintegration]=useState(false);
  const [visibleifa, setVisibleifa]=useState(false);
  const [visiblegpslatlong, setVisiblegpslatlong]=useState(false);
  const [visibleviewability, setVisibleviewability]=useState(false);
  const [visiblevdoadformat, setVisiblevdoadformat]=useState(false);
  const [visibledomainnamebundleid, setVisibledomainnamebundleid]=useState(false);
  const [visibleadunitfilter, setVisibleadunitfilter]=useState(false);
  const [visiblehandleRtb21, setVisiblehandleRtb21]=useState(false);
  const [visibleDealIdTargeting, setVisibleDealIdTargeting]=useState(false);
  const [visibletestRequests, setvisibletestRequests]=useState(false);
  const [handleCountries, sethandleTargetCountries]=useState(false)
  
  const [visiblehandlevpaid, setVisiblevpaid]=useState(false);
  const [visiblehandlemraid, setVisibleMraid]=useState(false);
  const handleClick=(e)=>{
    const otherfiltersvalue=e.target.value;

    if(otherfiltersvalue == "skippable"){
      setVisibleSkippable(true);
    }else if(otherfiltersvalue == "autoplay"){
      setvisibleAutoplay(true);
    }else if(otherfiltersvalue == "adsizedesktop"){
      setAdsizedesktop(true);
    }else if(otherfiltersvalue == "adsizemt"){
      setVisibleadsizemt(true);
    }else if(otherfiltersvalue == "sound"){
      setVisiblesound(true);
    }else if(otherfiltersvalue == "incentivized"){
      setVisibleincentivized(true);
    }else if(otherfiltersvalue == "instream"){
      setVisibleinstream(true);
    }else if(otherfiltersvalue == "clickable"){
      setVisibleclickable(true);
    }else if(otherfiltersvalue == "integration"){
      setVisibleintegration(true);
    }else if(otherfiltersvalue == "ifa"){
      setVisibleifa(true);
    }else if(otherfiltersvalue == "gpslatlong"){
      setVisiblegpslatlong(true);
    }else if(otherfiltersvalue == "viewability"){
      setVisibleviewability(true);
    }else if(otherfiltersvalue == "vdoadformat"){
      setVisiblevdoadformat(true);
    }else if(otherfiltersvalue == "domainnamebundleid"){
      setVisibledomainnamebundleid(true);
    }else if(otherfiltersvalue == "adunitfilter"){
      setVisibleadunitfilter(true);
    }else if(otherfiltersvalue == "others"){
      alert("Please Select An Option")
    }
  }

  const handleTargetCountries=e=>{
    sethandleTargetCountries(true);
  }

  const handleRtb21=e=>{
    setVisiblehandleRtb21(true);
    setVisibleDealIdTargeting(false);
    setvisibletestRequests(false);
    setBidder(({...createBidder,BidderPrice : "0"}));
  }
  
  const handleRtb22=e=>{
    setVisiblehandleRtb21(true);
    setVisibleDealIdTargeting(false);
    setvisibletestRequests(false);
    setBidder(({...createBidder,BidderPrice : "0"}));
  }

  const handleRtb24=e=>{
    setVisiblehandleRtb21(true);
    setVisibleDealIdTargeting(false);
    setvisibletestRequests(true);
    setBidder(({...createBidder,BidderPrice : "0"}));
  }

  const handleVastFixedPrice=e=>{
    setVisiblehandleRtb21(false);
    setVisibleDealIdTargeting(true);
    setvisibletestRequests(false);
  }

  const handleVastVdopiaExtnPrice=e=>{
    setVisiblehandleRtb21(false);
    setVisibleDealIdTargeting(true);
    setvisibletestRequests(false);
    setBidder(({...createBidder,BidderPrice : "0"}));
  }

  const handleVpaidFixedPrice=e=>{
    setVisiblehandleRtb21(false);
    setVisibleDealIdTargeting(true);
    setvisibletestRequests(false);
  }

  const handleVpaidVdopiaExtnPrice=e=>{
    setVisiblehandleRtb21(false);
    setVisibleDealIdTargeting(true);
    setvisibletestRequests(false);
    setBidder(({...createBidder,BidderPrice : "0"}));
  }

  //Publishers Channels


  const handleTableRowSelect=e=>{
    console.log("table data!!!");
  }
  
  const [finaloutput, setFinalOutput]=useState({
    res: []
  });

  //For searching Channels

  const initialvalueforsearch = {name:""}
  const [search,setSearch]=useState(initialvalueforsearch)

  const onInputSearchChange=e=>{
    setSearch(item1=>({name: e.target.value}));
  }

  const onSearchSubmit = e => {
    e.preventDefault();
    let t = search.name
    getChannelsData(t);
    
  }

  //For Searching Channel Ends here...
  const [searchbyid,setsearchbyid]=useState([]);

  var getSelectedKeys=[];
  // console.log(getSelectedKeys)

  const leftCheckboxContainer=(e)=>{ 
    const val=e.target.value
    console.log(val)
    const checked=e.target.checked;
    console.log(checked);
    

    // if(id != undefined){
      const {channelsrightarray}=userinfo;
      // let keys=[]
      // if(searchbyid != undefined){
      //   for (let key in searchbyid){
      //   keys.push(searchbyid[key].id)
      //   }
      // }
      // console.log(keys);

      
      if(checked == true){
            getSelectedKeys.push(val)
      }
      console.log(getSelectedKeys)
      if(checked == false){
        getSelectedKeys.pop(val)
      }
      console.log(getSelectedKeys)
}

function uncheckElements()
{
 var uncheck=document.querySelectorAll('.checkboxRight');
 var uncheck2=document.querySelectorAll('.check11')
 for(var i=0;i<uncheck.length;i++)
 {
   uncheck[i].checked=false;
 }
 for(var i=0;i<uncheck2.length;i++)
 {
  uncheck2[i].checked=false;
 }
}

  const handleOnLeftClick=(e)=>{
    const {channelsrightarray}=userinfo;
    console.log(channelsrightarray);
    uncheckElements()
    console.log(searchbyid)
    if(searchbyid.length == channels.length){
      while (channelsrightarray.length) {
        channelsrightarray.pop();
        console.log(channelsrightarray)
      }
      console.log(channelsrightarray)
      setsearchbyid([]);
    }
    let keys =[]
      if(searchbyid != undefined){
        for (let key in searchbyid){
          keys.push(searchbyid[key].id)
          }
      }
      
    let alteredKeys = keys.join().split(',')
    console.log(alteredKeys)
    console.log(getSelectedKeys)
    console.log(userinfo);
    if(getSelectedKeys == ''){
      setsearchbyid([]);
      setBidder((item) => ({
        ...item,
        channel_choice:getSelectedKeys
      }));
      setUserInfo(({...userinfo,channelsrightarray: getSelectedKeys}))
    }else{
    console.log(getSelectedKeys)
    var filteredKeysFromRightArr = alteredKeys.filter(x => getSelectedKeys.indexOf(x) === -1);
    console.log(filteredKeysFromRightArr)
    console.log(getSelectedKeys)

    console.log(channels.length);
    console.log(userinfo.channelsrightarray.length);

    if(userinfo.channelsrightarray.length == 0 && id == undefined){
      console.log("hoooooiiiiiii")
      console.log(userinfo);
      
    Crud.getTableData(`channels/query/${getSelectedKeys}`).then((res)=>{
     console.log(res)
      const resdata=res.data;
      // console.log(channels)
      if(resdata.length == channels.length){
        console.log(filteredKeysFromRightArr)
        setBidder((item) => ({
          ...item,
          channel_choice:filteredKeysFromRightArr
        }));
        setsearchbyid([]);
      }else{
        setsearchbyid(res.data);
        setBidder((item) => ({
          ...item,
          channel_choice:filteredKeysFromRightArr
        }));
        setUserInfo(({...userinfo,channelsrightarray :filteredKeysFromRightArr}))
      }
    
    })
  }else if(userinfo.channelsrightarray.length == 0 && id != undefined){
    console.log("elseeee");
    console.log(userinfo);
    
      Crud.getTableData(`channels/${filteredKeysFromRightArr}`).then((res)=>{
        console.log(res)
         const resdata=res.data;
         // console.log(channels)
         if(resdata.length == channels.length){
           console.log(filteredKeysFromRightArr)
           setBidder((item) => ({
             ...item,
             channel_choice:filteredKeysFromRightArr
           }));
           setsearchbyid([]);
         }else{
          console.log("mkjiiiiiii")
           setsearchbyid(res.data);
           setBidder((item) => ({
             ...item,
             channel_choice:filteredKeysFromRightArr
           }));
         }
       
       })
    
      
    
    
  }else{
    console.log("lppppppppppppp");
    Crud.getTableData(`channels/${filteredKeysFromRightArr}`).then((res)=>{
      console.log(res)
       const resdata=res.data;
       // console.log(channels)
       if(resdata.length == channels.length){
         console.log(filteredKeysFromRightArr)
         setBidder((item) => ({
           ...item,
           channel_choice:filteredKeysFromRightArr
         }));
         setsearchbyid([]);
       }else{
        console.log("mkjiiiiiii")
         setsearchbyid(res.data);
         setBidder((item) => ({
           ...item,
           channel_choice:filteredKeysFromRightArr
         }));
       }
     
     })
  }
  }
    }

  const RightClickOnHandle=e=>{
    const {channelsleftarray}=userinfo;
    const searchid=userinfo.channelsleftarray;
    console.log(searchid);

    if(id && id >0){
      setUserInfo(({...userinfo,channelsrightarray: channelsleftarray}));
      console.log(userinfo);
      let keys =[]
      if(searchbyid != undefined && searchbyid !=''){
        for (let key in searchbyid){
          keys.push(searchbyid[key].id)
          }
      }
      console.log(keys)
      

      let t = searchid.concat(keys.join().split(','))
      console.log(t)
      
      let unique = t.filter((item, i, ar) => ar.indexOf(item) === i);
      console.log(unique);

      console.log(unique.length);
      console.log(channels.length);

      if(unique.length == channels.length){
          Crud.getTableData(`channels`).then((res)=>{
            console.log(res.data);
            setsearchbyid(res.data);
            setBidder((item) => ({
              ...item,
              channel_choice:unique
            }));
          })
      }else if(unique.length-1 == channels.length){
        console.log("sdddd@@@@")
        Crud.getTableData(`channels`).then((res)=>{
          console.log(res.data);
          setsearchbyid(res.data);
          setBidder((item) => ({
            ...item,
            channel_choice:unique
          }));
        })
      }else{
        console.log("nun!!!")
      Crud.getTableData(`channels/${unique}`).then((chRes)=>{
        setsearchbyid(chRes.data);
        console.log(chRes)
      setBidder((item) => ({
          ...item,
          channel_choice:unique
        }));
        
      })
    }
    }else{
      setUserInfo(({...userinfo,channelsrightarray: channelsleftarray}));
      console.log(userinfo.channelsleftarray.length)
      console.log(channels.length)
      if(userinfo.channelsleftarray.length == channels.length){
        Crud.getTableData(`channels`).then((resp)=>{
          console.log(resp.data);
          setsearchbyid(resp.data);
          setBidder((item) => ({
            ...item,channel_choice: userinfo.channelsleftarray}));
          })
          setUserInfo(({...userinfo,channelsrightarray: channelsleftarray}))
          console.log(createBidder.channel_choice);
      }else{
        Crud.getTableData(`channels/${searchid}`).then((res)=>{
        console.log(res.data);
        setsearchbyid(res.data);
        setBidder((item) => ({
          ...item,channel_choice: userinfo.channelsleftarray}));
    })
    
    }
  }
}

  
  
  
  const onInputChannelChoiceChange=e=>{
    console.log("its just a text area nothing else!!!")
  }

  const rightContainer=e=>{
    const {value, checked}=e.target;
    const {channelsleftarray}=userinfo;
    console.log(`${value} is ${checked}`)
    // console.log(e.target.id)
    //In case the user checks the box
    if(checked){
      setUserInfo(item1=>({
        ...item1,[e.target.id]: [...item1[e.target.id], e.target.value]
    }));
      console.log(userinfo.channelsleftarray);
    }
    else{
      setUserInfo(({...userinfo,channelsleftarray: channelsleftarray.filter((e) => e !== value)}));
      console.log(value+"unselected");
    }
  }

  const handleSelectAll=e=>{
    const checked=e.target.checked;
    console.log(e.target.id)
    // const val=e.target.value;
    // console.log(val);
    const element = document.querySelectorAll('.check12');
    console.log(element);
    const {channelsleftarray}=userinfo;
    
      if(checked){
        let key=[]
        for(var i=0; i< element.length; i++){
          const value=element[i].value;
          key.push(value);
          console.log(value);
          element[i].checked=true;
        }
        console.log(key);
        setUserInfo(({...userinfo,channelsleftarray: key}));
        console.log(userinfo);
      }else{
        // setUserInfo(({...userinfo,channelsleftarray: channelsleftarray.filter((e) => e === value)}));
        console.log(userinfo.channelsleftarray)
        for(var i=0; i<element.length; i++){
          element[i].checked=false;
        }
      }
    
  }

  const handleRightSelectAll=e=>{
    console.log(e.target.value)
    const checked=e.target.checked;
    console.log(checked);
    const val=e.target.value;
    console.log(val)
    const element = document.querySelectorAll('.check11');
    console.log(element);

    if(checked){
      for(var i=0; i<element.length; i++){
        element[i].checked=true;
      }
      // const {channelsrightarray}=userinfo;
      const search=searchbyid
      console.log(search);
      console.log(userinfo);
      let keys=[];
      for(let i=0; i<search.length; i++){
        keys.push(search[i].id)
      }
      console.log(keys);
      setUserInfo(({...userinfo, channelsrightarray: keys}))
      console.log(userinfo.channelsrightarray);

      // const {channelsrightarray}=userinfo;
        
      //   while (channelsrightarray.length) {
      //     channelsrightarray.pop();
      //     console.log(channelsrightarray)
      //   }
      //   console.log(channelsrightarray)

      //   setUserInfo(({...userinfo,channelsrightarray: channelsrightarray}));
      //   console.log(userinfo.channelsrightarray);

        getSelectedKeys.push(keys);
        console.log(keys[0]);
    }
    
      // if(checked){
      //   for(var i=0; i < element.length; i++){
      //     element[i].checked=true;
      //   }
        
      //   const {channelsrightarray}=userinfo;
        
      //   while (channelsrightarray.length) {
      //     channelsrightarray.pop();
      //     console.log(channelsrightarray)
      //   }
      //   console.log(channelsrightarray)

      //   setUserInfo(({...userinfo,channelsrightarray: channelsrightarray}));
      //   console.log(userinfo.channelsrightarray);
        
      // }else{
      //   console.log("do nothing!");
      //   element[i].checked=false;
      //   setUserInfo(item1=>({
      //     ...item1,[e.target.id]: [...item1[e.target.id], val]
      //   }));
      //   console.log(userinfo.channelsrightarray);
      // }
    
  }
  //Publisher Channels ends here......

















  //Ad Size Filter Starts here

  //For AdSize Search

  const initialvalueforAdSizesearch = {height:""}
  const [searchAdSize,setSearchAdSize]=useState(initialvalueforAdSizesearch)

  const onInputSearchAdSizeChange=e=>{
    setSearchAdSize(item1=>({height: e.target.value}));
  }

  const onSearchAdSizeSubmit = e => {
    e.preventDefault();
    let t = searchAdSize.height
    getAdSizeFilterData(t);
  }

  //For Ad Size Search

  const handleAdSizeTableRowSelect=e=>{
    console.log("Table Ad Size Data!!@")
  }


  

  const rightContainerForAdSize=e=>{
    const {value, checked}=e.target;
    const {channelsleftarrayForAdSize}=userinfoAdSizeList;
    console.log(`${value} is ${checked}`)
    if(checked){
      setUserInfoAdSizeList(item1=>({
        ...item1,[e.target.id]: [...item1[e.target.id], e.target.value]
    }));
      console.log(userinfoAdSizeList.channelsleftarrayForAdSize);
    }
    else{
      setUserInfoAdSizeList(({...userinfoAdSizeList,channelsleftarrayForAdSize: channelsleftarrayForAdSize.filter((e) => e !== value)}));
      console.log(value+"unselected");
    }
  }



  const RightClickOnHandleForAdSize=e=>{
    const {channelsleftarrayForAdSize}=userinfoAdSizeList;
    const searchid=userinfoAdSizeList.channelsleftarrayForAdSize;
    if(id && id>0){

      let keys =[]
      if(searchAdSizebyid != undefined && searchAdSizebyid !=''){
        for (let key in searchAdSizebyid){
          keys.push(searchAdSizebyid[key].id)
          }
      }

      let t = searchid.concat(keys.join().split(','))
      
      let unique = t.filter((item, i, ar) => ar.indexOf(item) === i);

      Crud.getTableData(`adSizeMasterList/${unique}`).then((res)=>{
        setsearchAdSizebyid(res.data);
      })
    }else{
      setUserInfoAdSizeList(({...userinfoAdSizeList,channelsrightarrayForAdSize: channelsleftarrayForAdSize}));
      Crud.getTableData(`adSizeMasterList/${searchid}`).then((res)=>{
          setsearchAdSizebyid(res.data);
    })
    }
  }

  function uncheckElementsForAdSize(){
        var uncheck=document.querySelectorAll('.checkboxRightAdSize');
        for(var i=0;i<uncheck.length;i++)
    {
      
      uncheck[i].checked=false;
      
    }
  }

  const [searchAdSizebyid,setsearchAdSizebyid]=useState([]);

  let getSelectedKeysForAdSize=[];

  const leftContainerForAdSize=e=>{
    console.log(e.target.checked);
    const checked=e.target.checked;
    console.log(e.target.value);
    const value=e.target.value;
    const {channelsrightarrayForAdSize}=userinfoAdSizeList;
    let keys=[]
      if(searchAdSizebyid != undefined){
        for (let key in searchAdSizebyid){
          keys.push(searchAdSizebyid[key].id)
        }
      }
      console.log(keys);

      
      if(checked == true){
            getSelectedKeysForAdSize.push(value)
          }
      console.log(getSelectedKeysForAdSize)
      if(checked == false){
        getSelectedKeysForAdSize.pop(value)
      }
      console.log(getSelectedKeysForAdSize)
  }



  const handleOnLeftClickForAdSize=e=>{
    uncheckElementsForAdSize()
    console.log(searchAdSizebyid)
    let keys =[]
      if(searchAdSizebyid != undefined){
        for (let key in searchAdSizebyid){
          keys.push(searchAdSizebyid[key].id)
          }
      }
      
    let alteredKeys = keys.join().split(',')
    console.log(alteredKeys)
    console.log(getSelectedKeysForAdSize)
    var filteredKeysFromRightArr = alteredKeys.filter(x => getSelectedKeysForAdSize.indexOf(x) === -1);
    console.log(filteredKeysFromRightArr);
    if(filteredKeysFromRightArr == ''){
      console.log("jew!")
      setsearchAdSizebyid([]);
    }else{

    Crud.getTableData(`adSizeMasterList/${filteredKeysFromRightArr}`).then((res)=>{
      console.log(res.data);
      setsearchAdSizebyid(res.data);
    })
  }
  }

  let getSelectedKeysCountries=[];

  const leftContainerForCountries=e=>{
    const val=e.target.value
    console.log(val)
    const checked=e.target.checked;
    console.log(checked);
    

    // if(id != undefined){
      const {channelsrightarray}=userinfo;
      // let keys=[]
      // if(searchbyid != undefined){
      //   for (let key in searchbyid){
      //   keys.push(searchbyid[key].id)
      //   }
      // }
      // console.log(keys);

      
      if(checked == true){
            getSelectedKeysCountries.push(val)
          }
      console.log(getSelectedKeys)
      if(checked == false){
        getSelectedKeysCountries.pop(val)
      }
      console.log(getSelectedKeysCountries)
  }

  const LeftClickCountries=e=>{
    const {rightarrayforCountry}=userinfoCountryList;
    console.log(rightarrayforCountry);
    // uncheckElements()
    console.log(searchbyidCountries)
    if(searchbyidCountries.length == countries.length){
      while (rightarrayforCountry.length) {
        rightarrayforCountry.pop();
        console.log(rightarrayforCountry)
      }
      console.log(rightarrayforCountry)
      setsearchbyidCountries([]);
    }
    let keys =[]
      if(searchbyidCountries != undefined){
        for (let key in searchbyidCountries){
          keys.push(searchbyidCountries[key].alpha_2_code)
          }
      }
      
    let alteredKeys = keys.join().split(',')
    console.log(alteredKeys)
    console.log(getSelectedKeysCountries)
    var filteredKeysFromRightArr = alteredKeys.filter(x => getSelectedKeysCountries.indexOf(x) === -1);
    console.log(filteredKeysFromRightArr)

    Crud.getTableData(`country/${filteredKeysFromRightArr}`).then((res)=>{
      const resdata=res.data;
      // console.log(resdata)
      // console.log(channels)
      if(resdata.length == countries.length){
        console.log(filteredKeysFromRightArr)
        setBidder((item) => ({
          ...item,
          BidderCountryCode:filteredKeysFromRightArr
        }));
        setsearchbyidCountries([]);

      }else{
        setsearchbyidCountries(res.data);
        setBidder((item) => ({
          ...item,
          BidderCountryCode:filteredKeysFromRightArr
        }));
      }
    })
  }




  //Ad Size Filter Ends here......

















  //Countries Targeting Starts Here....

  const [searchbyidCountries,setsearchbyidCountries]=useState([]);

  const handleCountryTableRowSelect=e=>{
    console.log("countries data");
  }

  const rightContainerForCountries=e=>{
    const {value, checked}=e.target;
    const {leftarrayforCountry}=userinfoCountryList;
    console.log(`${value} is ${checked}`)
    if(checked){
      setUserInfoCountryList(item1=>({
        ...item1,[e.target.id]: [...item1[e.target.id], e.target.value]
    }));
      console.log(userinfoCountryList.leftarrayforCountry);
    }
    else{
      setUserInfoCountryList(({...userinfoCountryList,leftarrayforCountry: leftarrayforCountry.filter((e) => e !== value)}));
      console.log(value+"unselected");
      console.log(userinfoCountryList);
    }
  }

  const RightClickCountries=e=>{
    const {leftarrayforCountry}=userinfoCountryList;
    const searchid=userinfoCountryList.leftarrayforCountry;
    console.log(searchid);

    if(id && id >0){

      let keys =[]
      if(searchbyidCountries != undefined && searchbyidCountries !=''){
        for (let key in searchbyidCountries){
          keys.push(searchbyidCountries[key].alpha_2_code)
          }
      }
      console.log(keys)
      

      let t = searchid.concat(keys.join().split(','))
      console.log(t)
      
      let unique = t.filter((item, i, ar) => ar.indexOf(item) === i);
      console.log(unique);
      
      Crud.getTableData(`country/${unique}`).then((chRes)=>{
        setsearchbyidCountries(chRes.data);
        console.log(chRes)
      setBidder((item) => ({
          ...item,
          BidderCountryCode:t
        }));
        
      })

    }else{
      setUserInfoCountryList(({...userinfoCountryList,rightarrayforCountry: leftarrayforCountry}));
      console.log(userinfoCountryList.leftarrayforCountry.length)
      console.log(countries.length)
      if(userinfoCountryList.leftarrayforCountry.length == countries.length){
        Crud.getTableData(`country_codes`).then((resp)=>{
          console.log(resp.data);
          setsearchbyidCountries(resp.data);
          setBidder((item) => ({
                ...item,
                BidderCountryCode: userinfoCountryList.leftarrayforCountry
              }));
              console.log(createBidder)
          setBidder((item) => ({
            ...item,BidderCountryCode: userinfoCountryList.leftarrayforCountry}));
          })
      }else{
        Crud.getTableData(`country/${searchid}`).then((res)=>{
          console.log(res.data);
          setsearchbyidCountries(res.data);
          console.log(userinfoCountryList.leftarrayforCountry);
          setBidder((item) => ({
            ...item,BidderCountryCode: userinfoCountryList.leftarrayforCountry}));
          
    })
    // console.log(channel_choice)
    console.log(userinfoCountryList);
    }
  }
  }


  

  //Countries Targeting Ends Here...














  //For Handle Approve Pop Up
  const initialapprovevalue={domain : "", status: "whitelist", platform: ""}

  const [user,setUser]=useState(initialapprovevalue)

  const handleApprove=(ApproveData)=>{
    console.log(ApproveData);
    setUser(ApproveData);
    handleApproveShow();
  }


  const onApproveInputChange=e=>{
    console.log(e.target.name)
    console.log(e.target.value)
    setWhiteBlackList({ ...whiteBlackList, [e.target.name]: e.target.value });
    console.log(whiteBlackList);
  }

  // const onInputPlatformChange=e=>{

  // }


  const onApproveSubmit=e=>{
    e.preventDefault();
    
    handleApproveClose();
  }

  const [showApprove, setShowApprove]=useState(false)

  const handleApproveClose= () =>setShowApprove(false);
  const handleApproveShow= () =>setShowApprove(true);

  //END: For Handle Approve Pop Up

  //For HandleBlock Pop Up
  const initialblockvalue={domain: "", status: "blacklist"}

  const [blockeduser, setBlockedUser]=useState(initialblockvalue)

  const handleBlock=(BlockedData)=>{
    setBlockedUser(BlockedData)
    handleBlockShow();
  }

  const onBlockedInputChange=e=>{
    console.log(e.target.name)
    console.log(e.target.value)
    // setBlockedUser({ ...blockeduser, [e.target.name]: e.target.value });
    // console.log(blockeduser);
    setBlackList({ ...Blacklist, [e.target.name]: e.target.value });
    console.log(Blacklist);
  }

  const onBlockedSubmit=e=>{
    e.preventDefault();
    handleBlockClose();
  }

  const [showBlock, setShowBlock]=useState(false)

  const handleBlockClose =()=>setShowBlock(false);
  const handleBlockShow=()=>setShowBlock(true);

  //END For Handle Block Pop Up

  const handleClickClose=e=>{
    setVisibleSkippable(false);
  }

  const handleAutoPlayClose=e=>{
    setvisibleAutoplay(false)
  }

  const handleClickAdSizeDesktopClose=e=>{
    setAdsizedesktop(false)
  }

  const handleClickAdSizeMTClose=e=>{
    setVisibleadsizemt(false)
  }

  const handleSoundClose=e=>{
    setVisiblesound(false)
  }
  
  const handleIncentivizedClose=e=>{
    setVisibleincentivized(false)
  }

  const handleInstreamClose=e=>{
    setVisibleinstream(false)
  }

  const handleClickableClose=e=>{
    setVisibleclickable(false)
  }

  const handleClickIntegrationClose=e=>{
    setVisibleintegration(false)
  }

  const handleIfaClose=e=>{
    setVisibleifa(false)
  }
  const handleGpsLatLongClose=e=>{
    setVisiblegpslatlong(false)
  }
  const handleViewAbilityClose=e=>{
    setVisibleviewability(false)
  }
  const handleClickVdoAdFormatClose=e=>{
    setVisiblevdoadformat(false)
  }
  const handleDomainBundleClose=e=>{
    setVisibledomainnamebundleid(false)
  }
  const handleClickAdUnitFilterClose=e=>{
    setVisibleadunitfilter(false)
  }
//For Other Filters Fropdown
  
  //For Seat Bidder Table
  
  const getSeatBidderData = (Bidder) => {
    // let Bidder="1BGhkQ
    axios(`http://localhost:5000/seat_bidder/${Bidder}`).then((res) => {
        // setSeatBidder(res.data);
        setSeatBidder({...res.data});
    });
  }
  useEffect(() => {
    getData()
  }, []);

  

  const onInputSeatBidderChange = e => {
    setSeatBidder({ ...seatBidder, [e.target.name]: e.target.value });
    };

  const StyledTableCell = styled(TableCell)(({ theme }) => ({
      [`&.${tableCellClasses.head}`]: {
        backgroundColor: '#21364e',
        color: theme.palette.common.white,
        fontSize: 15,
        height: 0,
      },
      [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
      },
    }));
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
      '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
      },
      '&:last-child td, &:last-child th': {
        border: 0,
        height: 0,
      },
    }));
  
  //For Seat Bidder Table

  //For hudson_bidder_whitelist_blacklist

  const getWhiteBlackListData = (Bidder) => {
    axios(`http://localhost:5000/hudson_bidder_whitelist_blacklist/${Bidder}`).then((res) => {
        setWhiteBlackList({...res.data});
        // setBlackList({...res.data});
        // setWhiteBlackList(res.data);
        console.log(res.data);
             
    });
  }

  const getBlackListData=(Bidder) => {
    axios(`http://localhost:5000/hudson_bidder_whitelist_blacklist/blacklist/${Bidder}`).then((res) => {
        // setWhiteBlackList({...res.data});
        setBlackList({...res.data});
        // setWhiteBlackList(res.data);
        console.log(res.data);
             
    });
  }

  const onInputWhiteBlackList = e => {
    setWhiteBlackList({ ...whiteBlackList, [e.target.name]: e.target.value });
  };

  const onInputBlackList=e=>{
    setBlackList({...Blacklist, [e.target.name]: e.target.value })
  }
  

  //for hudson_bidder_whitelist_blacklist ends here...
  
  //For Ads_txt_and_seller_filter table
  
  const getAdsFilterData = (Ads) => {
    axios(`http://localhost:5000/ads_txt_and_seller_filter/${Ads}`).then((res) => {
        setAdFilter({...res.data});
        // setAdFilter(res.data);
        let sampleArr = Array.from(res.data.account_type)
        setAdFilter((item) => ({
          ...item,
          account_type:sampleArr 
        }))
        console.log(Array.isArray(sampleArr));
        console.log(sampleArr);
    });
  }
  useEffect(() => {
    getData()
  }, []);

  const onInputAdFilterChange =e=>{
    setAdFilter({ ...adsFilter, [e.target.name]: e.target.value});
  }

  //For Ads_txt_and_seller_filter table ends here....


    
    const onInputChange = e => {
      console.log(e.target.name);
      console.log(e.target.value);
      setBidder(item1=>({...item1,[e.target.name]: e.target.value }));
    };

    const onInputChangeBidderQpsValue = e => {
      // if(e.target.name == 'BidderQpsValue'){
      //   let errors = [] 
      //     if(e.target.value < 0 || e.target.value == 0){
      //       errors.BidderQpsValue = "Maximum Bid Requests/Second should be a positive integer.";
      //     }
      //     setValidation(errors);
      // }else{
      setBidder(item1=>({...item1,[e.target.name]: e.target.value }));
      // }
    };

  const onInputChangeCheck = e => {
    const { value, checked } = e.target;
    console.log(value);
    console.log(checked);
    if(checked){
        setBidder({ ...createBidder, [e.target.name]: e.target.value });
        console.log(createBidder.EnabledOnDesktop);
    }else{
      
        setBidder(item1=>({
          ...item1,EnabledOnDesktop: ("0")
      }));
      console.log(createBidder.EnabledOnDesktop);
    }
}

  const onInputAccountTypeCheck=e=>{
    const { value, checked } = e.target;
    console.log(value);
    console.log(checked);
    console.log(e.target.name);
    // if(checked){
    //     setAdFilter({ ...adsFilter, [e.target.name]: e.target.value });
    // }else{
    //     setAdFilter(item1=>({
    //       ...item1,account_type: (!value)
    //   }));
    // }
    if(checked){
      setAdFilter(item1=>({
          ...item1,[e.target.name]: [...item1[e.target.name], e.target.value]
      }));
    }else{
      setAdFilter(item1=>({
          ...item1,account_type: account_type.filter((e) => e !== value)
      }));
  }
  }

const onInputChangeMobile=e=>{
  const {value,checked}=e.target;
  if(checked){
    setBidder({ ...createBidder, [e.target.name]: e.target.value });
  }else{
    setBidder(item1=>({
      ...item1,EnabledOnMobile: ("0")
  }));
  }
}

const onInputChangeTablet=e=>{
  const {value,checked}=e.target;
  if(checked){
    setBidder({ ...createBidder, [e.target.name]: e.target.value });
  }else{
    setBidder(item1=>({
      ...item1,EnabledOnTablet: ("0")
  }));
  }
}

const onInputBidderQpsUnlimited=e=>{
  
  const {value,checked}=e.target;
  if(checked){
    setBidder({ ...createBidder, [e.target.name]: e.target.value });
    // setBidder({ ...createBidder, BidderQpsValue : null})
    setBidder(item1=>({
      ...item1,BidderQpsValue: ("0")
    }));
  }else{
    setBidder(item1=>({
      ...item1,BidderQpsIsUnlimited: ("0")
  }));
  }
}

const onInputChangeConnectedtv=e=>{

  const {value,checked}=e.target;
  if(checked){
    setBidder({ ...createBidder, [e.target.name]: e.target.value });
  }else{
    setBidder(item1=>({
      ...item1,EnabledOnConnectedTV: ("0")
  }));
  }
}

const onInputClientSideWrappingChangeCheck=e=>{
  const {value,checked}=e.target;
  console.log(value)
  console.log(checked)
  if(checked){
    setBidder({ ...createBidder, [e.target.name]: e.target.value });
  }else{
    setBidder(item1=>({
      ...item1,ClientSideUnwrapping: ("0")
  }));
  }
}

const onInputAdsTxtEnabled=e=>{
  const {value,checked}=e.target;
  console.log(value)
  console.log(checked)
  if(checked){
    setAdFilter({ ...adsFilter, [e.target.name]: e.target.value });
    onInputIsSellerenabled(e);
  }else{
    setAdFilter(item1=>({
      ...item1,is_ads_txt_enabled: ("0")
  }));
  onInputIsSellerenabled(e);
  }
}

const onInputIsSellerenabled=e=>{
  const {value,checked}=e.target;
  console.log(value)
  console.log(checked)
  if(checked){
    setAdFilter({ ...adsFilter, [e.target.name]: e.target.value });
  }else{
    setAdFilter(item1=>({
      ...item1,is_seller_enabled: ("0")
  }));
  }
}


const handleChangeAdRequestType=e=>{
  console.log(e.target.name);
  console.log(e.target.value);
  const { value, checked } = e.target;
        if(checked){
            setBidder(item1=>({
                ...item1,[e.target.name]: [...item1[e.target.name], e.target.value]
            }));
        }else{
            setBidder(item1=>({
                ...item1,adRequestType: adRequestType.filter((e) => e !== value)
            }));
        }
}


const onInputChangeAdsize=e=>{
  console.log(e.target.name);
  console.log(e.target.value);
  const { value, checked } = e.target;
        if(checked){
            setBidder(item1=>({
                ...item1,[e.target.name]: [...item1[e.target.name], e.target.value]
            }));
        }else{
            setBidder(item1=>({
                ...item1,adsize: adsize.filter((e) => e !== value)
            }));
        }
}

const onInputChangeAdsTxtDomain = e =>{
  const { value, checked } = e.target;
  if(checked){
      setBidder(item1=>({
          ...item1,[e.target.name]: [...item1[e.target.name], e.target.value]
      }));
      
  }else{
      setBidder(item1=>({
          ...item1,ads_default_domains_select: ads_default_domains_select.filter((e) => e !== value)
      }));
  }
}

const onSubmit = e => {
        let unique=[];
        for(let i=0;i<searchAdSizebyid.length;i++){
          const list=searchAdSizebyid[i].id
          unique.push(list);
        }
        e.preventDefault();
        console.log(createBidder);
        console.log(validation);

        let errors = [];

        if (createBidder.BidderIdentifier=='') {
          errors.BidderIdentifier = "*Please provide Connection Identifier";
          toast.error("Please provide Connection Identifier",{
             position: "top-right",
            autoClose: 4000,
            autoClose: 5000,
             hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
             progress: undefined,
             })
        }

        if (createBidder.BidderUrl==''){
          errors.BidderUrl = "*Please provide Bid Request URL";
          toast.error("Please provide Bid Request URL",{
             position: "top-right",
            autoClose: 4000,
            autoClose: 5000,
             hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
             progress: undefined,
             })
        }

        if(createBidder.BidderQpsIsUnlimited == 0){
          if(createBidder.BidderQpsValue <= 0){
            errors.BidderQpsValue = "*Maximum Bid Requests/Second should be a positive integer.";
            toast.error("Maximum Bid Requests/Second should be a positive integer.",{
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: false,
              draggable: true,
              progress: undefined,
              })
          }
        }

        if(createBidder.EnabledOnDesktop == 0 && createBidder.EnabledOnMobile == 0 && createBidder.EnabledOnTablet == 0 && createBidder.EnabledOnConnectedTV == 0){
          errors.EnabledOnDesktop = "*At-least one of the Device type must be selected."
          errors.EnabledOnMobile = "*At-least one of the Device type must be selected."
          errors.EnabledOnTablet = "*At-least one of the Device type must be selected."
          errors.EnabledOnConnectedTV = "*At-least one of the Device type must be selected."
          toast.error("At-least one of the Device type must be selected.",{
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            })
        }

        setValidation(errors);
      
        console.log(Object.values(errors));
        console.log(Object.values(errors).length);

        if(Object.values(errors).length == ''){
          console.log("no error found")

        if(id !=  undefined ){
            console.log(createBidder.channel_choice);
            Crud.update(`hudsonBidder/${id}`, createBidder)
            .then(()=>{console.log(createBidder) 
            toast.success("Bidder Updated !",{
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: false,
                draggable: true,
                progress: undefined,
                });}) 
            axios.put(`http://localhost:5000/seat_bidder/${seat_id}`, seatBidder)
                .then(()=>{console.log(seatBidder)})
            axios.put(`http://localhost:5000/ads_txt_and_seller_filter/${ads_txt_targeting_id}`, adsFilter)
                .then(()=>{console.log(adsFilter)})
            axios.put(`http://localhost:5000/hudson_bidder_whitelist_blacklist/${bidder_id}`,whiteBlackList)
            axios.put(`http://localhost:5000/hudson_bidder_whitelist_blacklist/blacklist/${bidder_id}`,Blacklist)
            Crud.create(`bidderAdSizes/delete`,{createBidder});
            Crud.create(`bidderAdSizes/update`,{createBidder,unique});
        }else{
              console.log(createBidder.channel_choice);
              console.log(userinfoAdSizeList.channelsleftarrayForAdSize);
              const adSizeData=userinfoAdSizeList.channelsleftarrayForAdSize;
              // console.log(getSelectedKeysForAdRequestType);
              // setBidder({...createBidder,adRequestType: getSelectedKeysForAdRequestType})
              
              if(createBidder.channel_choice == undefined){
                alert("enter a value for publisher channels")
              }else{
              axios.post(`http://localhost:5000/hudsonBidder`, createBidder)
                .then(()=>{console.log(createBidder) 
              toast.success("Bidder Added !",{
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: false,
              draggable: true,
              progress: undefined,
            });})
            Crud.create(`bidderAdSizes`,{createBidder,adSizeData});
            Crud.create(`seat_bidder`,{createBidder,seat_id});
            Crud.create(`ads_txt_and_seller_filter`,{createBidder,adsFilter})
            Crud.create(`hudson_bidder_whitelist_blacklist`,{createBidder,whiteBlackList})
            Crud.create(`hudson_bidder_whitelist_blacklist/blacklist`,{createBidder,Blacklist})
          }
          
        }
      }
  };

  return (
    <><div>
      <div align="left" className={styles.container}>
        <h4>Create Connection {id}</h4>
      </div>
      <div className="container-fluid">
        {/* Connection Details */}
        <div className="row">
          <div className="col-md-12">
            <Form onSubmit={e => onSubmit(e)}>
              <div>
                <fieldset 
                // className="toggleAble"
                >
                  <legend>Connection Details</legend>

                  <Form.Group className="row">
                    <label className="col-sm-3 col-form-label text-right">
                      Connection ID
                    </label>
                    <div className="col-sm-9">

                      <p
                        className="mt-1"
                        // onChange={e => onInputBidderIdChange(e)}
                      >{createBidder.BidderId || ""}</p>
                    </div>
                  </Form.Group>

                  <Form.Group className="row">
                    <label className="col-sm-3 col-form-label text-right">
                      Currency
                    </label>
                    <div className="col-sm-9">
                      <p className="mt-1">
                        {createBidder.BidderCurrency || "USD"}
                      </p>
                    </div>
                  </Form.Group>

                  <Form.Group className="row">
                    <label className="col-sm-3 col-form-label text-right">
                      Pricing Units
                    </label>
                    <div className="col-sm-9">
                      <p className="mt-1">{createBidder.BidderModel || "CPM"}</p>
                    </div>
                  </Form.Group>

                  <Form.Group className="row">
                    <label className="col-sm-3 col-form-label text-right">
                      Connection Identifier
                    </label>
                    <div className="col-sm-4">
                      <Form.Control
                        className="form-control customInput"
                        type="text"
                        name="BidderIdentifier"
                        value={createBidder.BidderIdentifier || ""}
                        onChange={e => onInputChange(e)} 
                        />
                        <p className='formErrors'>{validation.BidderIdentifier}</p> 
                    </div>
                  </Form.Group>

                  <Form.Group className="row mb-3">
                    <label className="col-sm-3 col-form-label text-right">
                      Seat
                    </label>
                    <div className="col-sm-4">
                    <Form.Control
                        className="form-control customTextarea"
                        placeholder="Seat ID is Optional"
                        type="text"
                        as="textarea"
                        name="seat_id"
                        value={seatBidder.seat_id || ""}
                        onChange={(e) => onInputSeatBidderChange(e)}
                        rows="4"
                        row={3}
                      />
                      {/* <textarea
                        name="seat_id"
                        className="form-control customTextarea"
                        value={seat_id || ""}
                        onChange={e=> onInputSeatBidderChange(e)}
                        rows="4"
                      ></textarea> */}
                    </div>
                  </Form.Group>

                  <Form.Group className="row">
                    <label className="col-sm-3 col-form-label text-right">
                      Tag Id
                    </label>
                    <div className="col-sm-4">
                      <Form.Control
                        className="form-control customInput"
                        type="text"
                        name="tagid"
                        value={createBidder.tagid || ""}
                        onChange={e => onInputChange(e)} />
                    </div>
                  </Form.Group>
                </fieldset>
              </div>


              {/* Connection Details */}

              {/* Ad Request Setup  */}
              <div className="row mt-4">
                <div className="col-md-12">

                  <div>
                    <fieldset>
                      <legend>Ad Request Setup</legend>

                      <Form.Group className="row">
                        <label className="col-sm-3 col-form-label text-right">
                          Connection Type
                        </label>

                        <div className="col text-left">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderType"
                                value="rtb21"
                                checked={createBidder.BidderType == "rtb21"}
                                onChange={e => onInputChange(e)}
                                onClick={handleRtb21} />
                              OpenRTB 2.1
                              <i className="input-helper"></i>
                            </label>
                          </div>

                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderType"
                                value="rtb22"
                                checked={createBidder.BidderType == "rtb22"}
                                onChange={e => onInputChange(e)}
                                onClick={handleRtb22} />
                              OpenRTB 2.2
                              <i className="input-helper"></i>
                            </label>
                          </div>

                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderType"
                                value="rtb24"
                                checked={createBidder.BidderType == "rtb24"}
                                onChange={e => onInputChange(e)}
                                onClick={handleRtb24} />
                              OpenRTB 2.4
                              <i className="input-helper"></i>
                            </label>
                          </div>

                          <div className="row">
                            <div className="col-md-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="BidderType"
                                    value="vast_fixed_price"
                                    checked={createBidder.BidderType == "vast_fixed_price"}
                                    onChange={e => onInputChange(e)}
                                    onClick={handleVastFixedPrice}
                                     />
                                  VAST Fixed Price
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-md-8">
                              <div className="row">
                                <div className="col-md-3 text-right mt-1">
                                  <p>Price (in CPM):</p>
                                </div>
                                <div className="col-md-4">
                                  <Form.Group>
                                    <div className="input-group">
                                      <Form.Control
                                        type="text"
                                        className="form-control customInput"
                                        placeholder="5.00"
                                        name="BidderPrice"
                                        value={createBidder.BidderPrice || ""}
                                        disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24' || createBidder.BidderType=='vast_vdopia_extn_price' || createBidder.BidderType=='vpaid_fixed_price' || createBidder.BidderType=='vpaid_vdopia_extn_price'}
                                        onChange={e => onInputChange(e)} />
                                      <div className="input-group-prepend">
                                        <span
                                          style={{
                                            borderRadius: "0px 5px 5px 0px",
                                          }}
                                          className="input-group-text"
                                        >
                                          $
                                        </span>
                                      </div>
                                    </div>
                                  </Form.Group>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderType"
                                value="vast_vdopia_extn_price"
                                checked={createBidder.BidderType == "vast_vdopia_extn_price"}
                                onChange={e => onInputChange(e)} 
                                onClick={handleVastVdopiaExtnPrice}/>
                              VAST with Vdopia Extension Price
                              <i className="input-helper"></i>
                            </label>
                          </div>

                          <div className="row">
                            <div className="col-md-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="BidderType"
                                    value="vpaid_fixed_price"
                                    checked={createBidder.BidderType == "vpaid_fixed_price"}
                                    onChange={e => onInputChange(e)}
                                    onClick={handleVpaidFixedPrice} />
                                  VPAID Fixed Price
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-md-8">
                              <div className="row">
                                <div className="col-md-3 text-right mt-1">
                                  <p>Price (in CPM):</p>
                                </div>
                                <div className="col-md-4">
                                  <Form.Group>
                                    <div className="input-group">
                                      <Form.Control
                                        type="text"
                                        className="form-control customInput"
                                        placeholder="5.00"
                                        name="BidderPrice"
                                        value={createBidder.BidderPrice || ""}
                                        onChange={e => onInputChange(e)}
                                        disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24' || createBidder.BidderType=='vast_vdopia_extn_price' || createBidder.BidderType=='vast_fixed_price' || createBidder.BidderType=='vpaid_vdopia_extn_price'}
                                         />
                                      <div className="input-group-prepend">
                                        <span
                                          style={{
                                            borderRadius: "0px 5px 5px 0px",
                                          }}
                                          className="input-group-text"
                                        >
                                          $
                                        </span>
                                      </div>
                                    </div>
                                  </Form.Group>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderType"
                                value="vpaid_vdopia_extn_price"
                                checked={createBidder.BidderType == "vpaid_vdopia_extn_price"}
                                onChange={e => onInputChange(e)}
                                onClick={handleVpaidVdopiaExtnPrice} />
                              VAST with Vdopia Extension Price
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                      </Form.Group>
                    
                    {  visiblehandleRtb21 &&
                      <Form.Group className="row">
                        <label className="col-sm-3 col-form-label text-right">
                          Ad Format
                        </label>

                        <div className="col-sm-1">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderAdformat"
                                value="video"
                                checked={createBidder.BidderAdformat == "video"}
                                onChange={e => onInputChange(e)} />
                              Video
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>

                        <div className="col-sm-1">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderAdformat"
                                value="bannerNinterstitial"
                                checked={createBidder.BidderAdformat == "bannerNinterstitial"}
                                onChange={e => onInputChange(e)} />
                              Banner/Interstitial
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                      </Form.Group>
                    }
                    { visibletestRequests &&
                      <Form.Group className="row">
                        <label className="col-sm-3 col-form-label text-right"></label>
                        <div className="col">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input type="checkbox"
                                className="form-check-input"
                                // onChange={e => onInputClientSideWrappingChangeCheck(e)}
                                name="ClientSideUnwrapping"
                                value="1"
                                // checked={createBidder.ClientSideUnwrapping ? true : ""} 
                                />
                              <i className="input-helper"></i>
                              Test Requests
                            </label>
                          </div>
                        </div>
                      </Form.Group>
                    } 
                      <Form.Group className="row">
                        <label className="col-sm-3 col-form-label text-right">
                          Auction Type
                        </label>

                        <div className="col-sm-2">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderAuctionType"
                                value="first_price_auction"
                                checked={createBidder.BidderAuctionType == "first_price_auction"}
                                onChange={e => onInputChange(e)}
                                disabled={createBidder.BidderType=='vast_vdopia_extn_price' || createBidder.BidderType=='vast_fixed_price' || createBidder.BidderType=='vpaid_vdopia_extn_price' || createBidder.BidderType=='vpaid_fixed_price'} />
                              First Price Auction
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>

                        <div className="col-sm-3-text-right">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderAuctionType"
                                value="second_price_auction"
                                checked={createBidder.BidderAuctionType == "second_price_auction"}
                                onChange={e => onInputChange(e)}
                                disabled={createBidder.BidderType=='vast_vdopia_extn_price' || createBidder.BidderType=='vast_fixed_price' || createBidder.BidderType=='vpaid_vdopia_extn_price' || createBidder.BidderType=='vpaid_fixed_price'} />
                              Second Price Auction
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>

                        <div className="col-sm-4">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="BidderAuctionType"
                                value="both"
                                checked={createBidder.BidderAuctionType == "both"}
                                onChange={e => onInputChange(e)} 
                                disabled={createBidder.BidderType=='vast_vdopia_extn_price' || createBidder.BidderType=='vast_fixed_price' || createBidder.BidderType=='vpaid_vdopia_extn_price' || createBidder.BidderType=='vpaid_fixed_price'}/>
                              Both
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                      </Form.Group>

                      <Form.Group className="row mb-3">
                        <label className="col-sm-3 col-form-label text-right">
                          Bid Request URL
                        </label>
                        <div className="col-sm-7">
                          <textarea
                            className="form-control customTextarea"
                            rows="2"
                            name="BidderUrl"
                            value={createBidder.BidderUrl || ""}
                            onChange={e => onInputChange(e)}
                          ></textarea>
                          <p className='formErrors'>{validation.BidderUrl}</p>
                        </div>
                        
                      </Form.Group>
                      <Form.Group className="row">
                        <label className="col-sm-3 col-form-label text-right">
                          Security Type
                        </label>

                        <div className="col-sm-2">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="SecurityType"
                                value="protocol_relative_url"
                                checked={createBidder.SecurityType == "protocol_relative_url"}
                                onChange={e => onInputChange(e)} />{" "}
                             
                              Secure Only URL
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>

                        <div className="col-sm-2-text-left">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="SecurityType"
                                value="secure_only_url"
                                checked={createBidder.SecurityType == "secure_only_url"}
                                onChange={e => onInputChange(e)} />
                               Protocol Relative URL
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>

                        <div className="col-sm-4">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="SecurityType"
                                value="non_secure_only_url"
                                checked={createBidder.SecurityType == "non_secure_only_url"}
                                onChange={e => onInputChange(e)} />
                              Non-Secure Only URL
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </div>
                      </Form.Group>

                      <Form.Group className="row">
                        <label className="col-sm-3 col-form-label text-right"></label>
                        <div className="col">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input type="checkbox"
                                className="form-check-input"
                                onChange={e => onInputClientSideWrappingChangeCheck(e)}
                                name="ClientSideUnwrapping"
                                value="1"
                                checked={createBidder.ClientSideUnwrapping ? true : ""} 
                                />
                              <i className="input-helper"></i>
                              This is a client side unwrapping VAST Tag
                            </label>
                          </div>
                        </div>
                      </Form.Group>

                      <Form.Group className="row">
                        <label className="col-sm-3 col-form-label text-right">
                          Win Notice URL
                        </label>
                        <div className="col-sm-7">
                          <Form.Control
                            className="form-control customInput"
                            type="text"
                            name="BidderWinUrl"
                            value={createBidder.BidderWinUrl || ""}
                            onChange={e => onInputChange(e)}
                            />
                        </div>
                      </Form.Group>

                      <Form.Group className="row">
                        <label className="col-sm-3 col-form-label text-right">
                          Frequency Cap (Device ID Level) VAST Only
                        </label>

                        <div className="col text-left">
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="DailyFreqPerDeviceId"
                                value="-1"
                                checked={createBidder.DailyFreqPerDeviceId == "-1"}
                                onChange={(e)=>onInputChange(e)}
                                disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24'}
                                />
                              None
                              <i className="input-helper"></i>
                            </label>
                          </div>

                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="DailyFreqPerDeviceId"
                                value="1"
                                checked={createBidder.DailyFreqPerDeviceId == "1"}
                                onChange={(e)=>onInputChange(e)}
                                disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24'}
                                />
                              1 per unique device ID per day
                              <i className="input-helper"></i>
                            </label>
                          </div>
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="DailyFreqPerDeviceId"
                                value="2"
                                checked={createBidder.DailyFreqPerDeviceId == "2"}
                                onChange={(e)=>onInputChange(e)}
                                disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24'}
                                />
                              3 per unique device ID per day
                              <i className="input-helper"></i>
                            </label>
                          </div>
                          <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="DailyFreqPerDeviceId"
                                value="3"
                                checked={createBidder.DailyFreqPerDeviceId =="3"}
                                onChange={(e)=>onInputChange(e)}
                                disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24'}
                                 />
                              5 per unique device ID per day
                              <i className="input-helper"></i>
                            </label>
                          </div>
                          {/* <div className="form-check">
                            <label className="form-check-label">
                              <input
                                type="radio"
                                className="form-check-input"
                                name="DailyFreqPerDeviceId"
                                value="4"
                                checked={createBidder.DailyFreqPerDeviceId == "4"}
                                disabled={createBidder.BidderType=='rtb21' || createBidder.BidderType=='rtb22' || createBidder.BidderType=='rtb24'}
                                />
                              5 per unique device ID per day
                              <i className="input-helper"></i>
                            </label>
                          </div> */}
                        </div>
                      </Form.Group>
                      { visibleDealIdTargeting &&
                      <Form.Group className="row">
                        <label className="col-sm-2 col-form-label text-right">
                          Deal ID Targeting
                        </label>
                        <div className="col-sm-7">
                          <Form.Control
                            className="form-control customInput"
                            type="text" />
                        </div>
                      </Form.Group>
                    }
                    </fieldset>
                    <br />
                    <div>
                    <fieldset>
                            <legend>Performance Metrics</legend>
                            <Form.Group className="row">
                                <label className="col-sm-3 col-form-label text-right"> Viewability Score</label>
                                <div className="col-sm-3">
                                    <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        name="viewability_score"
                                        value={adsFilter.viewability_score || ""}
                                        onChange={e => onInputAdFilterChange(e)}
                                    />
                                </div>
                                <div className='col-sm-3' align='left'>
                                [Range 0 to 1]
                                </div>
                            </Form.Group>
                            <Form.Group className="row">
                                <label className="col-sm-3 col-form-label text-right"> Video Completetion Rate</label>
                                <div className="col-sm-3">
                                    <input
                                        className="form-control customInput"
                                        type="text"
                                        name="vtr"
                                        value={adsFilter.vtr || ""}
                                        onChange={e => onInputAdFilterChange(e)}
                                    />
                                    {/* <div className="controls min-controls" style={{color: "#49afcd" ,fontSize: "13px"}}>
                                        <b>Note: </b>This performance metrics will be applicable for video inventory only
                                    </div> */}
                                     </div>
                                     <div className="col-sm-3">[Range 0 to 1]</div>
                                    
                               
                                
                                
                            </Form.Group>
                            
                            <Form.Group className="row">
                                <label className="col-sm-3 col-form-label text-right"> Click Through Rate</label>
                                <div className="col-sm-3">
                                    <Form.Control
                                        className="form-control customInput"
                                        type="text"
                                        name="ctr"
                                        value={adsFilter.ctr || ""}
                                        onChange={e => onInputAdFilterChange(e)}
                                    />
                                </div>
                                <div className='col-sm-3' align='left'>
                                [Range 0 to 1]
                                </div>
                            </Form.Group>
                        </fieldset>
                    </div>
                    <div>
                      <fieldset>
                        <legend>Ads.Txt and Seller Filter</legend>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Ads.Txt Domains
                          </label>
                          <div className="col-sm-4">
                            <Form.Control
                              className="form-control customInput"
                              type="text"
                              name="ads_txt_domains"
                              value={adsFilter.ads_txt_domains || ""}
                              onChange={e=>onInputAdFilterChange(e)}
                               />
                          </div>
                          <div className="col">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                onChange={e => onInputChangeAdsTxtDomain(e)}
                                name="ads_default_domains_select"
                                value="true"
                                checked={Array.isArray(createBidder.ads_default_domains_select ) && createBidder.ads_default_domains_select?.find(item => item == "true") ? true : ""}
                                />
                                <i className="input-helper"></i>
                                Selected
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            AdsTxt
                          </label>
                          <div className="col">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                value="1"
                                onChange={e => onInputAdsTxtEnabled(e)}
                                name="is_ads_txt_enabled"
                                checked={adsFilter.is_ads_txt_enabled == "1" ? true : "" }
                                />
                                <i className="input-helper"></i>
                                Ads.txt enabled for selected domain(s)
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Seller Enabled
                          </label>
                          <div className="col">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                disabled
                                value="1"
                                onChange={e => onInputIsSellerenabled(e)}
                                name="is_seller_enabled"
                                checked={adsFilter.is_seller_enabled == "1" ? true : "" }
                                />
                                <i className="input-helper"></i>
                                Seller enabled for selected domain(s)
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Account Type
                          </label>
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                value="RESELLER"
                                onChange={e=> onInputAccountTypeCheck(e)}
                                name="account_type"
                                // checked={adsFilter.account_type == "RESELLER" ? true : "" } 
                                checked={Array.isArray(adsFilter.account_type ) && adsFilter.account_type?.find(item => item == "RESELLER") ? true : ""}
                                />
                                <i className="input-helper"></i>
                                RESELLER
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1-text-left">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                value="DIRECT"
                                onChange={e=> onInputAccountTypeCheck(e)}
                                name="account_type"
                                // checked={adsFilter.account_type == "DIRECT" ? true : "" }
                                checked={Array.isArray(adsFilter.account_type ) && adsFilter.account_type?.find(item => item == "DIRECT") ? true : ""} 
                                />
                                <i className="input-helper"></i>
                                DIRECT
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Supply Chain Applicability
                          </label>

                          <div className="col-md-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="supply_chain_applicability"
                                  value="0"
                                  checked={createBidder.supply_chain_applicability == "0"}
                                  onChange={e=>onInputChange(e)}
                                   />
                                All
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="supply_chain_applicability"
                                  value="1"
                                  checked={createBidder.supply_chain_applicability == "1"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                Complete Only(complete=1)
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>

                        {/* <Form.Group className="row">
    <label className="col-sm-2 col-form-label text-right"></label>
    <div className="col">
      <div className="form-check">
        <label className="form-check-label">
          <input type="checkbox" className="form-check-input" />
          <i className="input-helper"></i>
          This is a client side unwrapping VAST Tag
        </label>
      </div>
    </div>
  </Form.Group> */}
                      </fieldset>
                    </div>
                    <br />
                    <div>
                      <fieldset>
                        <legend>Request Filters</legend>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Supported Request Types
                          </label>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                name="adRequestType"
                                value="1"
                                checked={Array.isArray(createBidder.adRequestType) && createBidder.adRequestType?.find(item => item == 1) ? true : ""}
                                onChange={(e)=>handleChangeAdRequestType(e)}
                                />
                                <i className="input-helper"></i>
                                VAST
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                name="adRequestType"
                                value="2" 
                                onChange={e=>handleChangeAdRequestType(e)}
                                checked={Array.isArray(createBidder.adRequestType) && createBidder.adRequestType?.find(item => item == "2") ? true : ""}
                                // onChange={e=> onInputChangeAdRequestType(e)}
                                // onChange={()=>{
                                //   if(checkedvpaid){
                                //     setVisiblevpaid(false);
                                //   }else{
                                //     setVisiblevpaid(true);
                                //   }
                                //   setCheckedVpaid(!checkedvpaid);
                                // }}
                                />
                                <i className="input-helper"></i>
                                VPAID
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                name="adRequestType"
                                value="3"
                                onChange={e=>handleChangeAdRequestType(e)}
                                checked={Array.isArray(createBidder.adRequestType) && createBidder.adRequestType?.find(item => item == "3") ? true : ""}
                                // onChange={e => onInputChangeTypeCheck(e)}
                                // name="adRequestType"
                                // value="3"
                                // checked={checkedmraid}
                                // onChange={()=>{
                                //   if(checkedmraid){
                                //     setVisibleMraid(false);
                                //   }else{
                                //     setVisibleMraid(true);
                                //   }
                                //   setCheckedmraid(!checkedmraid);
                                // }}
                                />
                                <i className="input-helper"></i>
                                MRAID
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                name="adRequestType"
                                value="4"
                                onChange={e=>handleChangeAdRequestType(e)}
                                checked={Array.isArray(createBidder.adRequestType) && createBidder.adRequestType?.find(item => item == "4") ? true : ""}
                                // onChange={e => onInputChangeTypeCheck(e)}
                                // name="adRequestType"
                                // value="4"
                                // checked={Array.isArray(createBidder.adRequestType ) && createBidder.adRequestType?.find(item => item == "4") ? true : ""}
                                />
                                <i className="input-helper"></i>
                                JS
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        {/* <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Supported Bid Request Creative
                          </label>
                          { visiblehandlevpaid &&
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"></input>
                                <i className="input-helper"></i>
                                VPAID 2.0
                              </label>
                            </div>
                          </div>
                          }
                          { visiblehandlemraid &&
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                MRAID 1.0
                              </label>
                            </div>
                          </div>
                          }
                          { visiblehandlemraid &&
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                MRAID 2.0
                              </label>
                            </div>
                          </div>
                          }

                        </Form.Group> */}
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Maximum Requests/Second (QPS)
                          </label>
                          
                              <div className="col-sm-2">
                                <Form.Control
                                  className="form-control customInput"
                                  type="text"
                                  name="BidderQpsValue"
                                  value={createBidder.BidderQpsValue || ""}
                                  onChange={e => onInputChangeBidderQpsValue(e)

                                           }
                                  disabled={createBidder.BidderQpsIsUnlimited == "1"}
                                  />
                              </div>
                          
                          <div className="col">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                name="BidderQpsIsUnlimited"
                                value="1"
                                checked={createBidder.BidderQpsIsUnlimited == "1" ? true : ""}
                                onChange={e=>onInputBidderQpsUnlimited(e)}
                                //   if(checked){
                                //     setVisiblehandleunlimited(true);
                                //   }else{
                                //     setVisiblehandleunlimited(false);
                                //   }
                                //   setChecked(!checked);
                                // }}
                                />
                                <i className="input-helper"></i>
                                Unlimited
                              </label>
                              
                            </div>
                            
                          </div>
                          
                        </Form.Group>
                        <Form.Group className="row">
                          <div className="col-sm-3">
                          </div>
                          <div className="col">
                            <p className='formErrors'>{validation.BidderQpsValue}</p>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Device Type
                          </label>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                value="1"
                                onChange={e => onInputChangeCheck(e)}
                                name="EnabledOnDesktop"
                                // checked={(createBidder.EnabledOnDesktop ) && createBidder.EnabledOnDesktop == "1" ? true : ""}
                                checked={createBidder.EnabledOnDesktop == "1" ? true : "" }
                                />
                                <i className="input-helper"></i>
                                Desktop
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                value="1"
                                onChange={e=>onInputChangeMobile(e)}
                                name="EnabledOnMobile"
                                checked={createBidder.EnabledOnMobile == "1" ? true : ""}
                                />
                                <i className="input-helper"></i>
                                Mobile
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                value="1"
                                onChange={e=>onInputChangeTablet(e)}
                                name="EnabledOnTablet"
                                checked={createBidder.EnabledOnTablet == "1" ? true : ""}
                                />
                                <i className="input-helper"></i>
                                Tablet
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input"
                                value="1"
                                onChange={e=>onInputChangeConnectedtv(e)}
                                name="EnabledOnConnectedTV"
                                checked={createBidder.EnabledOnConnectedTV == "1" ? true : ""}
                                />
                                
                                <i className="input-helper"></i>
                                ConnectedTV
                              </label>
                              
                            </div>
                            
                          </div>

                        </Form.Group>
                        <Form.Group className="row">
                        <div className="col-sm-3"></div>
                          <div className="col">
                          <p className="formErrors">{validation.EnabledOnDesktop}</p>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Request Type
                          </label>

                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="BidderPlatform"
                                  value="site,app"
                                  checked={createBidder.BidderPlatform == "site,app"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                Both(App And Site)
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-sm-2-text-right">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="BidderPlatform"
                                  value="app"
                                  checked={createBidder.BidderPlatform == "app"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                App Only
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="BidderPlatform"
                                  value="site"
                                  checked={createBidder.BidderPlatform == "site"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                Site Only
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Device OS
                          </label>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="DeviceOs"
                                  value="All"
                                  checked={createBidder.DeviceOs == "All"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                All
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="DeviceOs"
                                  value="Android"
                                  checked={createBidder.DeviceOs == "Android"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                Android
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="DeviceOs"
                                  value="ios"
                                  checked={createBidder.DeviceOs == "ios"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                iOS
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            GDPR Applicability
                          </label>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="GdprApplicability"
                                  value="-1"
                                  checked={createBidder.GdprApplicability == "-1"}
                                  onChange={e => onInputChange(e)}
                                  />
                                All
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="GdprApplicability"
                                  value="1"
                                  checked={createBidder.GdprApplicability == "1"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                True
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="GdprApplicability"
                                  value="0"
                                  checked={createBidder.GdprApplicability == "0"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                False
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                            <label className="col-sm-3 col-form-label text-right">Target Countries</label>
                            <div className="col-sm-1">
                                  <button
                                  type="button"
                                  className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                  onClick={(e)=>handleTargetCountries(e)}
                                  // onClick={()=> handleBlock(createBidder.BlockThisList)}
                                  >
                                  ......
                                  </button>
                                  
                            </div>
                            <div className="col-sm-4">All Countries Are selected by default</div>
                        </Form.Group>
                        { handleCountries &&
                          <div>
                          {/* <fieldset> */}
                              {/* <legend>Ad Size Filter</legend> */}
                              
                              <Form.Group className="row">
                              
                              <div className="col-sm-5">
      
                           <div className="container-box2">
                             <div className="item-list block">
                              <Table 
                              sx={{ minWidth: 100 }}
                              >
                                    
                                        <tr>
                                          
                                          <th style={{background:"#f7f7f7"}}>
                                            <input 
                                            type="checkbox"
                                            id="channelsleftarray"
                                            name="channelsleftarray"
                                            value={channels}
                                            onChange={(e)=>handleSelectAll(e)}>
                                            </input>
                                          </th>
                                          <th style={{background:"#f7f7f7"}}>Countries</th>  
                                          <th style={{background:"#f7f7f7"}}>alpha_2_code</th>
                                        </tr>
                                    
                             
                             {
                               countries.map((row)=>(
                                <><tr 
                                id={row.alpha_2_code}
                                onClick={(e)=>handleCountryTableRowSelect(e)}>
                                     <td>
                                        <label className="form-check-label">
                                          <input
                                            type="checkbox"
                                            id="leftarrayforCountry"
                                            name="leftarrayforCountry"
                                            className="checkAdSize12"
                                            value={row.alpha_2_code}
                                            onChange={(e)=>rightContainerForCountries(e)}
                                            />
                                        </label>
                                     </td>
                                     <td style={{width:"50px"}}>{row.country_name}</td>
                                     <td style={{width:"50px"}}>{row.alpha_2_code}</td>
                                   </tr></>
                                  
                                  
                              ))}
                              </Table>
                              </div>
                              </div> 
                              </div>
                                
                              
                              <div className="col-xl-2">
                              <div>
                                <div className="form-check" align="center">
                                  <button
                                    type="button"
                                    id="res"
                                    name="res"
                                    className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                    value={finaloutput.res}
                                    onClick={(e) => RightClickCountries(e)}>
                                       {/* <FontAwesomeIcon icon="save" />faChevronRight */}
                                    <FontAwesomeIcon icon="chevron-right"/>
                                  </button>
                                </div>
                              </div>
                              <div>
                                <div className="form-check" align="center">
                                  <button
                                    type="button"
                                    id="rightarrayforCountry"
                                    name="rightarrayforCountry"
                                    className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                    value={userinfoCountryList.rightarrayforCountry}
                                    onClick={(e) => LeftClickCountries(e)}
                                  >
                                    <FontAwesomeIcon icon="chevron-left"/>
                                  </button>
                                </div>
                              </div>
                              
                              </div>
                              <div className="col-xl-5">
                                <div className="container-box2">
                                <Table>
                                         
                                           <tr>
                                              <td style={{background:"#f7f7f7"}}>
                                              <input
                                              type="checkbox"
                                              id="rightarrayforCountry"
                                              name="rightarrayforCountry"
                                              className="checkboxRighCountries"
                                              value={userinfoCountryList.rightarrayforCountry}
                                              // onChange={(e)=>handleRightSelectAll(e)}
                                              >
      
                                              </input>
                                              </td>
                                              <td style={{background:"#f7f7f7"}}>Countries</td>
                                              <td style={{background:"#f7f7f7"}}>alpha_2_code</td>
                                           </tr>
                                         
                                   {
                                     searchbyidCountries.map((row,index) => (
                                       
                                         <tr>
                                           <td>
                                              <label className="form-check-label">
                                              <input
                                                type="checkbox"
                                                id="channelsrightarrayForAdSize"
                                                name="channelsrightarrayForAdSize"
                                                className="checkboxRightAdSize"
                                                // checked={checked}
                                                value={row.alpha_2_code || ""}
                                                onChange={(e)=>leftContainerForCountries(e)} 
                                                />
                                                </label>
                                            </td>
                                            <td>{row.country_name}</td>
                                            <td>{row.alpha_2_code}</td>
                                          </tr>
                                       
                                     )
                                     )
                                   }
                                  </Table>
                                  </div>
                                </div>
                                
                                
                              {/* </div> */}
                            </Form.Group>
                            <Form.Group >
                            <label className="col-sm-3 col-form-label text-right">
                          </label>
                          <div className="col-sm-4">
                          {/* <Form.Control
                              className="form-control customTextarea"
                              type="text"
                              as="textarea"
                              // name="seat_id"
                              // value={seatBidder.seat_id || ""}
                              // onChange={(e) => onInputSeatBidderChange(e)}
                              
                          > */}
                          {/* <div> */}
                            
                              
                            <Form.Control
                            // className="form-control customTextarea"
                            className="check15"
                            type="text"
                            as="textarea"
                            rows="4"
                            // name="channel_choice"
                            value={createBidder.BidderCountryCode || ""}
                            onClick={e => onInputChannelChoiceChange(e)}
                            >
                              
                            </Form.Control>
                          {/* </Form.Control> */}
                          {/* </div> */}
                          </div>
                          </Form.Group>
      
                              
                              
                              
                              
                          {/* </fieldset> */}
                          </div>
                        }
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">Other Filters</label>
                          <div className="col-sm-3">
                            <select className="form-control customDropDown" name="otherfilters"
                              style={{ width: "280px" }}
                              onChange={(e) => handleClick(e)}
                            >
                              <option value="others">Other Filters</option>
                              <option value="adsizedesktop">Ad Size Desktop</option>
                              <option value="adsizemt">Ad Size(Mobile/Tablet)</option>
                              <option value="skippable">Skippable-Yes/No</option>
                              <option value="sound">Sound On/Off</option>
                              <option value="autoplay">Autoplay-Yes/No</option>
                              <option value="incentivized">Incentivized-Yes/No</option>
                              <option value="instream">In-Stream - Yes/No</option>
                              <option value="clickable">Clickable - Yes/No</option>
                              <option value="integration">Integration Type</option>
                              <option value="ifa">Has IFA - Yes/No</option>
                              <option value="gpslatlong">Has GPS Based Lat/Long</option>
                              <option value="viewability">Viewability Measure</option>
                              <option value="vdoadformat">.VDO Ad Formats</option>
                              <option value="domainnamebundleid">Has Domain Name/Bundle ID-Yes</option>
                              <option value="adunitfilter">Ad Unit Filter(Desktop)</option>
                            </select>
                            {/* <br/> */}

                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <div className="col-sm-1"></div>
                                <label className="col-sm-2 col-form-label text-right">Ad Size(Mobile/Tablet)</label>
                                <div className="col text-left">
                                  <div className="form-check">
                                    <label className="form-check-label">
                                      <input type="checkbox" className="form-check-input" 
                                        onChange={e => onInputChangeAdsize(e)}
                                        name="adsize"
                                        value="300_250"
                                        checked={Array.isArray(createBidder.adsize) && createBidder.adsize?.find(item => item == "300_250") ? true : ""}
                                      />
                                      <i className="input-helper"></i>300 * 250
                                    </label>
                                  </div>
                                  <div className="form-check">
                                    <label className="form-check-label">
                                      <input type="checkbox" className="form-check-input" 
                                        onChange={e => onInputChangeAdsize(e)}
                                        name="adsize"
                                        value="320_480"
                                        checked={Array.isArray(createBidder.adsize ) && createBidder.adsize?.find(item => item == "320_480") ? true : ""}
                                      />
                                      <i className="input-helper"></i>320 * 480
                                    </label>
                                  </div>
                                  <div className="form-check">
                                    <label className="form-check-label">
                                      <input type="checkbox" className="form-check-input" 
                                        onChange={e => onInputChangeAdsize(e)}
                                        name="adsize"
                                        value="492_517"
                                        checked={Array.isArray(createBidder.adsize ) && createBidder.adsize?.find(item => item == "492_517") ? true : ""}
                                      />
                                      <i className="input-helper"></i>492 * 517
                                    </label>
                                  </div>
                                  <div className="form-check">
                                    <label className="form-check-label">
                                      <input type="checkbox" className="form-check-input" 
                                        onChange={e => onInputChangeAdsize(e)}
                                        name="adsize"
                                        value="others"
                                        checked={Array.isArray(createBidder.adsize ) && createBidder.adsize?.find(item => item == "others") ? true : ""}
                                      />
                                      <i className="input-helper"></i>Others
                                    </label>
                                  </div>
                                </div>

                        </Form.Group>
                        <Form.Group className="row">
                                <div className="col-sm-1"></div>
                                <label className="col-sm-2 col-form-label mt-1 text-right">Has GPS-based Lat/Long</label>
                                
                                        <div className="col-sm-1 text-left">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input
                                                    type="radio"
                                                    className="form-check-input"
                                                    name="gps"
                                                    value="yes"
                                                    checked={createBidder.gps == "yes"}
                                                    onChange={e => onInputChange(e)}
                                                />
                                                Yes<i className="input-helper"></i>
                                                </label>
                                            </div>
                                        </div>
                                        <div className="col-sm-1">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input
                                                    type="radio"
                                                    className="form-check-input"
                                                    name="gps"
                                                    value="no"
                                                    checked={createBidder.gps == "no"}
                                                    onChange={e => onInputChange(e)}
                                                />
                                                No
                                                <i className="input-helper"></i>
                                                </label>
                                            </div>
                                        </div>
                                        
                        </Form.Group>
                        <Form.Group className="row">
                                <div className="col-sm-1"></div>
                                <label className="col-sm-2 col-form-label mt-1 text-right">Has IFA - Yes/No</label>
                                        <div className="col-sm-1 text-left">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input
                                                    type="radio"
                                                    className="form-check-input"
                                                    name="ifa"
                                                    value="yes"
                                                    checked={createBidder.ifa == "yes"}
                                                    onChange={e => onInputChange(e)}
                                                />
                                                Yes<i className="input-helper"></i>
                                                </label>
                                            </div>
                                        </div>
                                        <div className="col-sm-1">
                                            <div className="form-check">
                                                <label className="form-check-label">
                                                <input
                                                    type="radio"
                                                    className="form-check-input"
                                                    name="ifa"
                                                    value="no"
                                                    checked={createBidder.ifa == "no"}
                                                    onChange={e => onInputChange(e)}
                                                />
                                                No
                                                <i className="input-helper"></i>
                                                </label>
                                            </div>
                                        </div>
                                        
                            </Form.Group>
                        {visibleSkippable &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Skippable-Yes/No
                            </label>

                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="skippable"
                                    value="yes"
                                    checked={createBidder.skippable == "yes"}
                                    onChange={e=>onInputChange(e)}
                                    // defaultChecked
                                     />
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>

                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="skippable"
                                    value="no"
                                    checked={createBidder.skippable == "no"}
                                    onChange={e=>onInputChange(e)}
                                     />
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleClickClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>
                          }
                        {visibleAutoplay &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              AutoPlay-Yes/No
                            </label>

                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="autoplay"
                                    value="true"
                                    checked={createBidder.autoplay == "true"}
                                    onChange={e=>onInputChange(e)}
                                     />
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>

                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="autoplay"
                                    value="false"
                                    checked={createBidder.autoplay == "false"}
                                    onChange={e=>onInputChange(e)}
                                    />
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleAutoPlayClose}
                              >
                                Remove
                              </button>
                            </div>



                          </Form.Group>}
                        {visibleadsizedesktop &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Ad Size Desktop
                            </label>

                            <div className="col text-left">

                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Small
                                </label>
                              </div>


                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Medium
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Large
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleClickAdSizeDesktopClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibleadsizemt &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Ad Size(Mobile/Tablet)
                            </label>

                            <div className="col text-left">

                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  300 * 250
                                </label>
                              </div>


                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  320 * 480
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  492 * 517
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Others
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleClickAdSizeMTClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visiblesound &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Sound-On/Off
                            </label>

                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  On
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>

                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  Off
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleSoundClose}
                              >
                                Remove
                              </button>
                            </div>



                          </Form.Group>}
                        {visibleincentivized &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Incentivized-Yes/No
                            </label>

                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>

                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleIncentivizedClose}
                              >
                                Remove
                              </button>
                            </div>



                          </Form.Group>}
                        {visibleinstream &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              In-Stream
                            </label>

                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>

                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleInstreamClose}
                              >
                                Remove
                              </button>
                            </div>



                          </Form.Group>}
                        {visibleclickable &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Clickable-Yes/No
                            </label>

                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>

                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleClickableClose}
                              >
                                Remove
                              </button>
                            </div>



                          </Form.Group>}
                        {visibleintegration &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Integration Type
                            </label>

                            <div className="col text-left">

                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Chocolate SSP
                                </label>
                              </div>


                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Vdopia Direct
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Mediation Direct
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Indirect
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleClickIntegrationClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibleifa &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Has IFA-Yes/No
                            </label>

                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>

                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleIfaClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visiblegpslatlong &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Has GPS-based Lat/Long - Yes/No
                            </label>

                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>

                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleGpsLatLongClose}
                              >
                                Remove
                              </button>
                            </div>



                          </Form.Group>}
                        {visibleviewability &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Viewability Measure
                            </label>

                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>

                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleViewAbilityClose}
                              >
                                Remove
                              </button>
                            </div>
                            {/* <Form.Group className="row"> */}
                            <div className="col-sm-2"></div>

                            <div className="col text-left">

                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Enable Moat Viewability Measurement
                                </label>
                              </div>
                            </div>



                          </Form.Group>}
                        {visiblevdoadformat &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              .VDO Ad Formats
                            </label>

                            <div className="col text-left">

                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Max. VDO
                                </label>
                              </div>


                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  InView.VDO Push-Down
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  InView.VDO In-Line
                                </label>
                              </div>

                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleClickVdoAdFormatClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}
                        {visibledomainnamebundleid &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Has Domain Name / Bundle ID - Yes
                            </label>

                            <div className="col-sm-1">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    id="membershipRadios1"
                                    defaultChecked />{" "}
                                  Yes
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>

                            <div className="col-sm-3">
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input
                                    type="radio"
                                    className="form-check-input"
                                    name="auctionType"
                                    disabled
                                    id="membershipRadios2" />{" "}
                                  No
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </div>
                            <div className="col-sm-2">
                              <button
                                // type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleDomainBundleClose}
                              >
                                Remove
                              </button>
                            </div>
                            {/* <Form.Group className="row"> */}
                            <div className="col-sm-2"></div>





                          </Form.Group>}
                        {visibleadunitfilter &&
                          <Form.Group className="row">
                            <div className="col-sm-2"></div>
                            <label className="col-sm-4 col-form-label text-left">
                              Ad Unit Filter(Desktop)
                            </label>

                            <div className="col text-left">

                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Interstitial
                                </label>
                              </div>


                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  InBanner
                                </label>
                              </div>

                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Outstream
                                </label>
                              </div>
                              <div className="form-check">
                                {/* <label className="form-check-label"> */}
                                Instream
                                {/* </label> */}
                              </div>

                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Preroll
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Midroll
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Postroll
                                </label>
                              </div>
                              <div className="form-check">
                                <label className="form-check-label">
                                  <input type="checkbox" className="form-check-input" />
                                  <i className="input-helper"></i>
                                  Any
                                </label>
                              </div>

                            </div>
                            <div className="col-sm-2">
                              <button
                                type="submit"
                                className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                                onClick={handleClickAdUnitFilterClose}
                              >
                                Remove
                              </button>
                            </div>
                          </Form.Group>}

                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">Data Center Region</label>
                          <div className="col-sm-3">
                            <select className="form-control customDropDown" name="DataCenterRegion" onChange={e => onInputChange(e)}
                            >
                              <option value="any" selected={createBidder.DataCenterRegion=="any"}>Any Region</option>
                              <option value="uswest2" selected={createBidder.DataCenterRegion=="uswest2"}>Region: us-west-2</option>
                              <option value="useast1" selected={createBidder.DataCenterRegion=="useast1"}>Region: us-east-1</option>
                              <option value="eucentral1" selected={createBidder.DataCenterRegion=="eucentral1"}>Region: eu-central-1</option>
                              <option value="apnortheast1" selected={createBidder.DataCenterRegion=="apnortheast1"}>Region: ap-northeast-1</option>
                              <option value="apsoutheast1" selected={createBidder.DataCenterRegion=="apsoutheast1"}>Region: ap-southeast-1</option>
                            </select>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">Ad Skippable</label>
                          <div className="col-sm-6">
                            <select className="form-control customDropDown" name="adSkippableSelected" onChange={(e)=>onInputChange(e)} style={{ width: "250px" }}
                            >
                              <option selected={createBidder.adSkippableSelected == "all"} value="all">All</option>
                              <option selected={createBidder.adSkippableSelected == "yes"} value="yes">Yes</option>
                              <option selected={createBidder.adSkippableSelected == "no"} value="no">No</option>
                            </select>
                            <div className="controls min-controls" style={{ color: "#49afcd", fontSize: "13px" }}>
                              <b>Note: </b>This Ad Duration metrics will be applicable for video inventory only
                            </div>
                          </div>

                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">Ad Duration</label>
                          <div className="col-sm-6">
                            <select className="form-control customDropDown" name="adDuration" onChange={(e)=>onInputChange(e)} style={{ width: "250px" }}
                            >
                              <option selected={createBidder.adDuration == "all"} value="all">Any</option>
                              <option selected={createBidder.adDuration == "15"} value="15">15 seconds and above</option>
                              <option selected={createBidder.adDuration == "30"} value="30">30 seconds and above</option>
                              <option selected={createBidder.adDuration == "60"} value="60">60 seconds and above</option>
                            </select>
                            <div className="controls min-controls" style={{ color: "#49afcd", fontSize: "13px" }}>
                              <b>Note: </b>This Ad Skippable metrics will be applicable for matching with Ad-Request only
                            </div>
                          </div>

                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Cookies Matched With
                          </label>

                          <div className="col-sm-2-right">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="cookie_sync_targeting"
                                  value="0"
                                  checked={createBidder.cookie_sync_targeting == "0"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                  Buyer Sync
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="cookie_sync_targeting"
                                  value="1"
                                  checked={createBidder.cookie_sync_targeting == "1"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                Supply Sync
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-sm-4" style={{marginLeft:"-60px"}}>
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="cookie_sync_targeting"
                                  value="-1"
                                  checked={createBidder.cookie_sync_targeting == "-1"}
                                  onChange={e=>onInputChange(e)}
                                  />
                                Default(With Cookie Or Without Cookie)
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                      </fieldset>
                    </div>
                    <br />
                    <div>
                      <fieldset>
                        <legend>Vadmins Only</legend>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Vdopia Bidder
                          </label>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="IsVdopiaBidder"
                                  value="1"
                                  checked={createBidder.IsVdopiaBidder == "1"}
                                  onChange={e => onInputChange(e)}
                                   />
                                Yes
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="IsVdopiaBidder"
                                  value="0"
                                  checked={createBidder.IsVdopiaBidder == "0"}
                                  onChange={e => onInputChange(e)}                                
                                  />
                                No
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>


                        </Form.Group>


                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Margin Percentage <br />(0-100)
                          </label>
                          <div className="col-sm-4">
                            <Form.Control
                              className="form-control customInput"
                              type="text"
                              name="BidderVdopiaMargin"
                              value={createBidder.BidderVdopiaMargin || ""} 
                              onChange={e => onInputChange(e)} 
                          />
                              
                        
                          </div>
                          <label className="col-sm-0 col-form-label text-left">
                            <span>
                              <strong>%</strong>  Vdopia Default is 50%
                            </span>
                          </label>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Companion Banner Resource Type
                          </label>
                          <div className="col-sm-2">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                disabled
                                />
                                <i className="input-helper"></i>
                                Static Resource
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-2-text-right">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" className="form-check-input" />
                                <i className="input-helper"></i>
                                iFrame Resource
                              </label>
                            </div>
                          </div>


                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            Bid Request Compression
                          </label>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="bidRequestCompression"
                                  value="1"
                                  checked={createBidder.bidRequestCompression == "1"}
                                  onChange={e => onInputChange(e)}
                                   />{" "}
                                True
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="bidRequestCompression"
                                  value="0"
                                  checked={createBidder.bidRequestCompression == "0"}
                                  onChange={e => onInputChange(e)}
                                  />{" "}
                                False
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                        <Form.Group className="row">
                          <label className="col-sm-3 col-form-label text-right">
                            App-Id Encoding
                          </label>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="IsAppIdEncoding"
                                  value="1"
                                  checked ={createBidder.IsAppIdEncoding == "1"}
                                  onChange={e => onInputChange(e)}
                                  />{" "}
                                Yes
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>

                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  name="IsAppIdEncoding"
                                  value="0"
                                  checked={createBidder.IsAppIdEncoding == "0"}
                                  onChange={e => onInputChange(e)}
                                  />
                                No
                                <i className="input-helper"></i>
                              </label>
                            </div>
                          </div>
                        </Form.Group>
                      </fieldset>
                    </div>
                    <br />











                    {/* Publisher Channels */}
                    <div>
                    <fieldset>
                        <legend>Publisher Channels</legend>
                        <Form className="row">
                                  <div className="col-sm-3">
                                    <Form.Control
                                      className="form-control customInput"
                                      type="text"
                                      name="name"
                                      // value={""}
                                      placeholder="Search Publisher Channels..."
                                      onChange={(e) => onInputSearchChange(e)}
                                    />
                                  </div>
                                  <div className="col-sm-3">
                                  <button
                                    type="button"
                                    className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                    onClick={(e)=>onSearchSubmit(e)}
                                    >Search 

                                    {/* <FontAwesomeIcon icon="search" /> */}
                                  </button>
                                  </div>
                        </Form>
                        <br/>
                        <Form.Group className="row">
                        
                        <div className="col-sm-5">

                     <div className="container-box2">
                       <div className="item-list block">
                        <Table 
                        sx={{ minWidth: 100 }}
                        >
                              
                                  <tr>
                                    
                                    <th style={{background:"#f7f7f7"}}>
                                      <input 
                                      type="checkbox"
                                      id="channelsleftarray"
                                      name="channelsleftarray"
                                      value={channels}
                                      onChange={(e)=>handleSelectAll(e)}>
                                      </input>
                                    </th>
                                      
                                    <th style={{background:"#f7f7f7"}}>ID</th>
                                    {/* <th style={{background:"#f7f7f7"}}>Name</th> */}
                                    <th style={{background:"#f7f7f7"}}>Channel Type</th>
                                    {/* <th style={{background:"#f7f7f7"}}>Type</th> */}
                                    <th style={{background:"#f7f7f7"}}>Name</th>
                                  </tr>
                              
                       
                       {
                         channels.map((row)=>(
                          <><tr 
                          id={row.id}
                          onClick={(e)=>handleTableRowSelect(e)}>
                               <td>
                                  <label className="form-check-label">
                                    <input
                                      type="checkbox"
                                      id="channelsleftarray"
                                      name="channelsleftarray"
                                      className="check12"
                                      value={row.id}
                                      onChange={(e)=>rightContainer(e)}/>
                                  </label>
                               </td>
                               <td style={{width:"30px"}}>{row.id}</td>
                               {/* <td style={{width:"30px"}}>{row.name}</td> */}
                               <td style={{width:"30px"}}>{row.channel_type}</td>
                               {/* <td style={{width:"30px"}}>{row.channel_created}</td> */}
                               <td style={{width:"30px"}}>{row.name}</td>
                             </tr></>
                            
                            
                        ))}
                        </Table>
                        </div>
                        </div> 
                        </div>
                          
                        
                        <div className="col-xl-2">
                        <div>
                          <div className="form-check" align="center">
                            <button
                              type="button"
                              id="res"
                              name="res"
                              className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                              value={finaloutput.res}
                              onClick={(e) => RightClickOnHandle(e)}>
                                 {/* <FontAwesomeIcon icon="save" />faChevronRight */}
                              <FontAwesomeIcon icon="chevron-right"/>
                            </button>
                          </div>
                        </div>
                        <div>
                          <div className="form-check" align="center">
                            <button
                              type="button"
                              id="channelsrightarray"
                              name="channelsrightarray"
                              className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                              value={userinfo.channelsrightarray}
                              onClick={(e) => handleOnLeftClick(e)}
                            >
                              <FontAwesomeIcon icon="chevron-left"/>
                            </button>
                          </div>
                        </div>
                        
                        </div>
                        <div className="col-xl-5">
                          <div className="container-box2">
                          <Table>
                                   
                                     <tr>
                                        <td style={{background:"#f7f7f7"}}>
                                        <input
                                        type="checkbox"
                                        id="channelsrightarray"
                                        name="channelsrightarray"
                                        className="checkboxRight"
                                        value={userinfo.channelsrightarray}
                                        onChange={(e)=>handleRightSelectAll(e)}
                                        >

                                        </input>
                                        </td>
                                        <td style={{background:"#f7f7f7"}}>ID</td>
                                        <td style={{background:"#f7f7f7"}}>Channel Type</td>
                                        <td style={{background:"#f7f7f7"}}>Name</td>
                                     </tr>
                                   
                             {
                               searchbyid.map((row,index) => (
                                 
                                   <tr>
                                     <td>
                                        <label className="form-check-label">
                                        <input
                                          type="checkbox"
                                          id="channelsrightarray"
                                          name="channelsrightarray"
                                          className="check11"
                                          // checked={checked}
                                          value={row.id || ""}
                                          onChange={(e)=>leftCheckboxContainer(e)} 
                                          />
                                          </label>
                                      </td>
                                      <td>{row.id}</td>
                                      <td>{row.channel_type}</td>
                                      <td>{row.name}</td>
                                    </tr>
                                 
                               )
                               )
                             }
                            </Table>
                            </div>
                          </div>
                          
                          
                        {/* </div> */}
                      </Form.Group>
                      <Form.Group >
                      <label className="col-sm-3 col-form-label text-right">
                    </label>
                    <div className="col-sm-4">
                    {/* <Form.Control
                        className="form-control customTextarea"
                        type="text"
                        as="textarea"
                        // name="seat_id"
                        // value={seatBidder.seat_id || ""}
                        // onChange={(e) => onInputSeatBidderChange(e)}
                        
                    > */}
                    {/* <div> */}
                      
                        
                      <Form.Control
                      // className="form-control customTextarea"
                      className="check15"
                      type="text"
                      as="textarea"
                      rows="4"
                      // name="channel_choice"
                      value={createBidder.channel_choice || ""}
                      onClick={e => onInputChannelChoiceChange(e)}
                      >
                        
                      </Form.Control>
                    {/* </Form.Control> */}
                    {/* </div> */}
                    </div>
                    </Form.Group>
                    </fieldset>
                    </div>
                    {/* Publisher Channels */}
                    <br/>









                    {/* Ad Size Filter */}
                    <div>
                    <fieldset>
                        <legend>Ad Size Filter</legend>
                        <Form className="row">
                                  <div className="col-sm-3">
                                    <Form.Control
                                      className="form-control customInput"
                                      type="text"
                                      name="name"
                                      // value={""}
                                      placeholder="Find AdSize..."
                                      onChange={(e) => onInputSearchAdSizeChange(e)}
                                    />
                                  </div>
                                  <div className="col-sm-3">
                                  <button
                                    type="button"
                                    className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                                    onClick={(e)=>onSearchAdSizeSubmit(e)}
                                    >Search 

                                    {/* <FontAwesomeIcon icon="search" /> */}
                                  </button>
                                  </div>
                        </Form>
                        <br/>
                        <Form.Group className="row">
                        
                        <div className="col-sm-5">

                     <div className="container-box2">
                       <div className="item-list block">
                        <Table 
                        sx={{ minWidth: 100 }}
                        >
                              
                                  <tr>
                                    
                                    <th style={{background:"#f7f7f7"}}>
                                      <input 
                                      type="checkbox"
                                      id="channelsleftarray"
                                      name="channelsleftarray"
                                      value={channels}
                                      onChange={(e)=>handleSelectAll(e)}>
                                      </input>
                                    </th>
                                    <th style={{background:"#f7f7f7"}}>Id</th>  
                                    <th style={{background:"#f7f7f7"}}>Ad Type</th>
                                    {/* <th style={{background:"#f7f7f7"}}>Name</th> */}
                                    <th style={{background:"#f7f7f7"}}>Height</th>
                                    {/* <th style={{background:"#f7f7f7"}}>Type</th> */}
                                    <th style={{background:"#f7f7f7",width:"150px"}}>Width</th>
                                  </tr>
                              
                       
                       {
                         adSizeList.map((row)=>(
                          <><tr 
                          id={row.id}
                          onClick={(e)=>handleAdSizeTableRowSelect(e)}>
                               <td>
                                  <label className="form-check-label">
                                    <input
                                      type="checkbox"
                                      id="channelsleftarrayForAdSize"
                                      name="channelsleftarrayForAdSize"
                                      className="checkAdSize12"
                                      value={row.id}
                                      onChange={(e)=>rightContainerForAdSize(e)}
                                      />
                                  </label>
                               </td>
                               <td style={{width:"50px"}}>{row.id}</td>
                               <td style={{width:"50px"}}>{row.adType}</td>
                               {/* <td style={{width:"30px"}}>{row.name}</td> */}
                               <td style={{width:"50px"}}>{row.height}</td>
                               {/* <td style={{width:"30px"}}>{row.channel_created}</td> */}
                               <td style={{width:"150px"}}>{row.width}</td>
                             </tr></>
                            
                            
                        ))}
                        </Table>
                        </div>
                        </div> 
                        </div>
                          
                        
                        <div className="col-xl-2">
                        <div>
                          <div className="form-check" align="center">
                            <button
                              type="button"
                              id="res"
                              name="res"
                              className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                              value={finaloutput.res}
                              onClick={(e) => RightClickOnHandleForAdSize(e)}>
                                 {/* <FontAwesomeIcon icon="save" />faChevronRight */}
                              <FontAwesomeIcon icon="chevron-right"/>
                            </button>
                          </div>
                        </div>
                        <div>
                          <div className="form-check" align="center">
                            <button
                              type="button"
                              id="channelsrightarrayForAdSize"
                              name="channelsrightarrayForAdSize"
                              className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                              value={userinfoAdSizeList.channelsrightarrayForAdSize}
                              onClick={(e) => handleOnLeftClickForAdSize(e)}
                            >
                              <FontAwesomeIcon icon="chevron-left"/>
                            </button>
                          </div>
                        </div>
                        
                        </div>
                        <div className="col-xl-5">
                          <div className="container-box2">
                          <Table>
                                   
                                     <tr>
                                        <td style={{background:"#f7f7f7"}}>
                                        <input
                                        type="checkbox"
                                        id="channelsrightarray"
                                        name="channelsrightarray"
                                        className="checkboxRightAdSize"
                                        value={userinfo.channelsrightarray}
                                        // onChange={(e)=>handleRightSelectAll(e)}
                                        >

                                        </input>
                                        </td>
                                        <td style={{background:"#f7f7f7"}}>Id</td>
                                        <td style={{background:"#f7f7f7"}}>Ad Type</td>
                                        <td style={{background:"#f7f7f7"}}>Height</td>
                                        <td style={{background:"#f7f7f7"}}>Width</td>
                                     </tr>
                                   
                             {
                               searchAdSizebyid.map((row,index) => (
                                 
                                   <tr>
                                     <td>
                                        <label className="form-check-label">
                                        <input
                                          type="checkbox"
                                          id="channelsrightarrayForAdSize"
                                          name="channelsrightarrayForAdSize"
                                          className="checkboxRightAdSize"
                                          // checked={checked}
                                          value={row.id || ""}
                                          onChange={(e)=>leftContainerForAdSize(e)} 
                                          />
                                          </label>
                                      </td>
                                      <td>{row.id}</td>
                                      <td>{row.adType}</td>
                                      <td>{row.height}</td>
                                      <td>{row.width}</td>
                                    </tr>
                                 
                               )
                               )
                             }
                            </Table>
                            </div>
                          </div>
                          
                          
                        {/* </div> */}
                      </Form.Group>
                      <Form.Group >
                      <label className="col-sm-3 col-form-label text-right">
                    </label>
                    <div className="col-sm-4">
                    {/* <Form.Control
                        className="form-control customTextarea"
                        type="text"
                        as="textarea"
                        // name="seat_id"
                        // value={seatBidder.seat_id || ""}
                        // onChange={(e) => onInputSeatBidderChange(e)}
                        
                    > */}
                    {/* <div> */}
                      
                        
                      <Form.Control
                      // className="form-control customTextarea"
                      className="check15"
                      type="text"
                      as="textarea"
                      rows="4"
                      // name="channel_choice"
                      value={createBidder.channel_choice || ""}
                      onClick={e => onInputChannelChoiceChange(e)}
                      >
                        
                      </Form.Control>
                    {/* </Form.Control> */}
                    {/* </div> */}
                    </div>
                    </Form.Group>

                        
                        
                        
                        
                    </fieldset>
                    </div>
                    {/* Ad Size Filter */}
                    <div>
                      <fieldset>
                        <legend>Approve List</legend>
                        <div className="col-sm-4">
                          <div className="form-check">
                            <button
                              type="button"
                              className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                              onClick={(e) => handleApprove(e)}
                            >
                              Add Apps Or Sites
                            </button>
                          </div>
                          <div className='box' style={{ height: "80px" }}>

                            <br />Sites(Domain):{whiteBlackList.domain}

                          </div>
                        </div>

                      </fieldset>
                    </div>
                    <br />
                    <div>
                      <fieldset>
                        <legend>Block List</legend>
                        <div className="col-sm-4">
                          <div className="form-check">
                            <button
                              type="button"
                              className="btn btn-gradient-info btn-rounded btn-icon-text btn-xs"
                              onClick={(e)=> handleBlock(e)}
                            >
                              Add Apps Or Sites
                            </button>
                          </div>
                          <div className='box' style={{ height: "80px" }}>

                            <br />Sites(Domain):{Blacklist.domain}

                          </div>
                        </div>

                      </fieldset>
                    </div>
                    <br />
                    {/* <div>
      <fieldset>
          <legend>Publisher Channels</legend>
      <Form.Group className="row">
          <label className="col-sm-3 col-form-label text-right">
          Publisher Channels
          </label>
          <div className="col-sm-3">
            <Form.Control
              className="form-control customInput"
              placeholder="Find Channel..."
              type="text"
              name="BidderIdentifier"
              // value={BidderIdentifier || ''}
              // onChange={e => onInputChange(e)}
            />
          </div>
          
      </Form.Group>
      <Form.Group className="row">
          <div className="col-sm-auto"></div>
          <div className="col-sm-6 col-form-label">
          <div className="form-check">
          <label className="form-check-label">
            <input type="checkbox" className="form-check-input" />
            <i className="input-helper"></i>
            Showing 1 to 50 out of 506 entries
          </label>
        </div>
      </div>
      <div className="col-sm-3">
          <div className="form-check">
          <label className="form-check-label" >
            <input type="checkbox" className="form-check-input" />
            <i className="input-helper"></i>
            Showing 1 to 1 out of 1 entries
          </label>
        </div>
      </div>
      
      
      </Form.Group>


      </fieldset>
    </div> */}

                    <Form.Group className="row mt-4">
                      <label className="col-sm-2 col-form-label text-right"></label>
                      <div className="col-sm-9 ml-2">
                        <button
                          type="submit"
                          className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                          id="button" 
                          // onClick={getRandomNumber}
                          // onclick={getElementById('random-number').value=Math.floor(Math.random()*10000)}
                        >
                          Submit
                          <FontAwesomeIcon icon="save" />
                        </button>
                      </div>
                    </Form.Group>
                  </div>
                </div>
              </div>
            </Form>
          </div>
        </div>
        {/* Ad Request Setup  */}
      </div>
    </div>
    <UpdateApproveList data={whiteBlackList} showApprove={showApprove} handleApproveClose={handleApproveClose} onApproveInputChange={onApproveInputChange} onApproveSubmit={onApproveSubmit} />
    <UpdateBlockList data={Blacklist} showBlock={showBlock} handleBlockClose={handleBlockClose} onBlockedInputChange={onBlockedInputChange} onBlockedSubmit={onBlockedSubmit}/>
    </>
    
  );
}

export default AddConnection;