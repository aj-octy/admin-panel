import * as React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import { Switch } from "@material-ui/core";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableContainer from "@mui/material/TableContainer";
import { tableCellClasses } from "@mui/material/TableCell";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import { param } from "jquery";
import { Box } from '@mui/material';
import "bootstrap/dist/css/bootstrap.min.css";
import { Form } from "react-bootstrap";
import DatePicker from "react-datepicker";
import AsyncSelect from "react-select/async";
import makeAnimated from "react-select/animated";

import Select from "react-select";
import { library } from "@fortawesome/fontawesome-svg-core";
import { faSave } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useParams, useHistory } from "react-router-dom";
import Crud from '../common/Calls_methods'

const top100Films = [
  { label: 'The Shawshank Redemption', year: 1994 },
  { label: 'The Godfather', year: 1972 },

];

export default function Test() {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(50);

  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - data.length) : 0;
  const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: "#21364e",
      color: theme.palette.common.white,
      fontSize: 15,
      height: 0,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    "&:nth-of-type(odd)": {
      backgroundColor: theme.palette.action.hover,
    },
    "&:last-child td, &:last-child th": {
      border: 0,
      height: 0,
    },
  }));

  const AntSwitch = styled(Switch)(({ theme }) => ({
    width: 28,
    height: 16,
    padding: 0,
    display: "flex",
    "&:active": {
      "& .MuiSwitch-thumb": {
        width: 15,
      },
      "& .MuiSwitch-switchBase.Mui-checked": {
        transform: "translateX(9px)",
      },
    },
    "& .MuiSwitch-switchBase": {
      padding: 2,
      "&.Mui-checked": {
        transform: "translateX(12px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          opacity: 1,
          backgroundColor:
            theme.palette.mode === "dark" ? "#177ddc" : "#1890ff",
        },
      },
    },
    "& .MuiSwitch-thumb": {
      boxShadow: "0 2px 4px 0 rgb(0 35 11 / 20%)",
      width: 12,
      height: 12,
      borderRadius: 6,
      transition: theme.transitions.create(["width"], {
        duration: 200,
      }),
    },
    "& .MuiSwitch-track": {
      borderRadius: 16 / 2,
      opacity: 1,
      backgroundColor:
        theme.palette.mode === "dark"
          ? "rgba(255,255,255,.35)"
          : "rgba(0,0,0,.25)",
      boxSizing: "border-box",
    },
  }));

  const [data, setData] = useState([]);
  const getData = () => {
    axios("http://localhost:5000/advertiser").then((res) => {
      setData(res.data);
    });
  };

  useEffect(() => {
    getData();
  }, []);

  const initialValueToggle = { activated: "yes" };
  const [state, setState] = useState(initialValueToggle);
  const { activated } = state;

  const handleChange = (e, index) => {
    let activated = e.target.checked ? "yes" : "no";
    axios.put(`http://localhost:5000/advertiser/activated/${index}`, {
      activated: activated,
    });
  };

  // const getInitialState ={acc_type : "internal"}
  const [values, setValue] = useState({ acc_type: "internal" });
  const { acc_type } = values;

  const handleSelectChange = (e, select) => {
    const acc_type = e.target.value;
    axios
      .put(`http://localhost:5000/advertiser/acc_type/${select}`, {
        acc_type: acc_type,
      })
      .then(getData);
  };

  // let myname = "amandeep";
  // let arr = [...myname];
  // console.log(arr);
  // let output = arr.reduce((a, c) => {
  //   console.info(a, c);
  //   if (a[c]) ++a[c];
  //   else a[c] = 1;
  //   return a;
  // }, {});
  // console.info(output);
  //  {  a: 2 , m: 1, n:1, d:1,e:2 }

  // let numbers = [2, 6, 9];
  // let min = Math.min(...numbers);
  // let max = Math.max(...numbers);
  // let newArray = [];
  // let missingNumber = [];
  // for (let index = min; index <= max; index++) newArray.push(index);
  // newArray.forEach((it) => {
  //   let check = numbers.some((el) => el == it);
  //   if (check == false) missingNumber.push(it);
  //   return missingNumber;
  // });
  // console.info(missingNumber);







  const [jsonResults, setjsonResults] = useState([]);

  useEffect(()=>{
    // http://localhost:5000/deals/packId/58
    // fetch("http://localhost:5000/deals/packNameId")
    fetch("http://localhost:5000/deals/packId/58")
      .then((response) => response.json())
      .then((json) => setjsonResults(json))
    }, [])

    const { id } = useParams();

    let [query, setQuery] = useState([ ])
    let [queryBidder, setqueryBidder] = useState([ ])
    let [defaultDataForMulti, setdefaultDataForMulti] = useState([ ])

    const loadBidders = () => {
      Crud.fetchData(`deals/bidders-search?${queryBidder}`
      ).then((res) => res.json()
      .then(data => {
        let newData = data.map( ol => {
          return {label: ol.BidderName , value: ol.BidderId}
        })
        setQuery(newData)
      }));
    };
    useEffect( () => {
      loadBidders()
    })
    const mymultiselect =(e) => {
     console.log(e)
      setdefaultDataForMulti(e);

    }
   
    const getDealData = () => {
      Crud.details(`deals/`+ 111).then((res) => {
        console.info(res.data)
      loadBidderData(res.data.deal_id)
        // setdefaultDataForMulti(res.data.deal_id)
      });
    };

    const loadBidderData = (deal_id) => {
      Crud.fetchData(`deal_bidder/` + deal_id).then((res) =>{
        res.json()
        .then((it) => {
          it.forEach(element => {
            Crud.fetchData(`deal_bidder/bidder_id/` + element.bidder_id).then((res) =>{
              res.json()
              .then((el) => {
                let check = defaultDataForMulti.some(item => item.value == el.BidderId)
                console.info(check)
                 if(check == false){
                  setdefaultDataForMulti(o=>([...o,{label: el[0].BidderName, value: el[0].BidderId}]));
                }
              }
            )})
          });
          // setdefaultDataBidderData([{ label: el[0].name, value: el[0].id }]);
        }).catch( er =>{
          console.error(er)
        })
      });
      
    };

  useEffect(() => {
    if (id != undefined) {
      getDealData();
    } else if (id == "") {
    }
  }, []);






  const initialValue={adRequestType:[]}
  const [Bidder,setBidder]=useState(initialValue);
  const { adRequestType } = Bidder;

  const initialValue2={adRequestType2:[]}
  const [Bidder2,setBidder2]=useState(initialValue2);

const onInputChangeTypeCheck =(e) =>{
        console.log(e.target.name)
        console.log(e.target.value)
        const { value, checked } = e.target;
        if(checked){
            setBidder(item1=>({
                ...item1,[e.target.name]: [...item1[e.target.name], e.target.value]
            }));
        }else{
            setBidder(item1=>({
                ...item1,adRequestType: adRequestType.filter((e) => e !== value)
            }));
        }        
}


let changeBackgroundColor = e => {
  console.log("test")
  console.log(Bidder.adRequestType)

  for (const element of Bidder.adRequestType) {
    console.log(element);
    setBidder2([element])
  }
  
  console.log(Bidder2)
}

  const onSubmit = async (e) => {
    e.preventDefault();
    console.info(defaultDataForMulti)
    console.log(Bidder)


    console.log(Bidder2)

  }





  return (
    <>
      
        <em>Advertisers</em>
        <Form onSubmit={(e) => onSubmit(e)}>










        <Form.Group className="row">
                          <label className="col-sm-2 col-form-label text-right">
                            Supported Request Types
                          </label>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                onChange={e => onInputChangeTypeCheck(e)}
                                name="adRequestType"
                                value="test1"
                                // checked={(Bidder.adRequestType ) && Bidder.adRequestType?.find(item => item == "1") ? true : ""}
                                />
                                <i className="input-helper"></i>
                                VAST
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                onChange={e => onInputChangeTypeCheck(e)}
                                name="adRequestType"
                                value="test2"
                                // checked={checkedvpaid}
                                />
                                <i className="input-helper"></i>
                                VPAID
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                onChange={e => onInputChangeTypeCheck(e)}
                                name="adRequestType"
                                value="test3"
                                />
                                <i className="input-helper"></i>
                                MRAID
                              </label>
                            </div>
                          </div>
                          <div className="col-sm-1">
                            <div className="form-check">
                              <label className="form-check-label">
                                <input type="checkbox" 
                                className="form-check-input" 
                                onChange={e => onInputChangeTypeCheck(e)}
                                name="adRequestType"
                                value="test4"
                                // checked={Array.isArray(Bidder.adRequestType ) && Bidder.adRequestType?.find(item => item == "4") ? true : ""}
                                />
                                <i className="input-helper"></i>
                                JS
                              </label>
                            </div>
                          </div>
                        </Form.Group>



                        <Form.Group className="row mt-4">
                <label className="col-sm-2 col-form-label text-right"></label>
                <div className="col-sm-9 ml-2">
                  <button
                  type="button"
                    onClick={changeBackgroundColor} 
                    className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                  >
                    push array
                    
                  </button>
                </div>
              </Form.Group>




        <Form.Group className="row">
                {/* <label className="col-sm-2 col-form-label"> </label> */}
                <div
                  className="col-sm-10"
                  style={{ marginLeft: "0px" }}
                >
                    <Select
                    isMulti
                    options={query}
                    // className="basic-multi-select"
                    classNamePrefix="select"
                    onChange={(e) => mymultiselect(e)}
                    isLoading={false}
                    value={defaultDataForMulti}
                    isClearable={false} 
                    isSearchable={true}
                    isRtl={false}
                  />

                </div>
                </Form.Group>

                <Form.Group className="row mt-4">
                <label className="col-sm-2 col-form-label text-right"></label>
                <div className="col-sm-9 ml-2">
                  <button
                    type="submit"
                    className="btn btn-gradient-info btn-rounded btn-icon-text btn-lg"
                  >
                    Submit
                    
                  </button>
                </div>
              </Form.Group>
                </Form>


        
      
      <br />
      <br />
      {/* <Paper sx={{ overflow: "hidden" }}>
        <TableContainer className='tablewidth'>
          <Table
            sx={{ minWidth: 1600 }}
            size="small"
            stickyHeader
            aria-label="customized table"
          >
            <TableHead sx={{ width: "100%" }}>
              <StyledTableRow>
                <StyledTableCell align="left">Status</StyledTableCell>
                <StyledTableCell align="left">dropdown</StyledTableCell>
                <StyledTableCell align="left">id</StyledTableCell>
              </StyledTableRow>
            </TableHead>
            <TableBody sx={{ width: "100%" }}>
              {(rowsPerPage > 0
                ? data.slice(
                    page * rowsPerPage,
                    page * rowsPerPage + rowsPerPage
                  )
                : data
              ).map((row, index) => (
                <StyledTableRow align="right" key={row.id}>
                  <StyledTableCell>
                    <AntSwitch
                      inputProps={{ "aria-label": "ant design" }}
                      color="primary"
                      size="small"
                      defaultChecked={row.activated == "yes" ? true : false}
                      onChange={(e) => handleChange(e, row.id)}
                      name="activated"
                    />
                  </StyledTableCell>
                  <StyledTableCell>
                    <div className="container p-0">
                      <select
                        className="form-control tableDropDown"
                        value={row.acc_type}
                        onChange={(e) => handleSelectChange(e, row.id)}
                        name="acc_type"
                        style={{ width: "100px" }}
                      >
                        <option value="internal">internal</option>
                        <option value="external">external</option>
                      </select>
                    </div>
                  </StyledTableCell>
                  <StyledTableCell>{row.id}</StyledTableCell>
                </StyledTableRow>
              ))}
              {emptyRows > 0 && (
                <StyledTableRow style={{ height: 53 * emptyRows }}>
                  <TableCell colSpan={10} />
                </StyledTableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper> */}
    </>
  );
}

