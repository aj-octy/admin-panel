import React  from 'react';
import axios from 'axios';
import { Container,Row,Col } from 'react-bootstrap'
import {Button} from 'react-bootstrap'
import { Component } from 'react/cjs/react.production.min';


class newifilter extends Component {

constructor(props) {
  super(props)

  this.state = {
     email:'',
     postId:'',
     name:'',
     body:''
  }
}



changeHandler = e => {
    this.setState({[e.target.name]: e.target.value})
}

submitHandler = e => {
    e.preventDefault()
    console.log(this.state)
    axios.post("https://jsonplaceholder.typicode.com/comments",this.state)
    .then(response => {
        console.log(response)
    })
    .catch(error=>{
        console.log(error)
    })
}

render(){
    const{email,postId,name,body}=this.state
  return (
    <>
    <form onSubmit={this.submitHandler}>
    <div>
      <h3>Create a New IFilter</h3>
      <br/>
      <fieldset>
        <legend>Deal Settings</legend>
      </fieldset>
    </div>
    <br/>
    <br/>
    <Container>
    <Row xs="auto">
    <Col>
    
    
        <label class="control-label">
         
      <label>Enter your Email
      <i class="text-error">*</i>
      </label>
      </label>

    </Col>
    <Col>
      <input 
    //   onChange={(e)=>handle(e)} id="name" value={data.name} 
      style={{width:"400px"}} className="form-control" name='email' value={email} onChange={this.changeHandler} type="text" placeholder="Enter Email..." aria-label="Search" />
    </Col>
    
    
    </Row>
    </Container>
    <br/>
    <Container>
        <Row xs="auto">
            <Col>
                <label class="control-label">
                <label>Enter  Product ID
                <i class="text-error">*</i>
                </label>
                </label>
            </Col>
            <Col>
            <input 
            // onChange={(e)=>handle(e)} id="email" value={data.email} 
            style={{width:"400px"}} className="form-control" name='postId' value={postId} onChange={this.changeHandler} type="text" placeholder="Enter Product ID..." aria-label="Search" />
            </Col>
        </Row>
    </Container>
    <br/>
    <Container>
        <Row xs="auto">
            <Col>
                <label class="control-label">
                <label>Enter  Name
                <i class="text-error">*</i>
                </label>
                </label>
            </Col>

            <Col>
            <input 
            // onChange={(e)=>handle(e)} id="email" value={data.email} 
            style={{width:"400px"}} className="form-control" name='name' value={name} onChange={this.changeHandler} type="text" placeholder="Enter Name..." aria-label="Search" />

            </Col>
        </Row>
    </Container>
    <br/>
    <Container>
        <Row xs="auto">
        <Col>
                <label class="control-label">
                <label>Enter  body
                <i class="text-error">*</i>
                </label>
                </label>
            </Col>

            <Col>
            <input 
            // onChange={(e)=>handle(e)} id="email" value={data.email} 
            style={{width:"400px"}} className="form-control" name='body' value={body} onChange={this.changeHandler} type="text" placeholder="Enter body..." aria-label="Search" />

            </Col>
        </Row>
    </Container>
    <br/>
    <Button 
    type='submit'
    // onClick={()=>this.postData()} 
    style={{marginLeft:"930px"}} variant="primary" size='sm' 
        //    onClick={() => {history.push("/dashboard/newifilter")}}
          > 
    {/* <i className="mdi mdi-plus menu-icon"></i> */}
    Save
    
    </Button>{' '} 
    </form>
    </>
  )
}
}

export default newifilter