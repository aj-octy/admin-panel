import React, {  useState, useEffect } from 'react';
import { Dropdown } from 'react-bootstrap';
import { Link } from 'react-router-dom';
// import { Trans } from 'react-i18next';
import {AuthContext} from "../../helpers/AuthContext"
import axios from 'axios';
import chocolateLogo from '../../assets/images/chocolateLogo.png';
import userImg from '../../assets/images/user.png'
import chocolate_icon from '../../assets/images/chocolate_icon.png'



function Navbar() {

  const [authState, setAuthState] = useState({
    username: "",
    id: 0,
    status: false,
  });

  useEffect(() => {
    let unmounted = false;
    axios.get("http://localhost:5000/auth/auth",{
      headers:{
        accessToken: localStorage.getItem("accessToken")
      }
    }).then((response) => {
      if(!unmounted){
      if(response.data.error) {
        setAuthState({...authState, status: false});
      }else{
        setAuthState({
          username: response.data.username,
          id: response.data.id,
          status: true,
        });
        localStorage.setItem("id", response.data.id);
      }
    }
    })
     return ()=>{
       unmounted = true;
     } 
    
  },[])

  const logout = () =>{
    localStorage.removeItem("accessToken");
    setAuthState({
      username: "",
      id: 0,
      status: false,
    });
}
 
    return (
      <AuthContext.Provider value={{authState, setAuthState}}>
      <nav className="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div className="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <Link className="navbar-brand brand-logo" to="/"><img src={chocolateLogo} alt="logo" /></Link>
          <Link className="navbar-brand brand-logo-mini" to="/"><img src={chocolate_icon} alt="logo" /></Link>
        </div>
        <div className="navbar-menu-wrapper d-flex align-items-stretch">
          <button className="navbar-toggler navbar-toggler align-self-center" type="button" onClick={ () => document.body.classList.toggle('sidebar-icon-only') }>
            <span className="mdi mdi-menu"></span>
          </button>
          
          <ul className="navbar-nav navbar-nav-right">
            <li className="nav-item nav-profile">
              <Dropdown alignRight>
                <Dropdown.Toggle className="nav-link">
                  <div className="nav-profile-img">
                    <img src={userImg} alt="user"/>
                    <span className="availability-status online"></span>
                  </div>
                  <div className="nav-profile-text">
                    <p className="mb-1 text-grey">{authState.username}</p>
                  </div>
                </Dropdown.Toggle>

                <Dropdown.Menu className="navbar-dropdown">
                  <Dropdown.Item href="!#">
                    <i className="mdi mdi-logout mr-2 text-primary"></i>
                    {!authState.status ? 
                      (<>
                          <Link to="/login">Login</Link>
                          <Link to="/registration"> Registration</Link>
                      </>
                      ) : (
                        <button className="btn btn-gradient-dark btn-rounded btn-icon-text btn-lg"
                        onClick={logout}>loguot</button>
                      )
                    }
                    
                    
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </li>
            
            
            
          
          </ul>
          <button className="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" >
            <span className="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      </AuthContext.Provider>
    );
  // }
}

export default Navbar;
