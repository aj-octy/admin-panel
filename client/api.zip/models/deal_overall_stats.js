module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const deal_overall_stats = sequelize.define("deal_overall_stats", {
      deal_id: {
        type: DataTypes.STRING
      },
      impressions:{
        type: DataTypes.INTEGER
      },
      adv_rev: {
        type: DataTypes.FLOAT(15,2)
      },
      pub_rev:{
        type: DataTypes.FLOAT(15,2)
      },

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return deal_overall_stats;
  };