module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const publisher_domain_blocklist = sequelize.define("publisher_domain_blocklist", {
      adomain: {
        type: DataTypes.STRING
      },
      pub_id: {
        type: DataTypes.INTEGER
      },
      ex_adomain:{
        type: DataTypes.STRING
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return publisher_domain_blocklist;
  };