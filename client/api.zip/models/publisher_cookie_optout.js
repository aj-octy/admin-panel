module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const publisher_cookie_optout = sequelize.define("publisher_cookie_optout", {
      cookie_id: {
        type: DataTypes.STRING
      },
      pub_id: {
        type: DataTypes.INTEGER
      },
      added_on:{
        type: DataTypes.DATE
      },
      user_id:{
        type: DataTypes.INTEGER
      },

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return publisher_cookie_optout;
  };