module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const dataCenter = sequelize.define("dataCenter", {
      dc_name: {
        type: DataTypes.STRING
      },
      dc_url: {
        type: DataTypes.STRING,
      },

      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return dataCenter;
  };