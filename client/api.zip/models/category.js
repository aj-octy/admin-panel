module.exports = (sequelize, DataTypes) => {
    sequelize.sync()
      const category = sequelize.define("category", {
        category_code: {
          type: DataTypes.STRING,
        },
        category_name: {
          type: DataTypes.STRING,
        }
      },{
        freezeTableName: false,
        
      });
    
      return category;
    };