module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const country_codes = sequelize.define("country_codes", {
      country_name: {
        type: DataTypes.STRING,
      },
      alpha_2_code: {
        type: DataTypes.STRING,
      },
      alpha_3_code: {
        type: DataTypes.STRING,
      },
      numeric_code: {
        type: DataTypes.STRING,
      },
      iso_3166_2_code: {
        type: DataTypes.STRING,
      },
    },{
      freezeTableName: false,
      
    });
  
    return country_codes;
  };