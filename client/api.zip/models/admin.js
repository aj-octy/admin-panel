module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const admin = sequelize.define("admin", {
      Login: {
        type: DataTypes.STRING
      },
      password: {
        type: DataTypes.STRING,
      },
      passwd:{
        type: DataTypes.STRING
      },
      Name:{
        type: DataTypes.STRING
      },
      privileges:{
        type: DataTypes.ENUM('superadmin','sales','sales_ro','exec','admin','finance','tools_ro')
      },
      releaseDirectories:{
        type: DataTypes.STRING
      },
      super_regions:{
        type: DataTypes.STRING
      },
      manager_id:{
        type: DataTypes.STRING
      },
      secret:{
        type: DataTypes.STRING
      },
      is_developer:{
        type: DataTypes.STRING
      },
      status_privileges:{
        type: DataTypes.ENUM('superadmin', 'readonly')
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return admin;
  };