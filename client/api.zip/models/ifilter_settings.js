module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const ifilter_settings = sequelize.define("ifilter_settings", {
      setting_key: {
        type: DataTypes.STRING
      },
      setting_value: {
        type: DataTypes.STRING
      },
      setting_type:{
        type: DataTypes.STRING
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return ifilter_settings;
  };