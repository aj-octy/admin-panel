module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const floorBasedMargin_h = sequelize.define("floorBasedMargin_h", {
      floor_start_range: {
        type: DataTypes.FLOAT(5,2)
      },
      floor_end_range: {
        type: DataTypes.FLOAT(5,2)
      },
      country_code:{
        type: DataTypes.STRING
      },
      margin:{
        type: DataTypes.FLOAT(5,2)
      },
      updated_on:{
        type: DataTypes.DATE
      },
      updated_by:{
        type: DataTypes.STRING
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return floorBasedMargin_h;
  };