module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const hudsonBidder = sequelize.define("hudsonBidder", {
      BidderId: {
        type: DataTypes.STRING
      },
      publisherId: {
        type: DataTypes.INTEGER
      },
      BidderType: {
        type: DataTypes.ENUM('rtb21','rtb22','rtb24','vast_fixed_price','vast_vdopia_extn_price','vpaid_fixed_price','vpaid_vdopia_extn_price')
      },
      BidderPrice: {
        type: DataTypes.FLOAT
      },
      BidderModel:{
        type: DataTypes.ENUM('CPM', 'CPCV')
      },
      BidderCurrency: {
        type: DataTypes.ENUM('USD', 'EUR', 'INR', 'SGD')
      },
      BidderUrl: {
        type: DataTypes.STRING
      },
      BidderWinUrl: {
        type: DataTypes.STRING
      },
      BidderVdopiaMargin: {
        type: DataTypes.FLOAT
      },
      BidderCountryCode: {
        type: DataTypes.STRING
      },
      BidderAdformat: {
        type: DataTypes.ENUM('video', 'bannerNinterstitial')
      },
      BidderStatus: {
        type: DataTypes.ENUM('Approved','Disapproved','Pending_Review','Test')
      },
      BidderCreateDate: {
        type: DataTypes.DATE
      },
      BidderUpdatedAt: {
        type: DataTypes.DATE
      },
      BidderPlatform: {
        type: DataTypes.STRING
      },
      BidderAuctionType: {
        type: DataTypes.ENUM('first_price_auction','second_price_auction','both')
      },
      BidderQpsValue: {
        type: DataTypes.INTEGER
      },
      BidderQpsIsUnlimited: {
        type: DataTypes.INTEGER
      },
      AdvertiserId: {
        type: DataTypes.BIGINT
      },
      DeviceOs: {
        type: DataTypes.STRING
      },
      EnabledOnTablet: {
        type: DataTypes.INTEGER
      },
      IsVdopiaBidder: {
        type: DataTypes.INTEGER
      },
      BidderName: {
        type: DataTypes.STRING
      },
      BidderIdentifier: {
        type: DataTypes.STRING
      },
      BidderAdditionalSettings: {
        type: DataTypes.STRING
      },
      ClientSideUnwrapping: {
        type: DataTypes.INTEGER
      },
      ApiFramework: {
        type: DataTypes.STRING
      },
      adRequestType: {
        type: DataTypes.STRING
      },
      data_provider_expr: {
        type: DataTypes.TEXT
      },
      deal_id: {
        type: DataTypes.STRING
      },
      only_deal_impression: {
        type: DataTypes.INTEGER
      },
      DailyFreqPerDeviceId: {
        type: DataTypes.INTEGER
      },
      channel_choice: {
        type: DataTypes.TEXT
      },
      include_channel: {
        type: DataTypes.INTEGER
      },
      channelWhitelist: {
        type: DataTypes.BLOB('medium') 
      },
      isChannelListWhitelist: {
        type: DataTypes.INTEGER
      },
      bidRequestCompression: {
        type: DataTypes.INTEGER
      },
      SecurityType: {
        type: DataTypes.ENUM('protocol_relative_url','secure_only_url','non_secure_only_url')
      },
      testRequest: {
        type: DataTypes.INTEGER
      },
      device_types: {
        type: DataTypes.STRING
      },
      delivery_cap: {
        type: DataTypes.INTEGER
      },
      device_make: {
        type: DataTypes.STRING
      },
      EnabledOnMobile: {
        type: DataTypes.INTEGER
      },
      EnabledOnDesktop: {
        type: DataTypes.INTEGER
      },
      IsAppIdEncoding: {
        type: DataTypes.INTEGER
      },
      GdprApplicability: {
        type: DataTypes.INTEGER
      },
      EnabledOnConnectedTV: {
        type: DataTypes.INTEGER
      },
      DataCenterRegion: {
        type: DataTypes.STRING
      },
      is_feedback_enabled: {
        type: DataTypes.INTEGER
      },
      FloorBasedMargin: {
        type: DataTypes.INTEGER
      },
      is_dfilter_enabled: {
        type: DataTypes.INTEGER
      },
      is_private_auction: {
        type: DataTypes.INTEGER
      },
      tagid: {
        type: DataTypes.STRING
      },
      is_burl_enabled: {
        type: DataTypes.INTEGER
      },
      supply_chain_applicability: {
        type: DataTypes.INTEGER
      },
      cookie_sync_targeting: {
        type: DataTypes.INTEGER
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return hudsonBidder;
  };