module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const adSizeMasterList = sequelize.define("adSizeMasterList", {
      adType: {
        type: DataTypes.ENUM('video', 'banner'),
      },
      width: {
        type: DataTypes.INTEGER,
      },
      height:{
        type: DataTypes.INTEGER
      },
      updated_by:{
        type: DataTypes.STRING
      },
      updated_on:{
        type: DataTypes.DATE
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return adSizeMasterList;
  };