module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const deals = sequelize.define("deals", {
      name: {
        type: DataTypes.STRING
      },
      deal_id:{
        type: DataTypes.STRING
      },
      auction_price_type: {
        type: DataTypes.ENUM('fixed', 'nonfixed')
      },
      start_date:{
        type: DataTypes.DATE
      },
      end_date:{
        type: DataTypes.DATE
      },
      status:{
        type: DataTypes.ENUM('pause', 'active', 'completed')
      },
      created_at:{
        type: DataTypes.DATE
      },
      updated_at:{
        type: DataTypes.DATE
      },
      deal_type:{
        type: DataTypes.ENUM('guaranteed', 'nonguaranteed')
      },
      daily_limit:{
        type: DataTypes.INTEGER
      },
      price:{
        type: DataTypes.FLOAT(10,2)
      },
      pack_id:{
        type: DataTypes.INTEGER
      },
      seat_id:{
        type: DataTypes.STRING
      },
      definition:{
        type: DataTypes.STRING
      },

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return deals;
  };