module.exports = (sequelize, DataTypes) => {
    sequelize.sync()
      const network_ISP = sequelize.define("network_ISP", {
        ccode: {
          type: DataTypes.STRING,
        },
        isp_name: {
          type: DataTypes.STRING,
        }
      },{
        freezeTableName: false,
        
      });
    
      return network_ISP;
    };