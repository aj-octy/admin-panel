module.exports = (sequelize, DataTypes) => {
    const publisher = sequelize.define("publisher", {
      fname: {
        type: DataTypes.STRING,
      },lname: {
        type: DataTypes.STRING,
      },apikey: {
        type: DataTypes.STRING,
      },identifier: {
        type: DataTypes.STRING,
      },description: {
        type: DataTypes.TEXT,
      },Notes: {
        type: DataTypes.TEXT,
      },passwd: {
        type: DataTypes.STRING,
      },lastlogin: {
        type: DataTypes.DATE,
      },addtime: {
        type: DataTypes.DATE,
      },email: {
        type: DataTypes.STRING,
      },currency: {
        type: DataTypes.STRING,
      },phone: {
        type: DataTypes.STRING,
      },mobile: {
        type: DataTypes.STRING,
      },fax: {
        type: DataTypes.STRING,
      },address1: {
        type: DataTypes.STRING,
      },address2: {
        type: DataTypes.STRING,
      },city: {
        type: DataTypes.STRING,
      },state: {
        type: DataTypes.STRING,
      },country: {
        type: DataTypes.STRING,
      },zip: {
        type: DataTypes.STRING,
      },legal_name: {
        type: DataTypes.STRING,
      },ssn: {
        type: DataTypes.STRING,
      },company_name: {
        type: DataTypes.STRING,
      },
      advertiser_id: {
        type: DataTypes.INTEGER,
      },
      type: {
        type: DataTypes.ENUM('online', 'iphone'),
      },
      allowed_networks: {
        type: DataTypes.STRING,
      },
      payment_cycle: {
        type: DataTypes.INTEGER,
      },
      acc_type: {
        type: DataTypes.ENUM('internal', 'external'),
      },
      pub_network_type: {
        type: DataTypes.ENUM('unknown', 's2s' , 'direct' , 'rtb'),
      },
      supply_type: {
        type: DataTypes.ENUM('chocolate_tag', 'chocolate_ortb' , 'ebda_ortb'),
      },
      secret: {
        type: DataTypes.STRING,
      },fallback: {
        type: DataTypes.INTEGER,
      },fallback_tag: {
        type: DataTypes.STRING,
      },seller_network_id: {
        type: DataTypes.STRING,
      },activated: {
        type: DataTypes.STRING,
      },price_settle_method: {
        type: DataTypes.ENUM('floor', 'margin' , 'both'),
      },psm_trickle_rate: {
        type: DataTypes.INTEGER,
      },is_seller_json_enabled: {
        type: DataTypes.INTEGER,
      },is_truncated_ip_enabled: {
        type: DataTypes.INTEGER,
      },network_type: {
        type: DataTypes.STRING,
      },network_code: {
        type: DataTypes.STRING,
      },adtxt_url: {
        type: DataTypes.STRING,
      },monthaly_volume_video: {
        type: DataTypes.STRING,
      },monthaly_volume_display: {
        type: DataTypes.STRING,
      },app_domain: {
        type: DataTypes.TEXT,
      },term_and_condition: {
        type: DataTypes.INTEGER,
      },comments: {
        type: DataTypes.TEXT,
      },publisher_type: {
        type: DataTypes.ENUM('ADMOB', 'ADD_MANAGER' , 'OTHER'),
      },is_reauction: {
        type: DataTypes.INTEGER,
      },is_ifilter: {
        type: DataTypes.INTEGER,
      },authenticated_with: {
        type: DataTypes.INTEGER,
      }
    },{
      freezeTableName: false,
      timestamps: false
    });
  
    // publisher.associate = (models) => {
    //   publisher.hasMany(models.Posts, {
    //     onDelete: "cascade",
    //   });
    // };
    return publisher;
  };