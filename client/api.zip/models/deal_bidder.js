module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const deal_bidder = sequelize.define("deal_bidder", {

      deal_id:{
        type: DataTypes.STRING
      },
      bidder_id: {
        type: DataTypes.STRING
      },
      margin:{
        type: DataTypes.INTEGER
      },
      created_at:{
        type: DataTypes.DATE
      },
      updated_at:{
        type: DataTypes.DATE
      },
      

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return deal_bidder;
  };