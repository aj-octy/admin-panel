module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const city_code_mapping = sequelize.define("city_code_mapping", {
      state_code: {
        type: DataTypes.STRING
      },
      city_name:{
        type: DataTypes.STRING
      },
      country_code:{
        type: DataTypes.STRING
      },

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return city_code_mapping;
  };