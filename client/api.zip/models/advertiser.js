module.exports = (sequelize, DataTypes) => {
    const advertiser = sequelize.define("advertiser", {
      fname: {
        type: DataTypes.STRING,
      },lname: {
        type: DataTypes.STRING,
      },apikey: {
        type: DataTypes.STRING,
      },description: {
        type: DataTypes.TEXT,
      },Notes: {
        type: DataTypes.TEXT,
      },passwd: {
        type: DataTypes.STRING,
      },lastlogin: {
        type: DataTypes.DATE,
      },addtime: {
        type: DataTypes.DATE,
      },email: {
        type: DataTypes.STRING,
      },phone: {
        type: DataTypes.STRING,
      },mobile: {
        type: DataTypes.STRING,
      },fax: {
        type: DataTypes.STRING,
      },address1: {
        type: DataTypes.STRING,
      },address2: {
        type: DataTypes.STRING,
      },city: {
        type: DataTypes.STRING,
      },state: {
        type: DataTypes.STRING,
      },country: {
        type: DataTypes.STRING,
      },zip: {
        type: DataTypes.STRING,
      },legal_name: {
        type: DataTypes.STRING,
      },ssn: {
        type: DataTypes.STRING,
      },company_name: {
        type: DataTypes.STRING,
      },Publisher_id: {
        type: DataTypes.INTEGER,
      },type: {
        type: DataTypes.ENUM('online', 'iphone'),
      },timezone: {
        type: DataTypes.STRING,
      },activated: {
        type: DataTypes.ENUM('yes', 'no'),
      },sex: {
        type: DataTypes.STRING,
      },credit: {
        type: DataTypes.DECIMAL(27, 9),
      },acc_type: {
        type: DataTypes.ENUM('internal', 'external'),
      },secret: {
        type: DataTypes.STRING,
      }
    },{
      freezeTableName: false,
      timestamps: false
    });
  
    // advertiser.associate = (models) => {
    //   advertiser.hasMany(models.Posts, {
    //     onDelete: "cascade",
    //   });
    // };
    return advertiser;
  };