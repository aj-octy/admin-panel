module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const ifilter_history = sequelize.define("ifilter_history", {
      setting_key: {
        type: DataTypes.STRING
      },
      setting_value: {
        type: DataTypes.STRING
      },
      tstamp: {
        type: DataTypes.DATE
      },
      updatedBy: {
        type: DataTypes.STRING
      },
      setting_type:{
        type: DataTypes.ENUM('video','banner')
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return ifilter_history;
  };