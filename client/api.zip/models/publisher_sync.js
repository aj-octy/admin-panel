module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const publisher_sync = sequelize.define("publisher_sync", {
      publisher_id: {
        type: DataTypes.STRING
      },
      publisher_initiated_url: {
        type: DataTypes.STRING
      },
      publisher_sync_url:{
        type: DataTypes.STRING
      },
      macro:{
        type: DataTypes.STRING
      },
      bidirectional:{
        type: DataTypes.INTEGER
      },
      vdopia_initiated:{
        type: DataTypes.INTEGER
      },
      expiration_time:{
        type: DataTypes.INTEGER
      },
      enabled:{
        type: DataTypes.INTEGER
      },
      creation_date:{
        type: DataTypes.DATE
      },
      update_date:{
        type: DataTypes.DATE
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return publisher_sync;
  };