module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const channels = sequelize.define("channels", {
      publisher_id: {
        type: DataTypes.INTEGER
      },
      url: {
        type: DataTypes.STRING
      },
      name: {
        type: DataTypes.STRING,
      },
      chclt_apikey:{
        type: DataTypes.STRING,
      },
      verified:{
        type: DataTypes.ENUM('Not Verified', 'Verified'),
      },
      approval:{
        type: DataTypes.ENUM('automatic', 'manual'),
      },
      playerurl:{
        type: DataTypes.STRING,
      },
      allow_sitetargeting:{
        type: DataTypes.STRING.BINARY
      },
      pretty_name:{
        type: DataTypes.STRING,
      },
      tagline:{
        type: DataTypes.STRING,
      },
      channel_category:{
        type: DataTypes.STRING,
      },
      primary_category:{
        type: DataTypes.STRING,
      },
      type:{
        type: DataTypes.ENUM('video','tracker','app','wap','richmedia','vast2vdo'),
      },
      channel_type:{
        type: DataTypes.ENUM('iphone','PC'),
      },
      extAds:{
        type: DataTypes.STRING,
      },
      description:{
        type: DataTypes.TEXT,
      },
      groups:{
        type: DataTypes.STRING,
      },
      appType:{
        type: DataTypes.ENUM('undefined','androidApp','iOSApp','RIMApp','SymbianApp','MobileWeb','Online','app','WindowsApp','iPadApp'),
      },
      tablet_specific:{
        type: DataTypes.INTEGER,
      },
      addedon:{
        type: DataTypes.DATE,
      },
      channel_created:{
        type: DataTypes.ENUM('portal', 'mobclix', 'cc-api', 'rtb'),
      },
      app_Type:{
        type: DataTypes.ENUM('ios','android','all','ios-web','android-web','ios-app','android-app','all-web','all-app','symbian-app','rim-app','windows-app','ipad-app'),
      },
      domain:{
        type: DataTypes.STRING,
      },
      app_bundle:{
        type: DataTypes.STRING,
      },
      market_place_setting:{
        type: DataTypes.ENUM('all_bidders_vdopia_optional','vdopia_bidders_only','all_bidders_vdopia_mandatory','no_bidders','test_bidders_only'),
      },
      qps_level:{
        type: DataTypes.ENUM('test','micro','medium','large','2xlarge','4xlarge','8xlarge','unlimited','blocked','trickle','automatic'),
      },
      skippable:{
        type: DataTypes.INTEGER,
      },
      sound:{
        type: DataTypes.INTEGER,
      },
      autoplay:{
        type: DataTypes.INTEGER,
      },
      incentivized:{
        type: DataTypes.INTEGER,
      },
      in_stream:{
        type: DataTypes.INTEGER,
      },
      clickable:{
        type: DataTypes.INTEGER,
      },
      integration_type:{
        type: DataTypes.TEXT,
      },
      technical_integration:{
        type: DataTypes.ENUM('c2s','s2s','none'),
      },
      direct:{
        type: DataTypes.INTEGER,
      },
      video_unit_size:{
        type: DataTypes.STRING,
      },
      ssp_channel_id:{
        type: DataTypes.INTEGER,
      },
      ApiFramework:{
        type: DataTypes.STRING,
      },
      ssp_channel_ad_id:{
        type: DataTypes.INTEGER,
      },
      exp:{
        type: DataTypes.INTEGER,
      },
      isDesktop:{
        type: DataTypes.INTEGER,
      },
      supported_adunit:{
        type: DataTypes.ENUM('interstital','inbanner','outstream','instream_preroll','instream_midroll','instream_postroll','instream_any','all'),
      },
      coppa:{
        type: DataTypes.INTEGER,
      },
      is_manual_floor:{
        type: DataTypes.INTEGER,
      },
      
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return channels;
  };