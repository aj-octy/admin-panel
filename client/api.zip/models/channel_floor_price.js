module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const channel_floor_price = sequelize.define("channel_floor_price", {
      channel_id: {
        type: DataTypes.BIGINT(20)
      },
      country_code: {
        type: DataTypes.STRING
      },
      adtype:{
        type: DataTypes.ENUM('video', 'banner'),
      },
      bundle_domain:{
        type: DataTypes.STRING
      },
      floor_price_usd:{
        type: DataTypes.FLOAT
      },
      floor_price_pub_currency:{
        type: DataTypes.FLOAT
      },
      soft_floor_price_usd:{
        type: DataTypes.FLOAT
      },
      soft_floor_price_pub_currency:{
        type: DataTypes.FLOAT
      },
      
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return channel_floor_price;
  };