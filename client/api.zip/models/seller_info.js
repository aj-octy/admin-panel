module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const seller_info = sequelize.define("seller_info", {
      seller_id: {
        type: DataTypes.STRING
      },
      is_confidential: {
        type: DataTypes.INTEGER
      },
      name:{
        type: DataTypes.STRING
      },
      domain:{
        type: DataTypes.STRING
      },
      comment:{
        type: DataTypes.STRING
      },
      seller_type:{
        type: DataTypes.STRING
      },
      is_passthrough:{
        type: DataTypes.STRING
      },
      status:{
        type: DataTypes.ENUM('active', 'inactive')
      },
      created_on:{
        type: DataTypes.DATE
      },
      updated_on:{
        type: DataTypes.DATE
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return seller_info;
  };