module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const bidder_sync = sequelize.define("bidder_sync", {
      advertiser_id: {
        type: DataTypes.STRING
      },
      bidder_sync_url: {
        type: DataTypes.STRING
      },
      macro:{
        type: DataTypes.STRING
      },
      bidirectional:{
        type: DataTypes.INTEGER
      },
      expiration_time:{
        type: DataTypes.INTEGER
      },
      enabled:{
        type: DataTypes.INTEGER
      },
      priority:{
        type: DataTypes.INTEGER
      },
      integrationtype:{
        type: DataTypes.ENUM('partner_initiated', 'vdopia_initiated'),
      },
      creation_date:{
        type: DataTypes.DATE
      },
      update_date:{
        type: DataTypes.DATE
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return bidder_sync;
  };