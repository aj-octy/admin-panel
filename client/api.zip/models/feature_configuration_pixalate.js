module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const feature_configuration_pixalate = sequelize.define("feature_configuration_pixalate", {
      mobile_web_tag: {
        type: DataTypes.STRING
      },
      mobile_inapp_tag: {
        type: DataTypes.STRING
      },
      daily_capping:{
        type: DataTypes.INTEGER
      },
      status:{
        type: DataTypes.ENUM('disable', 'enable')
      },
      refresh_rate:{
        type: DataTypes.INTEGER
      },
      creation_date:{
        type: DataTypes.DATE
      },
      updation_date:{
        type: DataTypes.DATE
      },
      feature_name:{
        type: DataTypes.STRING
      },
      desktop_web_tag:{
        type: DataTypes.STRING
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return feature_configuration_pixalate;
  };