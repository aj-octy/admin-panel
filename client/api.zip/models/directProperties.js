module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const directProperties = sequelize.define("directProperties", {
      channel_apikey: {
        type: DataTypes.STRING
      },
      domain_bundle: {
        type: DataTypes.INTEGER,
      },
      status:{
        type: DataTypes.ENUM('Active', 'Inactive'),
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return directProperties;
  };