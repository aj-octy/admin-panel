module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const globally_blocked_domains = sequelize.define("globally_blocked_domains", {
      domain: {
        type: DataTypes.STRING
      },
      platform: {
        type: DataTypes.ENUM('app','site'),
      },
      category: {
        type: DataTypes.STRING,
      },
      created_on:{
        type: DataTypes.DATE,
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return globally_blocked_domains;
  };