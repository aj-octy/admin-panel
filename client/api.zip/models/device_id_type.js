module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const device_id_type = sequelize.define("device_id_type", {
      device_id: {
        type: DataTypes.STRING
      },
      model:{
        type: DataTypes.STRING
      },

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return device_id_type;
  };