module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const device_os = sequelize.define("device_os", {
      os_name: {
        type: DataTypes.STRING
      },
      os_version:{
        type: DataTypes.STRING
      },

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return device_os;
  };