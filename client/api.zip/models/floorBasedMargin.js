module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const floorBasedMargin = sequelize.define("floorBasedMargin", {
      floor_start_range: {
        type: DataTypes.FLOAT(5,2)
      },
      floor_end_range: {
        type: DataTypes.FLOAT(5,2)
      },
      country_code:{
        type: DataTypes.STRING
      },
      margin:{
        type: DataTypes.FLOAT(5,2)
      },
      updated_on:{
        type: DataTypes.DATE
      },
      
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return floorBasedMargin;
  };