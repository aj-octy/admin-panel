module.exports = (sequelize, DataTypes) => {
    sequelize.sync()
      const network_carrier = sequelize.define("network_carrier", {
        ccode: {
          type: DataTypes.STRING,
        },
        carrier: {
          type: DataTypes.STRING,
        }
      },{
        freezeTableName: false,
        
      });
    
      return network_carrier;
    };