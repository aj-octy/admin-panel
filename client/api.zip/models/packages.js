module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const packages = sequelize.define("packages", {
      definition: {
        type: DataTypes.TEXT
      },
      status: {
        type: DataTypes.ENUM('pending', 'active', 'inactive')
      },
      created_at:{
        type: DataTypes.DATE
      },
      updated_at:{
        type: DataTypes.DATE
      },
      name:{
        type: DataTypes.STRING
      },
      video_inventory_type_expr:{
        type: DataTypes.STRING
      },
      app_web_expr:{
        type: DataTypes.STRING
      },
      devices_expr:{
        type: DataTypes.STRING
      },
      carriers_network_expr:{
        type: DataTypes.STRING
      },
      location_expr:{
        type: DataTypes.STRING
      },
      data_provider_expr:{
        type: DataTypes.STRING
      },
      design_id:{
        type: DataTypes.STRING
      },
      targeting_code:{
        type: DataTypes.STRING
      },
      targeting_code_expr:{
        type: DataTypes.STRING
      },
      url_targeting_expr:{
        type: DataTypes.STRING
      },
      enabled_on_desktop:{
        type: DataTypes.STRING
      },
      enabled_on_mobile:{
        type: DataTypes.STRING
      },
      enabled_on_tablet:{
        type: DataTypes.STRING
      },
      package_json:{
        type: DataTypes.STRING
      },
      enabled_on_ctv	:{
        type: DataTypes.STRING
      },
      supply_chain_applicability:{
        type: DataTypes.STRING
      }

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return packages;
  };