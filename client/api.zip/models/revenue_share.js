module.exports = (sequelize, DataTypes) => {
    const revenue_share = sequelize.define("revenue_share", {
      publisher_id: {
        type: DataTypes.INTEGER,
      },rev_share: {
        type: DataTypes.FLOAT,
      },effective_date: {
        type: DataTypes.DATE,
      },created_at: {
        type: DataTypes.DATE,
      },updated_at: {
        type: DataTypes.DATE,
      },isupdated: {
        type: DataTypes.INTEGER,
      }
    },{
      freezeTableName: false,
      timestamps: false
    });
    return revenue_share;
  };