module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const device_make_model = sequelize.define("device_make_model", {
      make: {
        type: DataTypes.STRING
      },
      model:{
        type: DataTypes.STRING
      },

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return device_make_model;
  };