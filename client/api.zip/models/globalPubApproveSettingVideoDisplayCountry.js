module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const globalPubApproveSettingVideoDisplayCountry = sequelize.define("globalPubApproveSettingVideoDisplayCountry", {
      ccode: {
        type: DataTypes.STRING
      },
      pub_id: {
        type: DataTypes.INTEGER
      },
      adType:{
        type: DataTypes.ENUM('videp', 'banner'),
      },
      updated_by:{
        type: DataTypes.STRING
      },
      updated_on:{
        type: DataTypes.DATE
      },

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return globalPubApproveSettingVideoDisplayCountry;
  };