module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const adult_keywords = sequelize.define("adult_keywords", {
      keyword: {
        type: DataTypes.STRING
      },
      occurence: {
        type: DataTypes.INTEGER,
      },
      created_at:{
        type: DataTypes.DATE
      },
      status:{
        type: DataTypes.ENUM('active', 'inactive'),
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return adult_keywords;
  };