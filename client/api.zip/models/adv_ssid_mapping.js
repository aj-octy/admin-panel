module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const adv_ssid_mapping = sequelize.define("adv_ssid_mapping", {
      advertiser_id: {
        type: DataTypes.STRING
      },
      platform: {
        type: DataTypes.ENUM('app', 'web')
      },
      domain_bundle:{
        type: DataTypes.STRING
      },
      ssid:{
        type: DataTypes.STRING
      },
      updated_by:{
        type: DataTypes.STRING
      },
      created_on:{
        type: DataTypes.DATE
      },
      updated_on:{
        type: DataTypes.DATE
      },
      
    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return adv_ssid_mapping;
  };