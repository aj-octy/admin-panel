module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const publisher_device_optout = sequelize.define("publisher_device_optout", {
      ccode: {
        type: DataTypes.STRING
      },
      pub_id: {
        type: DataTypes.INTEGER
      },
      inventoryType:{
        type: DataTypes.ENUM('app', 'web'),
      },
      updated_by:{
        type: DataTypes.STRING
      },
      updated_on:{
        type: DataTypes.DATE
      },

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return publisher_device_optout;
  };