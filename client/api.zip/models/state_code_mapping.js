module.exports = (sequelize, DataTypes) => {
  sequelize.sync()
    const state_code_mapping = sequelize.define("state_code_mapping", {
      ccode: {
        type: DataTypes.STRING
      },
      ccode_alpha_3:{
        type: DataTypes.STRING
      },
      state_code:{
        type: DataTypes.STRING
      },
      state_name:{
        type: DataTypes.STRING
      },

    },{
      freezeTableName: false,
      timestamps: false
      
    });
  
    return state_code_mapping;
  };