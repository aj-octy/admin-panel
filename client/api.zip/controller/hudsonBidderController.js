const { query } = require("express");
const { QueryTypes } = require('sequelize');
const { hudsonBidder ,country_codes, sequelize} = require('../models');
const { search } = require("../routes/Users");
module.exports = {



    fetchHudsonBidderData:async(req, res) => {
          let getValue = req._parsedUrl.query
          myArray = getValue.split("/", 3);
          const search = myArray[0]
          const id = myArray[1]

          console.log("************************************")
          console.log(getValue)
          console.log(search)
          console.log(id)
          console.log("************************************")
          
        try {
          const listOfhudsonBidder = await 
          sequelize.query
          (
            // "select AdvertiserId,ApiFramework,BidderAdditionalSettings,CONCAT(UPPER(SUBSTRING(BidderAdformat,1,1)),LOWER(SUBSTRING(BidderAdformat,2))) as BidderAdformat,BidderAuctionType from hudsonBidder where hudsonBidder.BidderName like :search_name limit 100",
            "select * from hudsonBidder where AdvertiserId = :id and BidderName  like :search_name limit 100",
            {
              replacements: { 
                search_name:'%'+search+'%',
                id:id
               },
              type: QueryTypes.SELECT
            },
          {
             model: hudsonBidder 
          });
          res.json(listOfhudsonBidder);
        } catch (error) {
          console.error(error);
        }
          
    },

    updateFeedback:async (req, res) => {
      const id = req.params.id;
      const activated = req.body.is_feedback_enabled;
      try {
        const is_feedback_enabled = await
        sequelize.query
        ('UPDATE hudsonBidder SET is_feedback_enabled= :activated WHERE id = :id',
        {
          replacements: { id: id, activated: activated },
        type: QueryTypes.SELECT
        },
        {
        model: hudsonBidder,
        });
        res.json(is_feedback_enabled);
      } catch (error) {
        console.error(error);
      }
  },

  updateDFilter:async (req, res) => {
    const id = req.params.id;
    const activated = req.body.is_dfilter_enabled;
    try {
      const is_dfilter_enabled = await
      sequelize.query
      ('UPDATE hudsonBidder SET is_dfilter_enabled= :activated WHERE id = :id',
      {
        replacements: { id: id, activated: activated },
      type: QueryTypes.SELECT
      },
      {
      model: hudsonBidder,
      });
      res.json(is_dfilter_enabled);
    } catch (error) {
      console.error(error);
    }
  },

  updateBURL:async (req, res) => {
      const id = req.params.id;
      const activated = req.body.is_burl_enabled;
      try {
        const is_burl_enabled = await
        sequelize.query
        ('UPDATE hudsonBidder SET is_burl_enabled= :activated WHERE id = :id',
        {
          replacements: { id: id, activated: activated },
        type: QueryTypes.SELECT
        },
        {
        model: hudsonBidder,
        });
        res.json(is_burl_enabled);
      } catch (error) {
        console.error(error);
      }
    },

    updatePrivateAuction:async (req, res) => {
      const id = req.params.id;
      const activated = req.body.is_private_auction;
      try {
        const is_private_auction = await
        sequelize.query
        ('UPDATE hudsonBidder SET is_private_auction= :activated WHERE id = :id',
        {
          replacements: { id: id, activated: activated },
        type: QueryTypes.SELECT
        },
        {
        model: hudsonBidder,
        });
        res.json(is_private_auction);
      } catch (error) {
        console.error(error);
      }
    },


    updateFloorBasedMargin:async (req, res) => {
      const id = req.params.id;
      const activated = req.body.FloorBasedMargin;
      try {
        const FloorBasedMargin = await
        sequelize.query
        ('UPDATE hudsonBidder SET FloorBasedMargin= :activated WHERE id = :id',
        {
          replacements: { id: id, activated: activated },
        type: QueryTypes.SELECT
        },
        {
        model: hudsonBidder,
        });
        res.json(FloorBasedMargin);
      } catch (error) {
        console.error(error);
      }
    },

    updateBidderPrice:async (req, res) => {
      const id = req.params.id;
      const activated = req.body.BidderPrice;
      try {
        const BidderPrice = await
        sequelize.query
        ('UPDATE hudsonBidder SET BidderPrice= :activated WHERE id = :id',
        {
          replacements: { id: id, activated: activated },
        type: QueryTypes.SELECT
        },
        {
        model: hudsonBidder,
        });
        res.json(BidderPrice);
      } catch (error) {
        console.error(error);
      }
    },


    insertHudsonBidder:async (req, res) => {


        const obj = req.body;
        const BidderIdentifier=req.body.BidderIdentifier;
        const BidderId=req.body.BidderId;
        const BidderCurrency=req.body.BidderCurrency;
        const BidderModel=req.body.BidderModel;
        const tagid=req.body.tagid;
        const BidderType=req.body.BidderType;
        const BidderPrice=req.body.BidderPrice;
        const BidderAdformat=req.body.BidderAdformat;
        const BidderAuctionType=req.body.BidderAuctionType;
        const SecurityType=req.body.SecurityType;
        const BidderUrl=req.body.BidderUrl;
        const BidderWinUrl=req.body.BidderWinUrl;
        const DailyFreqPerDeviceId=req.body.DailyFreqPerDeviceId;
        const IsVdopiaBidder=req.body.IsVdopiaBidder;
        const BidderVdopiaMargin=req.body.BidderVdopiaMargin;
        const bidRequestCompression=req.body.bidRequestCompression;
        const IsAppIdEncoding=req.body.IsAppIdEncoding;
        const GdprApplicability=req.body.GdprApplicability;
        const DeviceOs=req.body.DeviceOs;
        const BidderPlatform=req.body.BidderPlatform;
        const EnabledOnDesktop=req.body.EnabledOnDesktop;
        const EnabledOnMobile=req.body.EnabledOnMobile;
        const EnabledOnTablet=req.body.EnabledOnTablet;
        const EnabledOnConnectedTV=req.body.EnabledOnConnectedTV;
        const BidderQpsIsUnlimited=req.body.BidderQpsIsUnlimited;
        const adRequest=req.body.adRequestType;
        const adRequestType=JSON.stringify(adRequest);
        console.log(adRequestType);
        const DataCenterRegion=req.body.DataCenterRegion;
        const supply_chain_applicability=req.body.supply_chain_applicability;
        const ClientSideUnwrapping=req.body.ClientSideUnwrapping;
        const BidderQpsValue=req.body.BidderQpsValue;
        const cookie_sync_targeting=req.body.cookie_sync_targeting;
        const channels=req.body.channel_choice;
        const chan=JSON.stringify(channels);
        const bccode=req.body.BidderCountryCode;
        const BidderCountryCode=JSON.stringify(bccode);
        const objext=req.body;
        const BidderAdditionalSettings=JSON.stringify(objext)
        const AdvertiserId=req.body.adv_id;
        try {
          const postPacakge = await 
          sequelize.query
          ('INSERT INTO hudsonBidder (BidderIdentifier,BidderId,BidderCurrency,BidderModel,tagid,BidderType,BidderPrice,BidderAdformat,BidderAuctionType,SecurityType,BidderUrl,BidderWinUrl,DailyFreqPerDeviceId,IsVdopiaBidder,BidderVdopiaMargin,bidRequestCompression,IsAppIdEncoding,GdprApplicability,DeviceOs,BidderPlatform,EnabledOnDesktop,EnabledOnMobile,EnabledOnTablet,EnabledOnConnectedTV,BidderQpsIsUnlimited,adRequestType,DataCenterRegion,supply_chain_applicability,ClientSideUnwrapping,BidderQpsValue,cookie_sync_targeting,channel_choice,BidderCountryCode,BidderAdditionalSettings,AdvertiserId) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
          {
            type:QueryTypes.JSON,
            replacements: [BidderIdentifier,BidderId,BidderCurrency,BidderModel,tagid,BidderType,BidderPrice,BidderAdformat,BidderAuctionType,SecurityType,BidderUrl,BidderWinUrl,DailyFreqPerDeviceId,IsVdopiaBidder,BidderVdopiaMargin,bidRequestCompression,IsAppIdEncoding,GdprApplicability,DeviceOs,BidderPlatform,EnabledOnDesktop,EnabledOnMobile,EnabledOnTablet,EnabledOnConnectedTV,BidderQpsIsUnlimited,adRequestType,DataCenterRegion,supply_chain_applicability,ClientSideUnwrapping,BidderQpsValue,cookie_sync_targeting,chan,BidderCountryCode,BidderAdditionalSettings,AdvertiserId]
           },
            {
              model: hudsonBidder
            });
          res.json(postPacakge);
          // const obj=postPacakge.
            
        } catch (error) {
            console.error(error);
        }
      
      },
    
    fetchHudsonBidderDataById: async (req, res) => {
        const id = req.params.id;
        try {
          const singleSelectPacakge = await 
            sequelize.query
          ('SELECT BidderAdditionalSettings FROM hudsonBidder WHERE hudsonBidder.id = :id',
          { 
            replacements: { id: id },
            type: QueryTypes.SELECT
          },
          {
            model: hudsonBidder,
          })
          res.json(JSON.parse(singleSelectPacakge[0].BidderAdditionalSettings));

          
        } catch (error) {
          console.error(error);
        }
      },

    updateHudsonBidder: async (req, res) => {
        const id=req.params.id;
        const BidderIdentifier=req.body.BidderIdentifier;
        // const BidderId=req.body.BidderId;
        // const BidderCurrency=req.body.BidderCurrency;
        // const BidderModel=req.body.BidderModel;
        const tagid=req.body.tagid;
        const BidderType=req.body.BidderType;
        const BidderPrice=req.body.BidderPrice;
        const BidderAdformat=req.body.BidderAdformat;
        const BidderAuctionType=req.body.BidderAuctionType;
        const SecurityType=req.body.SecurityType;
        const BidderUrl=req.body.BidderUrl;
        const BidderWinUrl=req.body.BidderWinUrl;
        const DailyFreqPerDeviceId=req.body.DailyFreqPerDeviceId;
        const IsVdopiaBidder=req.body.IsVdopiaBidder;
        const BidderVdopiaMargin=req.body.BidderVdopiaMargin;
        const bidRequestCompression=req.body.bidRequestCompression;
        const IsAppIdEncoding=req.body.IsAppIdEncoding;
        const GdprApplicability=req.body.GdprApplicability;
        const DeviceOs=req.body.DeviceOs;
        const BidderPlatform=req.body.BidderPlatform;
        const EnabledOnDesktop=req.body.EnabledOnDesktop;
        const EnabledOnMobile=req.body.EnabledOnMobile;
        const EnabledOnTablet=req.body.EnabledOnTablet;
        const EnabledOnConnectedTV=req.body.EnabledOnConnectedTV;
        const BidderQpsIsUnlimited=req.body.BidderQpsIsUnlimited;
        const adRequestType=req.body.adRequestType;
        // const adRequestResponse=req.body.adRequestResponse;
        const DataCenterRegion=req.body.DataCenterRegion;
        const supply_chain_applicability=req.body.supply_chain_applicability;
        const ClientSideUnwrapping=req.body.ClientSideUnwrapping;
        const BidderQpsValue=req.body.BidderQpsValue;
        console.log(BidderQpsValue);
        const cookie_sync_targeting=req.body.cookie_sync_targeting;
        const channel_choice=req.body.channel_choice;
        // const channel_choice=JSON.stringify(chan);
        // const channel=chan_ch.replaceAll('[', '');
        // const channel_choice=channel.replaceAll(']', '');
        const BidderCountryCode=req.body.BidderCountryCode;
        // const BidderCountryCode=JSON.stringify(bccode)
        const obj = req.body;
        const BidderAdditionalSettings = JSON.stringify(obj);
        try {
          const updateSelectPacakge = await 
            sequelize.query
          ("UPDATE hudsonBidder SET BidderIdentifier = '"+BidderIdentifier+"',tagid = '"+tagid+"',BidderType = '"+BidderType+"',BidderPrice = '"+BidderPrice+"',BidderAdformat = '"+BidderAdformat+"',BidderAuctionType = '"+BidderAuctionType+"',SecurityType = '"+SecurityType+"',BidderUrl = '"+BidderUrl+"',BidderWinUrl = '"+BidderWinUrl+"',DailyFreqPerDeviceId = '"+DailyFreqPerDeviceId+"',IsVdopiaBidder = '"+IsVdopiaBidder+"',BidderVdopiaMargin = '"+BidderVdopiaMargin+"',bidRequestCompression = '"+bidRequestCompression+"',IsAppIdEncoding = '"+IsAppIdEncoding+"',GdprApplicability = '"+GdprApplicability+"',DeviceOs = '"+DeviceOs+"',BidderPlatform = '"+BidderPlatform+"',EnabledOnDesktop = '"+EnabledOnDesktop+"',EnabledOnMobile = '"+EnabledOnMobile+"',EnabledOnTablet = '"+EnabledOnTablet+"',EnabledOnConnectedTV = '"+EnabledOnConnectedTV+"',BidderQpsIsUnlimited = '"+BidderQpsIsUnlimited+"',adRequestType ='"+adRequestType+"',DataCenterRegion = '"+DataCenterRegion+"',supply_chain_applicability = '"+supply_chain_applicability+"',ClientSideUnwrapping = '"+ClientSideUnwrapping+"',BidderQpsValue = '"+BidderQpsValue+"',cookie_sync_targeting = '"+cookie_sync_targeting+"', channel_choice = '"+channel_choice+"', BidderCountryCode= '"+BidderCountryCode+"', BidderAdditionalSettings= '"+BidderAdditionalSettings+"' WHERE id = '"+id+"'",
          {
            type: QueryTypes.UPDATE,
          },
          {
            model: hudsonBidder,
          })
          res.json(( updateSelectPacakge));
        } catch (error) {
          console.error(error);
        }
      }
}