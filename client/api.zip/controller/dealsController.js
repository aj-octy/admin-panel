const express = require('express');
const router = express.Router();
const { QueryTypes, json } = require('sequelize');
const { deals, packages ,deal_overall_stats, hudsonBidder, sequelize} = require('../models');

module.exports = {
    fetchDealData:async(req, res) => {
        let serach = req._parsedUrl.query
          try {
            const listOfdeals = await 
            sequelize.query
          ('SELECT deals.id,deals.status,deals.price, deals.deal_id, deals.name, IF(deals.start_date>NOW(), "scheduled", deals.status) as sstatus , deals.created_at , deals.end_date , deals.start_date , deals.deal_type , deals.auction_price_type , deals.pack_id, FORMAT(dos.adv_rev,2) as adv_spend ,FORMAT(dos.pub_rev,2) as pub_earning,FORMAT(((dos.adv_rev * 1000)/dos.impressions),2) as eCPM,FORMAT(dos.impressions,2) as impressions FROM deals LEFT JOIN deal_overall_stats as dos on(dos.deal_id=deals.deal_id)  where deals.name like:search_name order by deals.id desc',
          {
            replacements: { search_name:'%'+serach+'%' },
            type: QueryTypes.SELECT
          },
          {
            model: deals,
            model: packages,
            model: deal_overall_stats
          });
            res.json(listOfdeals);
              
          } catch (error) {
              console.error(error);
          }
      },

    fetchPackage:async(req, res) =>{
        let serach = req._parsedUrl.query
        try {
          const listOfpackages = await 
          sequelize.query
          ('SELECT id,name FROM packages WHERE name like :search_name',
          {
            replacements: { search_name: serach+'%' },
            type: QueryTypes.SELECT
          },
          {
            model: packages,    
          });
            res.json(listOfpackages);
              
          } catch (error) {
              console.error(error);
          }
    },

    getPackageById:async (req, res) => {
        const id = req.params.id;
        try {
          const singleSelectPacakge = await 
            sequelize.query
          ('SELECT packages.id, packages.name FROM packages WHERE id = :id',
          {
            replacements: { id: id },
            type: QueryTypes.SELECT
          },
          {
            model: deals,
            model: packages
          })
          res.json(singleSelectPacakge);
        } catch (error) {
          console.error(error);
        }
    },

    fetchPackageIdName:async (req, res) => {
        const id = req.params.id;
        try {
          const singleSelectPacakge = await 
            sequelize.query
          ('SELECT packages.id, packages.name FROM packages',
          {
            replacements: { id: id },
            type: QueryTypes.SELECT
          },
          {
            model: deals,
            model: packages
          })
          res.json(singleSelectPacakge);
        } catch (error) {
          console.error(error);
        }
    },

    fetchBidder:async(req, res) =>{
        let serach = req._parsedUrl.query
        try {
          const listOfhudsonBidder = await 
          sequelize.query
          ('SELECT BidderId,BidderName FROM hudsonBidder WHERE BidderName like :search_name',
          {
            replacements: { search_name: serach+'%' },
            type: QueryTypes.SELECT
          },
          {
            model: hudsonBidder,    
          });
            res.json(listOfhudsonBidder);
              
          } catch (error) {
              console.error(error);
          }
    },

    postDeal:async (req, res) => {

        const obj = req.body;
        const deal_id = obj.deal_id;
        const name = obj.name;
        const start_date = obj.start_date;
        const end_date = obj.end_date;
        const auction_price_type = obj.auction_price_type;
        const deal_type = obj.deal_type;
        const daily_limit = obj.price;
        const price = obj.price;
        const pack_id = obj.pack_id;
        const seat_id = obj.seat_id;
        const definition = JSON.stringify(obj);
      
       try {
          const postDeal = await sequelize.query(
            "INSERT INTO deals (definition,name,deal_id,start_date,end_date,auction_price_type,deal_type,daily_limit,price,pack_id,seat_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            {
              type: QueryTypes.JSON,
              replacements: [definition,name,deal_id,start_date,end_date,auction_price_type,deal_type,daily_limit,price,pack_id,seat_id],
            },
            {
              model: deals,
            }
          );
          
          res.json(JSON.parse(definition));
        } catch (error) {
          console.error(error);
        }
    },

    getDealById:async (req, res) => {
        const id = req.params.id;
        try {
          const singleSelectPacakge = await 
            sequelize.query
          ("SELECT definition FROM deals WHERE deals.id = :id",
          {
            replacements: { id: id },
            type: QueryTypes.SELECT
          },
          {
            model: deals,
            model: packages
          })
          res.json(singleSelectPacakge);
        } catch (error) {
          console.error(error);
        }
    },

    updateDeal:async (req, res) => {

        const id = req.params.id;
        const obj = req.body;
        const deal_id = obj.deal_id;
        const name = obj.name;
        const start_date = obj.start_date;
        const end_date = obj.end_date;
        const auction_price_type = obj.auction_price_type;
        const deal_type = obj.deal_type;
        const pack_id = obj.pack_id;
        const seat_id = obj.seat_id;
        let price = obj.price
        let daily_limit = obj.price
        if (auction_price_type == "nonfixed"){
           price = 0
           daily_limit = 0
        }
        
        const definition = JSON.stringify(obj);
        const query = "UPDATE deals SET name = '" + name + "' , definition = '" + definition + "',start_date = '" + start_date + "',end_date = '" + end_date + "',auction_price_type = '" + auction_price_type + "',deal_type = '" + deal_type + "',daily_limit = '" + daily_limit + "',price = '" + price + "',pack_id = '" + pack_id + "',seat_id = '" + seat_id +  "' WHERE id = '" + id + "'";
      
        try {
          const updateSelectDeals = await sequelize.query(
            query,
            {
              replacements: { id: id },
              type: QueryTypes.UPDATE,
            },
            {
              model: deals,
            }
          );
      
          res.json("Deal Updated");
        } catch (error) {
          console.error(error);
        }
    },
}