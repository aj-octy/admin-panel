const { query } = require("express");
const { QueryTypes } = require("sequelize");

const { channels,sequelize } = require("../models");
module.exports = {

    getChannelsData:async(req, res) => {

        try {
        const listOfAdvertiser = await 
        sequelize.query
        ("SELECT * FROM channels LIMIT 1000",
        {
          model: channels      
        });
          res.json(listOfAdvertiser);
        } catch (error) {
            console.error(error);
        }
    },


    getChannelsBySearch:async(req, res) => {

        let search = req._parsedUrl.query
          try {
          const listOfAdvertiser = await 
          sequelize.query
          (
            "select id,name,channel_type from channels WHERE channels.name like :search_name",
            {
              replacements: { search_name:'%'+search+'%' },
              type: QueryTypes.SELECT
            },
            {
              model: channels       
          });
            res.json(listOfAdvertiser);
            
          } catch (error) {
              console.error(error);
          }
      },

      getChannelsById:async (req, res) => {
        let id = req.params.id;
        if(id[(id.length)-1] == ','){
          id = id + "0";
        }
        console.log("-------------%%%%%111%%%%%-------------");
        console.log(id)
;
        console.log("--------------%%%%%%%%%%------------");
      
        if(id){
        try {
          const singleSelectPacakge = await 
            sequelize.query
          ("SELECT * FROM channels WHERE id IN ("+id+") LIMIT 1000",
          { 
            replacements: { id: id },
            type: QueryTypes.SELECT
          },
          {
            model: channels,
          })
          res.json(singleSelectPacakge);
        } catch (error) {
          console.error(error);
        }
        }else if(id === ''){
          console.log("channel id not found");
        }
      },

      getChannelsById2: async (req, res) => {
        let id = req.params.id;
        if(id[(id.length)-1] == ','){
          id = id + "0";
        }
        console.log("-------------%%%%%%%%%%-------------");
        console.log(id)
;
        console.log("--------------%%%%%%%%%%------------");
      
        if(id){
        try {
          const singleSelectPacakge = await 
            sequelize.query
          ("SELECT * FROM channels WHERE id NOT IN ("+id+")",
          { 
            replacements: { id: id },
            type: QueryTypes.SELECT
          },
          {
            model: channels,
          })
          res.json(singleSelectPacakge);
        } catch (error) {
          console.error(error);
        }
        }else if(id === ''){
          console.log("channel id not found");
        }else{
          console.log("no id found, exited!")
        }
      },

      



}
































// const { query } = require("express");
// const { QueryTypes } = require("sequelize");

// const { channels,sequelize } = require("../models");
// module.exports = {

//     getChannelsData:async(req, res) => {

//         try {
//         const listOfAdvertiser = await 
//         sequelize.query
//         ("SELECT * FROM channels",
//         {
//           model: channels      
//         });
//           res.json(listOfAdvertiser);
//         } catch (error) {
//             console.error(error);
//         }
//     },


//     getChannelsBySearch:async(req, res) => {

//         let search = req._parsedUrl.query
//           try {
//           const listOfAdvertiser = await 
//           sequelize.query
//           (
//             "select id,name,channel_type from channels WHERE channels.name like :search_name",
//             {
//               replacements: { search_name:'%'+search+'%' },
//               type: QueryTypes.SELECT
//             },
//             {
//               model: channels       
//           });
//             res.json(listOfAdvertiser);
            
//           } catch (error) {
//               console.error(error);
//           }
//       },

//       getChannelsById:async (req, res) => {
//         let id = req.params.id;
//         if(id[(id.length)-1] == ','){
//           id = id + "0";
//         }
      
//         if(id){
//         try {
//           const singleSelectPacakge = await 
//             sequelize.query
//           ("SELECT * FROM channels WHERE id IN ("+id+")",
//           { 
//             replacements: { id: id },
//             type: QueryTypes.SELECT
//           },
//           {
//             model: channels,
//           })
//           res.json(singleSelectPacakge);
//         } catch (error) {
//           console.error(error);
//         }
//         }else if(id === ''){
//           console.log("channel id not found");
//         }
//       }



// }