const { query } = require("express");
const { QueryTypes } = require("sequelize");

const { country_codes,sequelize } = require("../models");
module.exports = {

    getCountriesData: async(req, res) => {
        try {
            const listOfAdvertiser = await sequelize.query('select * from  country_codes',
        {
            model: country_codes,        
        });
          res.json(listOfAdvertiser);
        
            
        } catch (error) {
            console.error(error);
        }
    
    },

    getCountriesDataByAlphaCode :async (req, res) => {
        console.log("eeeeeeeeeeeeeeeeeee333#######################")
        let id = req.params.id;
        if(id[(id.length)-1] == ','){
          id = id + "0";
        }

        var b = "'" + id.split( "," ).join( "','" ) + "'";
        console.log(id)

        console.log(b)
        if(id){
        try {
          const singleSelectPacakge = await 
            sequelize.query
          ("SELECT * FROM country_codes WHERE alpha_2_code IN ("+b+")",
          { 
            replacements: { id: b },
            type: QueryTypes.SELECT
          },
          {
            model: country_codes,
          })
          res.json(singleSelectPacakge);
        } catch (error) {
          console.error(error);
        }
        }else if(id === ''){
          console.log("country id not found");
        }
      },

      getCountriesDataByAlphaCodeForUpdate :async (req, res) => {
        console.log("yyyyyyyyyyyyyyyyyy#######################")
        let id = req.params.id;
        if(id[(id.length)-1] == ','){
          id = id + "0";
        }

        // var b = "'" + id.split( "," ).join( "','" ) + "'";
        console.log(id)

        // console.log(b)
        if(id){
        try {
          const singleSelectPacakge = await 
            sequelize.query
          ("SELECT * FROM country_codes WHERE alpha_2_code IN ("+id+")",
          { 
            replacements: { id: id },
            type: QueryTypes.SELECT
          },
          {
            model: country_codes,
          })
          res.json(singleSelectPacakge);
        } catch (error) {
          console.error(error);
        }
        }else if(id === ''){
          console.log("country id not found");
        }
      },
}