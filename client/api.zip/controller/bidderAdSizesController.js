const { query } = require("express");
const { QueryTypes } = require("sequelize");

const { bidderAdSizes,sequelize } = require("../models");
module.exports = {

    getBidderAdSizesDataById:async(req, res) => {

        let id=req.params.id;
        console.log("+++++++++++677+++++++++")
        console.log(id)
;
        console.log("+++++++++++677+++++++++")

        try {
        const listOfAdvertiser = await 
        sequelize.query
        ("SELECT adSizeMasterListId FROM bidderAdSizes WHERE id = :id",
        {
          replacements: { id: id },
          model: bidderAdSizes      
        });
          res.json(listOfAdvertiser[0]);
          console.log("_______________________________________")
          console.log(listOfAdvertiser);
        } catch (error) {
            console.error(error);
        }
    },

    postBidderAdSizesDataByBidderId: async(req, res) => {
        console.log("---------------------------------")
        console.log(req.body);
        console.log("---------------------------------")
        const BidderId=req.body.createBidder.BidderId;
        const adSizeData=req.body.adSizeData
        console.log(BidderId);
        console.log(adSizeData);
        for (let i=0; i<adSizeData.length; i++){
            console.log(adSizeData[i]);
            try {
                const postPacakge = await 
                sequelize.query
                ('INSERT INTO bidderAdSizes (id,adSizeMasterListId,updated_by) VALUES (?,?,?)',
                {
                  type:QueryTypes.JSON,
                  replacements: [BidderId,adSizeData[i],56]
                 },
                  {
                    model: bidderAdSizes
                  });
                res.json(postPacakge);
                  
              } catch (error) {
                //   console.error(error);
              }

        }
    },

    updateBidderAdSizeById: async(req , res) => {
        console.log("*******&&&&&&&&&&&&&&&&&&&2222&&&&&&&&&&&&&")
        // console.log(req.body.createBidder.BidderId);
        const id=req.body.createBidder.BidderId;
        console.log(id)
;
        console.log(req.body);
        // console.log(req.body)
        try {
            const postPacakge = await 
            sequelize.query
            ("DELETE FROM bidderAdSizes WHERE id = '"+id+"'",
            {
              type:QueryTypes.JSON,
              replacements: [id]
             },
              {
                model: bidderAdSizes
              });
            res.json(postPacakge);
          } catch (error) {
              console.error(error);
        }
        
    },

    updateBidderAdSizes : async(req, res) => {
        console.log("---------------------------------")
        console.log(req.body);
        console.log("---------------------------------")
        const BidderId=req.body.createBidder.BidderId;
        const unique=req.body.unique
        console.log(BidderId);
        console.log(unique);
        for (let i=0; i<unique.length; i++){
            console.log(unique[i]);
            try {
                const postPacakge = await 
                sequelize.query
                ('INSERT INTO bidderAdSizes (id,adSizeMasterListId,updated_by) VALUES (?,?,?)',
                {
                  type:QueryTypes.JSON,
                  replacements: [BidderId,unique[i],78]
                 },
                  {
                    model: bidderAdSizes
                  });
                res.json(postPacakge);
                  
              } catch (error) {
                //   console.error(error);
              }

        }
    },

    // deleteAdSizeControllerByBidderId: async(req, res) => {

    //     // const BidderId=req.body.createBidder.BidderId;
    //     console.log("+++++++++&&&&&*****(())444");
    //     // console.log(BidderId);
    //     console.log(req.body);
    //     //   try {
    //     //   const listOfAdvertiser = await 
    //     //   sequelize.query
    //     //   (
    //     //     "select id,name,channel_type from channels WHERE channels.name like :search_name",
    //     //     {
    //     //       replacements: { search_name:'%'+search+'%' },
    //     //       type: QueryTypes.SELECT
    //     //     },
    //     //     {
    //     //       model: channels       
    //     //   });
    //     //     res.json(listOfAdvertiser);
            
    //     //   } catch (error) {
    //     //       console.error(error);
    //     //   }
    //   }, 


    // getChannelsBySearch:async(req, res) => {

    //     let search = req._parsedUrl.query
    //       try {
    //       const listOfAdvertiser = await 
    //       sequelize.query
    //       (
    //         "select id,name,channel_type from channels WHERE channels.name like :search_name",
    //         {
    //           replacements: { search_name:'%'+search+'%' },
    //           type: QueryTypes.SELECT
    //         },
    //         {
    //           model: channels       
    //       });
    //         res.json(listOfAdvertiser);
            
    //       } catch (error) {
    //           console.error(error);
    //       }
    //   },

    //   getChannelsById:async (req, res) => {
    //     let id = req.params.id;
    //     if(id[(id.length)-1] == ','){
    //       id = id + "0";
    //     }
    //     console.log("--------------------------");
    //     console.log(id)

    //     console.log("--------------------------");
      
    //     if(id){
    //     try {
    //       const singleSelectPacakge = await 
    //         sequelize.query
    //       ("SELECT * FROM channels WHERE id IN ("+id+")",
    //       { 
    //         replacements: { id: id },
    //         type: QueryTypes.SELECT
    //       },
    //       {
    //         model: channels,
    //       })
    //       res.json(singleSelectPacakge);
    //     } catch (error) {
    //       console.error(error);
    //     }
    //     }else if(id === ''){
    //       console.log("channel id not found");
    //     }
    //   }



}

