const express = require('express');
const router = express.Router();
const { QueryTypes } = require('sequelize');
const { publisher ,country_codes,channnels,advertiser, sequelize} = require('../models');

module.exports = {
    fetchPublisher:async(req, res) => {
  
        console.log(req._parsedUrl.query)
        let serach = req._parsedUrl.query
          try {
          const listOfPublisher = await 
          sequelize.query
          (
            
            'SELECT p.*, ssp.email as sspEmail, DATE_FORMAT(p.addtime,"%b %d, %Y") as addtime, if(a.email!="","true","false") as isExist, (SELECT round(rev_share,2) FROM revenue_share WHERE p.id=revenue_share.publisher_id ORDER BY effective_date desc limit 1) as rev_share, (SELECT effective_date FROM revenue_share WHERE p.id=revenue_share.publisher_id AND p.email!="" ORDER BY effective_date desc limit 1) as effective_date FROM publisher p LEFT JOIN ssp_publisher ssp ON (p.id = ssp.vanilla_pub_id) LEFT JOIN advertiser a ON p.email=a.email AND p.type=a.type where p.email like:search_name',
            {
              replacements: { search_name:'%'+serach+'%' },
              type: QueryTypes.SELECT
            },
            {
              model: advertiser,
              model: country_codes        
          });
            res.json(listOfPublisher);
            
          } catch (error) {
              console.error(error);
          }
      
    },

    fetchPubById:async (req, res) => {
        const id = req.params.id;
        const getById = await publisher.findByPk(id);
        res.json(getById);
    },

    updatePublisher:async (req, res) => {
        await publisher.update(req.body , { where: { id: req.params.id } });
        res.json("data inserted");
    },

    updateAccType:async (req,res) => {
        const id=req.params.id;
        const acc_type=req.body.acc_type;
        try {
          const updateAccType = await 
            sequelize.query
          ('UPDATE publisher SET acc_type= :acc_type WHERE id = :id',
          {
            replacements: { id: id, acc_type: acc_type },
            type: QueryTypes.SELECT
          },
          {
            model: publisher,
          })
          res.json(updateAccType);
        } catch (error) {
          console.error(error);
        }
        res.json("acc_type updated ");
    },

    updateAllowedNetwork:async (req,res) => {
        const id=req.params.id;
        const allowed_networks=req.body.allowed_networks;
        console.log(allowed_networks)
        
        try {
          const singleSelectPacakge = await 
            sequelize.query
          ('UPDATE publisher SET allowed_networks= :allowed_networks WHERE id = :id',
          {
            replacements: { id: id, allowed_networks: allowed_networks },
            type: QueryTypes.SELECT
          },
          {
            model: publisher,
          })
          res.json(singleSelectPacakge);
        } catch (error) {
          console.error(error);
        }
        res.json("allowed_networks updated ");
        
    },

    ConfigureFloor:async (req,res) => {
        const id=req.params.id;
        const price_settle_method=req.body.price_settle_method;
        const psm_trickle_rate=req.body.psm_trickle_rate;
        
        try {
          const ConfigureFloor = await 
            sequelize.query
          ('UPDATE publisher SET price_settle_method= :price_settle_method,psm_trickle_rate= :psm_trickle_rate WHERE id = :id',
          {
            replacements: { id: id, price_settle_method: price_settle_method, psm_trickle_rate: psm_trickle_rate },
            type: QueryTypes.SELECT
          },
          {
            model: publisher,
          })
          res.json(ConfigureFloor);
        } catch (error) {
          console.error(error);
        }
        res.json("price_settle_method updated ");
    },

    updateSellerNetwork:async (req,res) => {
        const id=req.params.id;
        const seller_network_id=req.body.seller_network_id;
      
        
        try {
          const updateSellerNetwork = await 
            sequelize.query
          ('UPDATE publisher SET seller_network_id= :seller_network_id WHERE id = :id',
          {
            replacements: { id: id, seller_network_id: seller_network_id },
            type: QueryTypes.SELECT
          },
          {
            model: publisher,
          })
          res.json(updateSellerNetwork);
        } catch (error) {
          console.error(error);
        }
        res.json("seller_network_id updated  :-)");
        
    },

    updateStatus:async (req, res) => {
        const id = req.params.id;
        const activated = req.body.activated;
      
      try {
        const updateStatus = await 
          sequelize.query
        ('UPDATE publisher SET activated= :activated WHERE id = :id',
        {
          replacements: { id: id, activated: activated },
          type: QueryTypes.SELECT
        },
        {
          model: publisher,
        })
        res.json(updateStatus);
      } catch (error) {
        console.error(error);
        
      }
      res.json("status updated  ");
    },

    updateSellerJson:async (req, res) => {
        const id = req.params.id;
        const is_seller_json_enabled = req.body.is_seller_json_enabled;
      
      try {
        const updateSellerJson = await 
          sequelize.query
        ('UPDATE publisher SET is_seller_json_enabled= :is_seller_json_enabled WHERE id = :id',
        {
          replacements: { id: id, is_seller_json_enabled: is_seller_json_enabled },
          type: QueryTypes.SELECT
        },
        {
          model: publisher,
        })
        res.json(updateSellerJson);
      } catch (error) {
        console.error(error);
      }
        res.json("is_seller_json_enabled updated ");
    },

    updateTruncatedIp:async (req, res) => {
        const id = req.params.id;
        const is_truncated_ip_enabled = req.body.is_truncated_ip_enabled;
      
      try {
        const updateTruncatedIp = await 
          sequelize.query
        ('UPDATE publisher SET is_truncated_ip_enabled= :is_truncated_ip_enabled WHERE id = :id',
        {
          replacements: { id: id, is_truncated_ip_enabled: is_truncated_ip_enabled},
          type: QueryTypes.SELECT
        },
        {
          model: publisher,
        })
        res.json(updateTruncatedIp);
      } catch (error) {
        console.error(error);
      }
        res.json("is_truncated_ip_enabled updated  :-)");
    },

    updateAuthenticatedWith:async (req,res) => {
        const id=req.params.id;
        const authenticated_with=req.body.authenticated_with;
        try {
          const updateAuthenticatedWith = await 
            sequelize.query
          ('UPDATE publisher SET authenticated_with= :authenticated_with WHERE id = :id',
          {
            replacements: { id: id, authenticated_with: authenticated_with },
            type: QueryTypes.SELECT
          },
          {
            model: publisher,
          })
          res.json(updateAuthenticatedWith);
        } catch (error) {
          console.error(error);
        }
        res.json("authenticated_with updated ");
        
    },

    updateVast:async (req, res) => {
        const id = req.params.id;
        const is_vast_enabled = req.body.is_vast_enabled;
      
      try {
        const updateVast = await 
          sequelize.query
        ('UPDATE publisher SET is_vast_enabled= :is_vast_enabled WHERE id = :id',
        {
          replacements: { id: id, is_vast_enabled: is_vast_enabled},
          type: QueryTypes.SELECT
        },
        {
          model: publisher,
        })
        res.json(updateVast);
      } catch (error) {
        console.error(error);
      }
        res.json("VAST enabled activated  ");
    }




}