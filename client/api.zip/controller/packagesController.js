const { query } = require("express");
const { QueryTypes } = require("sequelize");

const { packages, deals, device_os,device_make_model,category,network_carrier,network_ISP,state_code_mapping,city_code_mapping,device_id_type,country_codes,sequelize } = require("../models");
module.exports = {

	getPackageById: async (req, res) => {
      const id = req.params.id;
      const singleSelectPacakge = await sequelize.query(
          "SELECT definition FROM packages WHERE packages.id = :id",
          {
            replacements: { id: id },
            type: QueryTypes.SELECT,
          },
          {
            model: packages,
          }
        );
        res.json(JSON.parse(singleSelectPacakge[0]?.definition));
	},

  getPackageData: async (req, res) => {
      let serach = req._parsedUrl.query
      const listOfpackages = await sequelize.query(
        "select packages.id, packages.name, packages.status, packages.created_at , (select LEFT(GROUP_CONCAT(deals.name),22) from deals where deals.pack_id = packages.id ) as dealId from packages where packages.name like:search_name order by packages.id desc",
        {
          replacements: { search_name:'%'+serach+'%' },
          type: QueryTypes.SELECT
        },
        {
          model: packages,
          model: deals,
        }
      );
      res.json(listOfpackages);
  },

  searchPackageName : async (req, res) => {
    let keyword = req._parsedUrl.query;
      const listOfpackages = await sequelize.query(
        "SELECT id,name FROM packages WHERE name like :search_keyword",
        {
          replacements: { search_keyword: keyword + "%" },
          type: QueryTypes.SELECT,
        },
        {
          model: packages,
        }
      );
      res.json(listOfpackages);
      
  },

  searchOpratingSys:async(req, res) =>{
    let keyword = req._parsedUrl.query
      const listOfdevice_os = await 
      sequelize.query
      ('SELECT DISTINCT(os_name) AS os_name FROM device_os WHERE os_name LIKE :search_keyword',
      {
        replacements: { search_keyword: keyword+'%' },
        type: QueryTypes.SELECT
      },
      {
        model: device_os,    
      });
        res.json(listOfdevice_os)
        
  },

  searchDeviceModel:async(req, res) =>{
    let keyword = req._parsedUrl.query
      const listOfdevice_make_model = await 
      sequelize.query
      ('SELECT DISTINCT(make) AS make   FROM device_make_model WHERE make LIKE :search_keyword',
      {
        replacements: { search_keyword: keyword+'%' },
        type: QueryTypes.SELECT
      },
      {
        model: device_make_model,    
      });
        res.json(listOfdevice_make_model);
  },

  searchCategory:async(req, res) =>{
    let keyword = req._parsedUrl.query
      const listOfcategory = await 
      sequelize.query
      ('SELECT category_code,category_name FROM category WHERE category_name LIKE :search_keyword',
      {
        replacements: { search_keyword: keyword+'%' },
        type: QueryTypes.SELECT
      },
      {
        model: category,    
      });
        res.json(listOfcategory);
  },

  searchNetworkCarrier:async(req, res) =>{
    let keyword = req._parsedUrl.query
      const listOfnetwork_carrier = await 
      sequelize.query
      ('SELECT ccode,carrier FROM network_carrier WHERE carrier LIKE :search_keyword limit 200',
      {
        replacements: { search_keyword: keyword+'%' },
        type: QueryTypes.SELECT
      },
      {
        model: network_carrier,    
      });
        res.json(listOfnetwork_carrier);
  },

  searchNetworkISP:async(req, res) =>{
    let keyword = req._parsedUrl.query
      const listOfnetwork_ISP = await 
      sequelize.query
      ('SELECT ccode,isp_name FROM network_ISP WHERE isp_name LIKE :search_keyword limit 200',
      {
        replacements: { search_keyword: keyword+'%' },
        type: QueryTypes.SELECT
      },
      {
        model: network_ISP,    
      });
        res.json(listOfnetwork_ISP);
  },

  searchState : async(req, res) =>{
    let keyword = req._parsedUrl.query
      const listOfstate_code_mapping = await 
      sequelize.query
      ('SELECT state_name,ccode_alpha_3,ccode FROM state_code_mapping WHERE state_name LIKE :search_keyword limit 200',
      {
        replacements: { search_keyword: keyword+'%' },
        type: QueryTypes.SELECT
      },
      {
        model: state_code_mapping,    
      });
        res.json(listOfstate_code_mapping);
  
  },

  getStateCodeMapping :async (req, res) => {
    const id = req.params.id;
    try {
      const singleSelectstate_code_mapping = await 
        sequelize.query
      ('SELECT state_code_mapping.state_name, state_code_mapping.ccode_alpha_3 FROM state_code_mapping WHERE state_name = :id',
      {
        replacements: { id: id },
        type: QueryTypes.SELECT
      },
      {
        model: deals,
        model: state_code_mapping
      })
      res.json(singleSelectstate_code_mapping);
    } catch (error) {
      console.error(error);
    }
  },

  searchCity:async(req, res) =>{
    let keyword = req._parsedUrl.query
    try {
      const listOfcity_code_mapping = await 
      sequelize.query
      ('SELECT * FROM city_code_mapping WHERE city_name LIKE :search_keyword limit 100',
      {
        replacements: { search_keyword: keyword+'%' },
        type: QueryTypes.SELECT
      },
      {
        model: city_code_mapping,    
      });
        res.json(listOfcity_code_mapping);
          
      } catch (error) {
          console.error(error);
      }
  },

  searchCityById :async (req, res) => {
    const id = req.params.id;
    try {
      const singleSelectcity_code_mapping = await 
        sequelize.query
      ('SELECT city_code_mapping.city_name, city_code_mapping.country_code FROM city_code_mapping WHERE city_name = :id',
      {
        replacements: { id: id },
        type: QueryTypes.SELECT
      },
      {
        model: deals,
        model: city_code_mapping
      })
      res.json(singleSelectcity_code_mapping);
    } catch (error) {
      console.error(error);
    }
  },

  searchDeviceType : async(req, res) =>{
    let keyword = req._parsedUrl.query
    try {
      const listOfdevice_id_type = await 
      sequelize.query
      ('SELECT * FROM device_id_type WHERE model LIKE :search_keyword',
      {
        replacements: { search_keyword: keyword+'%' },
        type: QueryTypes.SELECT
      },
      {
        model: device_id_type,    
      });
        res.json(listOfdevice_id_type);
          
      } catch (error) {
          console.error(error);
      }
  },


  searchCountry: async(req, res) =>{
    
    try {
      const listOfcountry_codes = await 
      sequelize.query
      ('SELECT * FROM country_codes',

      {
        model: country_codes,    
      });
        res.json(listOfcountry_codes);
          
      } catch (error) {
          console.error(error);
      }
  },
  // 

  searchStateByCountry: async (req, res) => {
    const id = req.params.id;
    let keyword = req._parsedUrl.query
    console.log("****************")
    console.log(keyword)
    try {
      const singleSelectcountry_codes = await 
        sequelize.query
      ('select * from state_code_mapping where ccode_alpha_3 like:search_keyword',
      {
        replacements: { id: id,search_keyword:keyword+'%' },
        type: QueryTypes.SELECT
      },
      {
        model: deals,
        model: country_codes
      })
      res.json(singleSelectcountry_codes);
    } catch (error) {
      console.error(error);
    }
  },


  getCountryById: async (req, res) => {
    const id = req.params.id;
    try {
      const singleSelectcountry_codes = await 
        sequelize.query
      ('SELECT country_codes.alpha_3_code, country_codes.country_name FROM country_codes WHERE alpha_3_code = :id',
      {
        replacements: { id: id },
        type: QueryTypes.SELECT
      },
      {
        model: deals,
        model: country_codes
      })
      res.json(singleSelectcountry_codes);
    } catch (error) {
      console.error(error);
    }
  },

	createPackages: async (req, res) => {
    const obj = req.body;
    const definition = JSON.stringify(obj);
    const name = req.body.name;
    try {
      const postPacakge = await sequelize.query(
        "INSERT INTO packages (name,definition) VALUES (?,?)",
        {
          type: QueryTypes.JSON,
          replacements: [name, definition],
        },
        {
          model: packages,
        }
      );
      res.json(postPacakge);
    } catch (error) {
      console.error(error);
    }
  },

  updatePackages: async (req, res) => {
    const obj = req.body;
    const definition = JSON.stringify(obj);
    const id = req.params.id;
    const name = req.body.name;
    try {
      const updateSelectPacakge = await sequelize.query(
        "UPDATE packages SET name = '" +
          name +
          "' , definition = '" +
          definition +
          "' WHERE id = '" +
          id +
          "'",
        {
          replacements: { id: id },
          type: QueryTypes.UPDATE,
  
          replacements: [name, definition],
        },
        {
          model: packages,
        }
      );
      res.json(updateSelectPacakge);
    } catch (error) {
      console.error(error);
    }
  },


  deletePackages:async (req, res) => {
    const postId = req.params.postId;
    await packages.destroy({
      where: {
        id: postId,
      },
    });
  
    res.json("DELETED SUCCESSFULLY");
  },

  updateStatus:async (req, res) => {
    const id = req.params.id;
    const status = req.body.status;

    try {
      const singleSelectPacakge = await sequelize.query(
        'UPDATE packages SET status=:status WHERE id=:id',
        {
          replacements: { id: id, status: status },
          type: QueryTypes.SELECT,
        },
        {
          model: packages,
        }
      );
      res.json(singleSelectPacakge);
    } catch (error) {
      console.error(error);
    }
    res.json("data inserted succesfully");
  },


};