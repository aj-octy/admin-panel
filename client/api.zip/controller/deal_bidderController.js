const { query } = require('express');
const express = require('express');
const router = express.Router();
const { validateToken , isAuthCheck} = require("../middlewares/AuthMiddleware");
const { QueryTypes } = require('sequelize');
const { deals, packages ,deal_overall_stats, hudsonBidder,deal_bidder, sequelize} = require('../models');

module.exports={
    fetchDealBidder:async(req, res) => {
        try {
          const listOfdeals = await 
          sequelize.query
        ('SELECT * FROM deal_bidder',
        {
          model: deals,
          model: packages,
          model: deal_bidder
        });
          res.json(listOfdeals);
            
        } catch (error) {
            console.error(error);
        }
    
    },

    createDealBidder:async (req, res) => {
        deal_bidderArr = req.body;
        let check = deal_bidderArr.some(ol => ol.delete == 'all')
        let listOfdeals = ''
        if(check == false) {
            deal_bidderArr.forEach(async e => {
      
            const deal_id = e.deal_id;
            const bidder_id = e.bidder_id;
            const margin = e.margin;
      
            if(deal_id != ""){
              await deal_bidder.destroy({
                where: {
                  deal_id: deal_id,
                },
            })
            try {
                listOfdeals = await 
                sequelize.query
                ('INSERT INTO deal_bidder (deal_id, bidder_id,margin) VALUES ( ?, ?, ?)',
                {
                  type:QueryTypes.INSERT,
                  replacements: [deal_id, bidder_id, margin]
                },
                  {
                    model: deal_bidder
                  });
              } catch (error) {
                  console.error(error);
              }
          }else{
            console.log("deal id not found")
          }
          })
        } else {
          const query = "DELETE FROM deal_bidder WHERE deal_id ='"+ deal_bidderArr[0].deal_id +"'";
          try {
           await sequelize.query(
              query,
            );
        
            res.send("deal bidder deleted");
          } catch (error) {
            console.error(error);
          }
        }
        res.json(listOfdeals);
    },

    getDealBidderByDealId:async (req, res) => {
        const id = req.params.id;
        try {
          const getDealBidderByDealId = await 
            sequelize.query
          (
            'SELECT * FROM deal_bidder WHERE deal_bidder.deal_id = :id',
          {
            replacements: { id: id },
            type: QueryTypes.SELECT
          },
          {
            model: deal_bidder
          })
          res.json(getDealBidderByDealId);
        } catch (error) {
          console.error(error);
        }
    },

    getBidderByBidderId:async (req, res) => {
        const bidder_id = req.params.bidder_id;
        try {
          const getBidderByBidderId = await 
            sequelize.query
          (
            'SELECT BidderId,BidderName  FROM hudsonBidder WHERE BidderId = :bidder_id',
          {
            replacements: { bidder_id: bidder_id },
            type: QueryTypes.SELECT
          },
          {
            model: hudsonBidder
          })
          res.json(getBidderByBidderId);
        } catch (error) {
          console.error(error);
        }
    },

    updateDealBidder:async (req, res) => {
        await deal_bidder.update(req.body , { where: { id: req.params.id } });
        res.json("data inserted");
    },

    deleteDealBidder:async (req, res) => {
        const postId = req.params.postId;
        await deal_bidder.destroy({
          where: {
            deal_id: postId,
          },
        });
      
        res.json("DELETED SUCCESSFULLY");
      }
}