const { query } = require("express");
const { QueryTypes } = require("sequelize");

const { adSizeMasterList ,admin, sequelize} = require('../models');

module.exports = {
    getAdSizeMasterListData: async(req, res) => {
        let search = req._parsedUrl.query
        try {
          const listOfadSizeMasterList = await 
          sequelize.query
        ('SELECT adSizeMasterList.id,adSizeMasterList.width,adSizeMasterList.height,adSizeMasterList.adType,adSizeMasterList.updated_on,admin.name AS updated_by FROM adSizeMasterList LEFT JOIN admin ON adSizeMasterList.updated_by=admin.id WHERE adSizeMasterList.height like :search_name ORDER BY adSizeMasterList.id DESC',
        {
        replacements: { search_name:'%'+search+'%' },
        model: adSizeMasterList,
        model: admin   
        });
          res.json(listOfadSizeMasterList);
            
        } catch (error) {
            console.error(error);
        }
    
    },

    postAdSizeMasterList:  async (req, res) => {

        try {
            const post = await adSizeMasterList.create(req.body);
            return res.status(200).json({
              post,
            });
          } catch (error) {
            return res.status(500).json({error: error.message})
          }
      
    },

    getAdSizeMasterListById: async (req, res) => {
      let id = req.params.id;
      if(id[(id.length)-1] == ','){
        id = id + "0";
      }
      console.log("-------------------9999-------");
      console.log(id)
;
      console.log("------------------9999--------");
    
      if(id){
      try {
        const singleSelectPacakge = await 
          sequelize.query
        ("SELECT * FROM adSizeMasterList WHERE id IN ("+id+")",
        { 
          replacements: { id: id },
          type: QueryTypes.SELECT
        },
        {
          model: adSizeMasterList,
        })
        res.json(singleSelectPacakge);
      } catch (error) {
        console.error(error);
      }
      }else if(id === ''){
        console.log("channel id not found");
      }
    },
    // async (req, res) => {
    //     const id = req.params.id;
    //     const getById = await adSizeMasterList.findByPk(id)

    //     res.json(getById);
    // },

    updateAdSizeMasterListById: async (req, res) => {
        // const { newTitle, id } = req.body;
        await adSizeMasterList.update(req.body , { where: { id: req.params.id } });
        res.json("data inserted");
    },

    deleteAdSizeMasterListById: async (req, res) => {
        const postId = req.params.postId;
        await adSizeMasterList.destroy({
          where: {
            id: postId,
          },
        });
      
        res.json("DELETED SUCCESSFULLY");
    }



}