const express = require('express');
const router = express.Router();

const { QueryTypes } = require('sequelize');
const { advertiser ,country_codes, sequelize} = require('../models');

module.exports = {
    fetchAdvertiser:async(req, res) => {
        let serach = req._parsedUrl.query
        
          try {
          const listOfAdvertiser = await 
          sequelize.query
          (
            "select advertiser.id, email, CONCAT(fname,' ') as name,company_name,DATE_FORMAT(addtime, '%M %d, %Y') as addtime , acc_type, if(credit>0, FORMAT(credit,2),0.00) as credit, if(country_codes.alpha_3_code!='',country_codes.country_name,'Universal') AS country,activated from advertiser left join country_codes ON ( advertiser.country = country_codes.alpha_2_code ) WHERE advertiser.email like :search_name order by id desc",
            {
              replacements: { search_name:'%'+serach+'%' },
              type: QueryTypes.SELECT
            },
            {
              model: advertiser,
              model: country_codes        
          });
            res.json(listOfAdvertiser);
          } catch (error) {
              console.error(error);
          }
      
    },

    fetchStatus:async (req, res) => {
        const id = req.params.id;
        try {
          const listOfAdvertiser = await
          sequelize.query
          ('SELECT id,activated FROM advertiser WHERE id= :id',
          {
          replacements: { id: id },
          type: QueryTypes.SELECT
          },
          {
          model: advertiser,
          model: country_codes
          });
          res.json(listOfAdvertiser);
        } catch (error) {
          console.error(error);
        }
    },

    updateStatus:async (req, res) => {
        const id = req.params.id;
        const activated = req.body.activated;
      try {
        const updateStatus = await 
          sequelize.query
        ('UPDATE advertiser SET activated= :activated WHERE id = :id',
        {
          replacements: { id: id, activated: activated },
          type: QueryTypes.SELECT
        },
        {
          model: advertiser,
        })
        res.json(updateStatus);
      } catch (error) {
        console.error(error);
      }
        
    },

    createAdvertiser:async (req, res) => {

        try {
            const post = await advertiser.create(req.body);
            return res.status(200).json({
              post,
            });
          } catch (error) {
            return res.status(500).json({error: error.message})
          }
      
    },

    getAdvertiserById:async (req, res) => {
        const id = req.params.id;
        const getById = await advertiser.findByPk(id);
        res.json(getById);
    },

    updateAdvertiser:async (req, res) => {
        await advertiser.update(req.body , { where: { id: req.params.id } });
        res.json("data inserted");
    },

    updateAccType:async (req,res) => {
        const id=req.params.id;
        const acc_type=req.body.acc_type;
        try {
          const singleSelectPacakge = await 
            sequelize.query
          ('UPDATE advertiser SET acc_type= :acc_type WHERE id = :id',
          {
            replacements: { id: id, acc_type: acc_type },
            type: QueryTypes.SELECT
          },
          {
            model: advertiser,
          })
          res.json(singleSelectPacakge);
        } catch (error) {
          console.error(error);
        }
          res.json("data inserted succesfully ---------:-)");
        
      }

    
}