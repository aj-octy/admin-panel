const express = require('express');
const router = express.Router();


const { adv_ssid_mapping ,sequelize} = require('../models');


router.get("/", async(req, res) => {
    try {
    //     const listOfAdvertiser = await advertiser.findAll()
    // res.json(listOfAdvertiser);
    const listOfAdvertiser = await 
    sequelize.query
    ('select * from adv_ssid_mapping',
    {
      model: adv_ssid_mapping        
    });
      res.json(listOfAdvertiser);
        
    } catch (error) {
        console.error(error);
    }

});

router.post("/", async (req, res) => {

  try {
      const post = await adv_ssid_mapping.create(req.body);
      return res.status(200).json({
        post,
      });
    } catch (error) {
      return res.status(500).json({error: error.message})
    }

 });

 router.get("/:id", async (req, res) => {
  const id = req.params.id;
  const getById = await adv_ssid_mapping.findByPk(id);
  res.json(getById);
});

router.put("/:id", async (req, res) => {
  // const { newTitle, id } = req.body;
  await adv_ssid_mapping.update(req.body , { where: { id: req.params.id } });
  res.json("data inserted succesfully here!!!!!!!!!!!!!!!!!!!!!!");
});

router.delete("/:id", async (req, res) => {
  const id = req.params.id;
  await adv_ssid_mapping.destroy({
    where: {
      id: id,
    },
  });

  res.json("DELETED SUCCESSFULLY");
});

module.exports = router
