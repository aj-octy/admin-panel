const { query } = require('express');
const express = require('express');
const router = express.Router();
const { validateToken , isAuthCheck} = require("../middlewares/AuthMiddleware");
const { QueryTypes } = require('sequelize');
const deal_bidderController = require('../controller/deal_bidderController');


router.get("/", deal_bidderController.fetchDealBidder);
router.post("/", [isAuthCheck],deal_bidderController.createDealBidder);
router.get("/:id", deal_bidderController.getDealBidderByDealId)
router.get("/bidder_id/:bidder_id", deal_bidderController.getBidderByBidderId)
router.put("/:id", [isAuthCheck],deal_bidderController.updateDealBidder)
router.delete("/:postId", [isAuthCheck],deal_bidderController.deleteDealBidder)

module.exports = router
