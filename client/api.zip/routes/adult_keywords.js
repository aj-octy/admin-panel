const express = require('express');
const router = express.Router();


const { adult_keywords , sequelize} = require('../models');


router.get("/", async(req, res) => {
    try {
    //     const listOfAdvertiser = await advertiser.findAll()
    // res.json(listOfAdvertiser);
    const listOfAdvertiser = await 
    sequelize.query
    ("SELECT id,keyword,occurence,DATE_FORMAT(created_at,'%b %d, %Y') as created_at ,status FROM adult_keywords",
    {
      model: adult_keywords       
    });
      res.json(listOfAdvertiser);
        
    } catch (error) {
        console.error(error);
    }

});


module.exports = router
