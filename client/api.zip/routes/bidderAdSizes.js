const express = require('express');

const router = express.Router();



const { QueryTypes } = require("sequelize");

const { bidderAdSizes, sequelize} = require('../models');

const bidderAdSizesController = require('../controller/bidderAdSizesController');



router.get("/:id",bidderAdSizesController.getBidderAdSizesDataById);

router.post("/",bidderAdSizesController.postBidderAdSizesDataByBidderId);

router.post("/delete",bidderAdSizesController.updateBidderAdSizeById);

router.post("/update",bidderAdSizesController.updateBidderAdSizes);




module.exports = router