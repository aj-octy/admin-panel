const express = require('express');
const router = express.Router();


const { ifilter_history  , sequelize} = require('../models');


router.get("/", async(req, res) => {
    try {
    //     const listOfAdvertiser = await advertiser.findAll()
    // res.json(listOfAdvertiser);
    const listOfAdvertiser = await 
    sequelize.query
    ("select * from ifilter_history",
    {
      model: ifilter_history        
    });
      res.json(listOfAdvertiser);
        
    } catch (error) {
        console.error(error);
    }

});


module.exports = router
