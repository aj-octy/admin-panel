const express = require('express');
const router = express.Router();


const { publisher_category_blocklist ,country_codes,publisher, sequelize} = require('../models');


router.get("/", async(req, res) => {
    try {
    //     const listOfAdvertiser = await advertiser.findAll()
    // res.json(listOfAdvertiser);
    const listOfAdvertiser = await 
    sequelize.query
    ("SELECT tbl.id,tbl.pub_id,publisher.fname as publisherName ,publisher.lname , publisher.email as publisherEmail, tbl.category as domainCat , tbl.ex_category as ex_domainCat FROM publisher_category_blocklist AS tbl LEFT JOIN publisher ON (publisher.id=tbl.pub_id)",
    {
      model: country_codes,
      model: publisher_category_blocklist,
      model: publisher       
    });
      res.json(listOfAdvertiser);
        
    } catch (error) {
        console.error(error);
    }

});


module.exports = router
