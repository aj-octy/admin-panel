const express = require('express');

const router = express.Router();

const { validateToken , isAuthCheck} = require("../middlewares/AuthMiddleware");

const channelsController = require('../controller/channelsController')

const { QueryTypes } = require('sequelize');

const { channels, sequelize} = require('../models');




router.get("/",channelsController.getChannelsData);

router.get('/search',channelsController.getChannelsBySearch);

router.get("/:id", channelsController.getChannelsById);

router.get("/query/:id", channelsController.getChannelsById2);



module.exports = router













// const express = require('express');
// const router = express.Router();
// const { validateToken , isAuthCheck} = require("../middlewares/AuthMiddleware");
// const channelsController = require('../controller/channelsController')
// const { QueryTypes } = require('sequelize');
// const { channels, sequelize} = require('../models');


// router.get("/",channelsController.getChannelsData);
// router.get('/search',channelsController.getChannelsBySearch);
// router.get("/:id", channelsController.getChannelsById);

// module.exports = router