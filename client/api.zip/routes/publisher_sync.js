const express = require('express');
const router = express.Router();


const { publisher_sync ,country_codes, publisher, sequelize} = require('../models');


router.get("/", async(req, res) => {
    try {
    //     const listOfAdvertiser = await advertiser.findAll()
    // res.json(listOfAdvertiser);
    const listOfAdvertiser = await 
    sequelize.query
    ("SELECT publisher_sync.id, publisher_sync.publisher_sync_url, if(publisher_sync.vdopia_initiated=1 , 'Chocolate Initiated' , 'Partner Initiated') as vdopia_initiated, if(publisher_sync.enabled=1,'checked','unchecked') as enabled, FORMAT((publisher_sync.expiration_time/86400),0) as expiration_time, concat(publisher.company_name,' (',publisher.email,')') as fname, publisher.lname FROM publisher_sync INNER JOIN publisher ON publisher_sync.publisher_id=publisher.id WHERE 1=1 ORDER BY publisher_sync.id desc",
    {
      model: publisher_sync,
      model: country_codes,
      model: publisher        
    });
      res.json(listOfAdvertiser);
        
    } catch (error) {
        console.error(error);
    }

});


module.exports = router
