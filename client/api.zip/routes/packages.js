const express = require("express");
const router = express.Router();
const { validateToken , isAuthCheck} = require("../middlewares/AuthMiddleware");
const packagesController = require('../controller/packagesController')

const { QueryTypes } = require("sequelize");
const { packages, deals, device_os,device_make_model,category,network_carrier,network_ISP,state_code_mapping,city_code_mapping,device_id_type,country_codes,sequelize } = require("../models");

router.get("/searchPackageData",packagesController.getPackageData);
router.get("/search/", [isAuthCheck],packagesController.searchPackageName);
router.get('/operating_system',[isAuthCheck], packagesController.searchOpratingSys);
router.get('/device_model', [isAuthCheck],packagesController.searchDeviceModel);
router.get('/category_search', [isAuthCheck],packagesController.searchCategory);
router.get('/networkCarrier', [isAuthCheck],packagesController.searchNetworkCarrier);
router.get('/networkISP', [isAuthCheck],packagesController.searchNetworkISP);
router.get('/state_mapping', [isAuthCheck],packagesController.searchState);
router.get("/state/:id", [isAuthCheck],packagesController.getStateCodeMapping);
router.get('/city_mapping', [isAuthCheck],packagesController.searchCity);
router.get("/cities/:id", [isAuthCheck],packagesController.searchCityById );
router.get('/device_type', [isAuthCheck],packagesController.searchDeviceType);
router.get('/country',[isAuthCheck],packagesController.searchCountry);
router.get('/stateByCountry',packagesController.searchStateByCountry);
router.get("/country/:id", packagesController.getCountryById);
router.post("/", [isAuthCheck],packagesController.createPackages);
router.get("/:id",packagesController.getPackageById );
router.put("/:id", [isAuthCheck],packagesController.updatePackages);
router.delete("/:postId", [isAuthCheck],packagesController.deletePackages);
router.put("/status/:id", [isAuthCheck],packagesController.updateStatus);

module.exports = router;
