const express = require('express');
const router = express.Router();


const {seller_info , sequelize} = require('../models');


router.get("/", async(req, res) => {
    try {
    //     const listOfAdvertiser = await advertiser.findAll()
    // res.json(listOfAdvertiser);
    const listOfAdvertiser = await 
    sequelize.query
    ('select * from seller_info',
    {
      model: seller_info,        
    });
      res.json(listOfAdvertiser);
        
    } catch (error) {
        console.error(error);
    }

});


module.exports = router
