const express = require('express');
const router = express.Router();


const { advertiser ,country_codes, sequelize} = require('../models');


router.get("/", async(req, res) => {
    try {
    //     const listOfAdvertiser = await advertiser.findAll()
    // res.json(listOfAdvertiser);
    const listOfAdvertiser = await 
    sequelize.query
    ('select advertiser.id, email, CONCAT(fname," ") as name,company_name,DATE_FORMAT(addtime, "%M %d, %Y") as addtime , acc_type, if(credit>0, FORMAT(credit,2),0.00) as credit, if(country_codes.alpha_3_code!="",country_codes.country_name,"Universal") AS country from advertiser left join country_codes ON ( advertiser.country = country_codes.alpha_2_code ) order by id asc limit 150',
    {
      model: advertiser,
      model: country_codes        
    });
      res.json(listOfAdvertiser);
        
    } catch (error) {
        console.error(error);
    }

});


module.exports = router
