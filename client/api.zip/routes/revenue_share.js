const express = require('express');
const router = express.Router();

const { QueryTypes } = require('sequelize');
const { revenue_share , sequelize} = require('../models');


router.get("/", async(req, res) => {
    try {
    //     const listOfAdvertiser = await advertiser.findAll()
    // res.json(listOfAdvertiser);
    const listOfAdvertiser = await 
    sequelize.query
    ("SELECT * FROM revenue_share",
    {
      model: revenue_share        
    });
      res.json(listOfAdvertiser);
        
    } catch (error) {
        console.error(error);
    }

});

router.get("/:id", async (req, res) => {
    const id = req.params.id;
    const rev_share = req.body;
    const getById = await revenue_share.findByPk(id);
    res.json(getById);
  });

router.put("/:id", async (req, res) => {
    const id = req.params.id;
    const rev_share = req.body.rev_share;
    console.log(req.body)
  try {
    const singleSelectPacakge = await 
      sequelize.query
    ('UPDATE revenue_share SET rev_share= :rev_share WHERE publisher_id = :id',
    {
      replacements: { id: id, rev_share: rev_share },
      type: QueryTypes.SELECT
    },
    {
      model: revenue_share,
    })
    res.json(singleSelectPacakge);
  } catch (error) {
    console.error(error);
  }
    res.json("data inserted succesfully :-)");
});


module.exports = router
