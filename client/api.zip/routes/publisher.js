const express = require('express');
const router = express.Router();
const { validateToken , isAuthCheck} = require("../middlewares/AuthMiddleware");
const { QueryTypes } = require('sequelize');
const publisherController = require('../controller/publisherController');



router.get("/search", publisherController.fetchPublisher);
router.get("/:id", publisherController.fetchPubById)
router.put("/:id", [isAuthCheck],publisherController.updatePublisher)
router.put("/acc_type/:id", [isAuthCheck],publisherController.updateAccType)
router.put("/allowed_networks/:id", [isAuthCheck],publisherController.updateAllowedNetwork)
router.put("/ConfigureFloor/:id", [isAuthCheck],publisherController.ConfigureFloor)
router.put("/seller_network_id/:id", [isAuthCheck],publisherController.updateSellerNetwork)
router.put("/activated/:id", [isAuthCheck],publisherController.updateStatus)
router.put("/is_seller_json_enabled/:id", [isAuthCheck],publisherController.updateSellerJson)
router.put("/is_truncated_ip_enabled/:id", [isAuthCheck],publisherController.updateTruncatedIp)
router.put("/authenticated_with/:id", [isAuthCheck],publisherController.updateAuthenticatedWith)
router.put("/is_vast_enabled/:id", [isAuthCheck],publisherController.updateVast)


module.exports = router
