const express = require('express');
const router = express.Router();


const { bidder_sync ,country_codes, sequelize} = require('../models');


router.get("/", async(req, res) => {
    try {
    const listOfAdvertiser = await 
    sequelize.query
    ("SELECT bidder_sync.id,bidder_sync.bidder_sync_url,if(bidder_sync.enabled=1,'checked','unchecked') as enabled,FORMAT((bidder_sync.expiration_time/86400),0) as expiration_time, if(bidder_sync.integrationtype='vdopia_initiated', 'Chocolate Initiated' , 'Partner Initiated') as integrationtype,if(bidder_sync.priority=0,'High',if(bidder_sync.priority=1,'Medium','Low')) as priority,CONCAT(advertiser.company_name,' (',advertiser.email ,')') as fname, advertiser.lname FROM bidder_sync INNER JOIN advertiser ON bidder_sync.advertiser_id=advertiser.id WHERE 1=1 ORDER BY bidder_sync.id DESC",
    {
      model: bidder_sync,
      model: country_codes        
    });
      res.json(listOfAdvertiser);
        
    } catch (error) {
        console.error(error);
    }

});


module.exports = router
