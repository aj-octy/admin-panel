const express = require('express');

const router = express.Router();



const adSizeMasterListController=require('../controller/adSizeMasterListController')

const { QueryTypes } = require("sequelize");

const { adSizeMasterList ,admin, sequelize} = require('../models');



router.get("/search",adSizeMasterListController.getAdSizeMasterListData);

router.post("/",adSizeMasterListController.postAdSizeMasterList);

router.get("/:id",adSizeMasterListController.getAdSizeMasterListById);

router.put("/:id",adSizeMasterListController.updateAdSizeMasterListById);

router.delete("/:postId",adSizeMasterListController.deleteAdSizeMasterListById);



module.exports = router