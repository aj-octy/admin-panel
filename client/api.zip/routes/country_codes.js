const express = require('express');

const router = express.Router();



const countrycodescontroller = require('../controller/countrycodescontroller')

const { QueryTypes } = require('sequelize');

// const { channels, sequelize} = require('../models');



const { country_codes , sequelize} = require('../models');



router.get("/",countrycodescontroller.getCountriesData)

router.get("/:id", countrycodescontroller.getCountriesDataByAlphaCode);

router.get("/update/:id",countrycodescontroller.getCountriesDataByAlphaCodeForUpdate);



module.exports = router