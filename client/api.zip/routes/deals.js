const express = require('express');
const router = express.Router();
const { validateToken , isAuthCheck} = require("../middlewares/AuthMiddleware");
const dealsController = require('../controller/dealsController');




router.get("/search", dealsController.fetchDealData);
router.get('/packages-search',[isAuthCheck], dealsController.fetchPackage);
router.get("/packId/:id",[isAuthCheck], dealsController.getPackageById);
router.get("/packNameId",[isAuthCheck], dealsController.fetchPackageIdName);
router.get('/bidders-search',dealsController.fetchBidder);
router.post("/", dealsController.postDeal);
router.get("/:id",[isAuthCheck], dealsController.getDealById);
router.put("/:id",[isAuthCheck],dealsController.updateDeal);

module.exports = router
