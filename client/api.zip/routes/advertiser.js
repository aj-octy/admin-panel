const express = require('express');
const router = express.Router();
const { validateToken , isAuthCheck} = require("../middlewares/AuthMiddleware");
const { QueryTypes } = require('sequelize');
const advertiserController = require('../controller/advertiserController');
const { advertiser ,country_codes, sequelize} = require('../models');



router.get("", advertiserController.fetchAdvertiser);
router.get("/activeDeactiveUser/:id",advertiserController.fetchStatus);
router.put("/activated/:id", [isAuthCheck],advertiserController.updateStatus);
router.post("/", [isAuthCheck],advertiserController.createAdvertiser);
router.get("/:id", [isAuthCheck],advertiserController.getAdvertiserById);
router.put("/:id", [isAuthCheck],advertiserController.updateAdvertiser);
router.put("/acc_type/:id",[isAuthCheck],advertiserController.updateAccType)


module.exports = router