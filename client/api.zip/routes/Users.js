const express = require("express");
const router = express.Router();
const { Users } = require("../models");
const { advertiser } = require("../models");
const bcrypt = require("bcrypt");
const { sign, verify } = require("jsonwebtoken");
const { QueryTypes } = require('sequelize');

const {   sequelize} = require('../models');


const {validateToken} = require('../middlewares/AuthMiddleware')

router.post("/", async (req, res) => {
  const { username, password } = req.body;
  bcrypt.hash(password, 10).then((hash) => {
    Users.create({
      username: username,
      password: hash,
    });
    res.json("SUCCESS");
  });
});

router.post("/login", async (req, res) => {
  
  const { username, password } = req.body;
  console.log(req.body)
  

  const user = await Users.findOne({ where: { username: username } });

  if (!user) res.json({ error: "User Doesn't Exist" });

  bcrypt.compare(password, user.password).then((match) => {
    if (!match) res.json({ error: "Wrong Username And Password" });

    const accessToken = sign(
      { username: user.username, id: user.id },
      "importantsecret"
    );

    res.json({token: accessToken, username: username, id: user.id});
  })

  


});



router.post("/advertiser-login", async (req, res) => {
  const { username, password } = req.body;

  const user = await advertiser.findOne({ where: { email: username } });

  if (!user) res.json({ error: "User Doesn't Exist" });
  if(user == null){
    console.log(user)
    console.log(username)
  }

  bcrypt.compare(password, user.passwd).then((match) => {
    if (!match) res.json({ error: "Wrong Username And Password" });

    const accessToken = sign(
      { email: user.email, id: user.id, username:user.fname, password:user.passwd },
      "importantsecret"
    );

    res.json({token: accessToken, email: user.email, id: user.id, username:user.fname, password:user.passwd});
  });
});

router.post("/advertiser-Autologin",async (req,res)=>{
  const { username, password } = req.body;

  const user = await advertiser.findOne({ where: { email: username } });

  if (!user) res.json({ error: "User Doesn't Exist" });
  if(user == null){
    console.log(user)
    console.log(username)
  }

  // bcrypt.compare(password, user.passwd).then((match) => {
    // if (!match) res.json({ error: "Wrong Username And Password" });

    const accessToken = sign(
      { email: user.email, id: user.id, username:user.fname, password:user.passwd },
      "importantsecret"
    );

    res.json({token: accessToken, email: user.email, id: user.id, username:user.fname, password:user.passwd});
  // });
})


router.get('/auth',validateToken, (req,res) =>{
  res.json(req.user)
} )


router.post('/check', async(req,res) =>{

  const accessToken = req.body.token
  let adv_id = req.body.adv_id
  try {
      const validToken = verify(accessToken, "importantsecret");
      req.user = validToken;
      if(validToken){
        
        // get adv detail 
            var advQuery = await
            sequelize.query
            ('select * from advertiser WHERE id =:adv_id',
            {
              replacements: { adv_id: adv_id, },
              type: QueryTypes.SELECT
            })
            res.json(advQuery[0])
        // get adv detail 
        
      }else{res.status(404)}

  } catch (error) {
      return res.json({error})
  }

})

router.get('/fetchLoginData/:id/:admin_token', async(req,res) =>{
  const id = req.params.id;
  const accessToken = req.params.admin_token;
  try {
    const validToken = verify(accessToken, "importantsecret");
    req.user = validToken;
    if(validToken){
      console.log("yes")
      
      // get adv detail 
              var advQuery =  await
            sequelize.query
            ('select * from advertiser WHERE id = :id',
            {
              replacements: { id: id, },
              type: QueryTypes.SELECT
            })
            res.json(advQuery[0])
      // get adv detail 
      
    }else{res.status(404)}

} catch (error) {
    return res.json({error})
}


  // const id = req.params.id;
  //     var advQuery =  await
  //   sequelize.query
  //   ('select * from advertiser WHERE id = :id',
  //   {
  //     replacements: { id: id, },
  //     type: QueryTypes.SELECT
  //   })
  //   res.json(advQuery[0])
  

})






// router.post('/check', async(req,res) =>{

//     let admin_id = req.body.admin_id
//     let adv_id = req.body.adv_id

//   // get user details 
//     const adminQuery =  await
//       sequelize.query
//       ('select id,username from Users WHERE id = :admin_id',
//       {
//         replacements: { admin_id: admin_id, },
//         type: QueryTypes.SELECT
//       })
//       console.log(adminQuery);
//   // get user details 

//   if(adminQuery[0].id != '' && adminQuery[0].id != undefined){
//     var advQuery =  await
//     sequelize.query
//     ('select * from advertiser WHERE id = :adv_id',
//     {
//       replacements: { adv_id: adv_id, },
//       type: QueryTypes.SELECT
//     })
//     console.log(advQuery[0].passwd);
//   }

//   if (advQuery[0].passwd != '' && advQuery[0].id && advQuery[0].email){

//     const accessToken = sign(
//       { email: advQuery[0].email, id: advQuery[0].id, username:advQuery[0].fname, password:advQuery[0].passwd },
//       "importantsecret"
//     )

//     res.json({token: accessToken, email: advQuery[0].email, id: advQuery[0].id, username:advQuery[0].fname, password:advQuery[0].passwd});
//     console.log("**************8")

//   }
    

// } )




module.exports = router;