const express = require('express');
const router = express.Router();
const { QueryTypes } = require('sequelize');
const hudsonBidderController=require('../controller/hudsonBidderController')


router.get("/", hudsonBidderController.fetchHudsonBidderData);
router.put("/feedbackEnabled/:id", hudsonBidderController.updateFeedback);
router.put("/dFilterEnabled/:id", hudsonBidderController.updateDFilter);
router.put("/bURLEnabled/:id", hudsonBidderController.updateBURL);
router.put("/privateAuctionEnabled/:id", hudsonBidderController.updatePrivateAuction);
router.put("/floorBasedMarginEnabled/:id", hudsonBidderController.updateFloorBasedMargin);
router.put("/bidderPrice/:id", hudsonBidderController.updateBidderPrice)
router.post("/", hudsonBidderController.insertHudsonBidder);
router.get("/:id", hudsonBidderController.fetchHudsonBidderDataById);
router.get("/:id", hudsonBidderController.fetchHudsonBidderDataById);
router.put("/:id", hudsonBidderController.updateHudsonBidder);

module.exports = router