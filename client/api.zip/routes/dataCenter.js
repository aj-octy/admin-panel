const express = require("express");
const router = express.Router();

const { QueryTypes } = require("sequelize");
const { dataCenter, sequelize } = require("../models");

router.get("/:id", async (req, res) => {
  let keyword = req.params.id
  
  try {
    const listOfdataCenter = await sequelize.query(
      "SELECT dc_name,dc_url , status,if( platform = 'chocolate' , 'chocolate' , 'silverpush') as platform FROM dataCenter WHERE platform = (select authenticated_with from publisher WHERE id=:keyword )",
      {
        replacements: { keyword:keyword },
        type: QueryTypes.SELECT
      },
      {
        model: dataCenter,
      }
    );

    res.json(listOfdataCenter);
    console.log(listOfdataCenter)
  } catch (error) {
    console.error(error);
  }
});

module.exports = router;
