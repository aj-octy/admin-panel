const express = require('express');
const router = express.Router();


const { publisher_cookie_optout ,publisher_device_optout, publisher,sequelize} = require('../models');


router.get("/", async(req, res) => {
    try {
      const listOfdevice_optout = await 
      sequelize.query
      ('SELECT tbl.device_id AS id, tbl.pub_id,  CONCAT(publisher.fname , " " , publisher.lname) AS publisherName1,  publisher.fname AS publisherName,  publisher.fname as fname , publisher.lname , publisher.email as publisherEmail FROM publisher_device_optout AS tbl LEFT JOIN publisher ON (publisher.id=tbl.pub_id)',
    {
      model: publisher_device_optout, 
      model: publisher  
    });
      res.json(listOfdevice_optout);
        
    } catch (error) {
        console.error(error);
    }

});

router.get("/publisher_cookie_optout", async(req, res) => {
    try {
      const listOfcookie_optout = await 
      sequelize.query
      ('SELECT  tbl.cookie_id AS id, tbl.pub_id, CONCAT(publisher.fname , " " , publisher.lname) AS publisherName1,  publisher.fname AS publisherName,  publisher.fname as fname , publisher.lname, publisher.email as publisherEmail FROM publisher_cookie_optout AS tbl LEFT JOIN publisher ON (publisher.id=tbl.pub_id) ',
    {
      model: publisher_cookie_optout, 
      model: publisher  
    });
      res.json(listOfcookie_optout);
        
    } catch (error) {
        console.error(error);
    }

});



module.exports = router
