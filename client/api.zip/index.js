const express = require("express")
const cors = require("cors");

//initializing express
const app = express();

app.use(express.json());

app.use(cors());

//initializing tables of database
const db = require("./models");

//All Routers

const usersRouter = require("./routes/Users");
app.use("/auth", usersRouter);

const advertiserRoute = require("./routes/advertiser");
app.use("/advertiser", advertiserRoute);

const hudsonBidder = require("./routes/hudsonBidder");
app.use("/hudsonBidder", hudsonBidder);

const countryRoute = require("./routes/country_codes");
app.use("/country", countryRoute);

const publisher = require("./routes/publisher");
app.use("/publisher", publisher);

const pubCookieOpt = require("./routes/pubCookieOpt");
app.use("/pubCookieOpt", pubCookieOpt);

const adSizeMasterList = require("./routes/adSizeMasterList");
app.use("/adSizeMasterList", adSizeMasterList);

const bidder_sync = require("./routes/bidder_sync");
app.use("/bidder_sync", bidder_sync);

const publisher_sync= require("./routes/publisher_sync");
app.use("/publisher_sync",publisher_sync)   

const publisher_domain_blocklist= require("./routes/publisher_domain_blocklist");
app.use("/publisher_domain_blocklist",publisher_domain_blocklist)

const ifilter_history= require("./routes/ifilter_history");
app.use("/ifilter_history",ifilter_history)

const revenue_share= require("./routes/revenue_share");
app.use("/revenue_share",revenue_share)

const adult_keywords= require("./routes/adult_keywords");
app.use("/adult_keywords",adult_keywords)

const directProperties= require("./routes/directProperties");
app.use("/directProperties",directProperties)

const globally_blocked_domains= require("./routes/globally_blocked_domains");
app.use("/globally_blocked_domains",globally_blocked_domains)

const packages= require("./routes/packages");
app.use("/packages",packages)

const deals= require("./routes/deals");
app.use("/deals",deals)

const deal_bidder= require("./routes/deal_bidder");
app.use("/deal_bidder",deal_bidder)

const seller_info= require("./routes/seller_info");
app.use("/seller_info", seller_info)

const adv_ssid_mapping= require("./routes/adv_ssid_mapping");
app.use("/adv_ssid_mapping", adv_ssid_mapping)

const channels= require("./routes/channels");
app.use("/channels", channels)

const dataCenter= require("./routes/dataCenter");
app.use("/dataCenter", dataCenter)
    //Routes

db.sequelize.sync().then(()=>{
    app.listen(5000, ()=> {
        console.log("server is running on 5000")
    })
})
